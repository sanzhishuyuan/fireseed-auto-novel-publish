import { NextRequest, NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import db from '@/lib/db';
import { addSubmission } from '@/lib/task-helper';
import { withRoute } from '@/lib/with-route';
import type { AIContext } from '@/lib/with-route';

export const dynamic = 'force-dynamic';

/**
 * POST /api/ai/tasks/submit
 * AI 代理的任务提交通道
 * body: { token, task_id, content, file_url?, title? }
 */
export const POST = withRoute({ auth: 'ai', body: true, optionalAuth: true }, async (request: NextRequest, ctx: AIContext) => {
  try {
    const { task_id, content, file_url, title } = ctx.body;
    const userId = ctx.ai.valid ? (ctx.ai.userId || 'anonymous') : null;

    if (!task_id) {
      return NextResponse.json({ error: 'task_id is required' }, { status: 400 });
    }

    if (!content && !file_url) {
      return NextResponse.json({ error: '请提供交付内容或文件链接' }, { status: 400 });
    }

    if (!userId || userId === 'anonymous') {
      return NextResponse.json({ error: 'AI 代理需要关联用户' }, { status: 401 });
    }

    // 校验任务是否存在且已分配给该用户
    const task = db.prepare('SELECT status, assignee_id FROM novel_tasks WHERE id = ?').get(task_id) as {
      status: string;
      assignee_id: string;
    } | undefined;

    if (!task) {
      return NextResponse.json({ error: '任务不存在' }, { status: 404 });
    }
    if (task.status !== 'assigned') {
      return NextResponse.json({ error: '任务状态不正确' }, { status: 400 });
    }
    if (task.assignee_id !== userId) {
      return NextResponse.json({ error: '无权操作此任务' }, { status: 403 });
    }

    // 执行提交
    const result = addSubmission(task_id, userId, {
      title: title || 'AI 自动提交',
      content: content || undefined,
      file_path: file_url || undefined,
      file_name: file_url ? file_url.split('/').pop() : undefined,
    });

    if (!result.success) {
      return NextResponse.json({ error: result.error || '提交失败' }, { status: 400 });
    }

    // 记录 skill 事件
    try {
      db.prepare(`
        INSERT INTO skill_events (id, user_id, event_type, event_data)
        VALUES (?, ?, ?, ?)
      `).run(
        uuidv4(),
        userId,
        'task_complete',
        JSON.stringify({ task_id, submission_id: result.submissionId, source: 'ai_channel' })
      );
    } catch (e) {
      console.warn('[AI Task] 记录事件失败:', e);
    }

    return NextResponse.json({
      success: true,
      submission_id: result.submissionId,
      message: '提交成功，等待发布者审核',
    });
  } catch (error) {
    console.error('[AI Task] 提交失败:', error);
    return NextResponse.json({ success: false, error: '服务器错误' }, { status: 500 });
  }
});
