"use strict";(()=>{var e={};e.id=791,e.ids=[791],e.modules={85890:e=>{e.exports=require("better-sqlite3")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},49048:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>f,patchFetch:()=>T,requestAsyncStorage:()=>L,routeModule:()=>R,serverHooks:()=>_,staticGenerationAsyncStorage:()=>S});var n={};t.r(n),t.d(n,{GET:()=>N,dynamic:()=>I});var a=t(49303),s=t(88716),i=t(60670),o=t(71299),l=t(9487),d=t(94877);function u(e){let r=new Date;switch(e){case"weekly":return{startDate:new Date(r.getTime()-6048e5).toISOString()};case"monthly":return{startDate:new Date(r.getTime()-2592e6).toISOString()};default:return{startDate:null}}}function c(e){return e>=1e4?(e/1e4).toFixed(1)+"w":e>=1e3?(e/1e3).toFixed(1)+"k":e.toString()}let E={favorites:"最多收藏",reads:"最多阅读",likes:"最多点赞",chapters:"章节最多",words:"字数最多",popular:"综合热度"},p={novels:"作品最多",words:"总字数最多",favorites:"总收藏最多",reads:"最多读者",earned:"收入最高"},O={all:"全部",weekly:"本周",monthly:"本月"},I="force-dynamic";async function N(e){try{let r,t;let{searchParams:n}=new URL(e.url),a=n.get("category")||"novels",s=n.get("type")||"popular",i=n.get("period")||"all",I=Math.min(Math.max(parseInt(n.get("limit")||"20"),1),100);if(!["all","weekly","monthly"].includes(i))return(0,o.q)("INVALID_PARAM","无效的时间周期，支持 all/weekly/monthly",400);switch(a){case"novels":{let e=["favorites","reads","likes","chapters","words","popular"];if(!e.includes(s))return(0,o.q)("INVALID_PARAM",`无效的排行榜类型，支持: ${e.join(", ")}`,400);r=function(e,r="all",t=20){let n;let{startDate:a}=u(r),s=a?`AND created_at >= '${a}'`:"";switch(e){case"favorites":n=`
        SELECT n.id, n.title, n.author, n.tags, COUNT(f.id) as score
        FROM novels n
        LEFT JOIN favorites f ON f.novel_id = n.id ${s.replace(/AND/,"AND f")}
        WHERE n.deleted_at IS NULL
        GROUP BY n.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"reads":n=`
        SELECT n.id, n.title, n.author, n.tags, COUNT(DISTINCT up.user_id) as score
        FROM novels n
        LEFT JOIN user_progress up ON up.novel_id = n.id ${s.replace(/AND/,"AND up")}
        WHERE n.deleted_at IS NULL
        GROUP BY n.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"likes":n=`
        SELECT n.id, n.title, n.author, n.tags, COUNT(nl.id) as score
        FROM novels n
        LEFT JOIN novel_likes nl ON nl.novel_id = n.id ${s.replace(/AND/,"AND nl")}
        WHERE n.deleted_at IS NULL
        GROUP BY n.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"chapters":n=`
        SELECT n.id, n.title, n.author, n.tags, COUNT(c.id) as score
        FROM novels n
        LEFT JOIN chapters c ON c.novel_id = n.id ${s.replace(/AND/,"AND c")}
        WHERE n.deleted_at IS NULL
        GROUP BY n.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"words":n=`
        SELECT n.id, n.title, n.author, n.tags, COALESCE(SUM(c.word_count), 0) as score
        FROM novels n
        LEFT JOIN chapters c ON c.novel_id = n.id ${s.replace(/AND/,"AND c")}
        WHERE n.deleted_at IS NULL
        GROUP BY n.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"popular":n=`
        SELECT n.id, n.title, n.author, n.tags,
          COALESCE(f.cnt, 0) * 10 + COALESCE(r.cnt, 0) * 3 + COALESCE(l.cnt, 0) * 5 + COALESCE(c.cnt, 0) * 2 as score
        FROM novels n
        LEFT JOIN (SELECT novel_id, COUNT(*) as cnt FROM favorites GROUP BY novel_id) f ON f.novel_id = n.id
        LEFT JOIN (SELECT novel_id, COUNT(DISTINCT user_id) as cnt FROM user_progress GROUP BY novel_id) r ON r.novel_id = n.id
        LEFT JOIN (SELECT novel_id, COUNT(*) as cnt FROM novel_likes GROUP BY novel_id) l ON l.novel_id = n.id
        LEFT JOIN (SELECT novel_id, COUNT(*) as cnt FROM chapters GROUP BY novel_id) c ON c.novel_id = n.id
        WHERE n.deleted_at IS NULL
        ORDER BY score DESC
        LIMIT ?
      `;break;default:return[]}return l.default.prepare(n).all(t).map((e,r)=>({rank:r+1,targetId:e.id,title:e.title,subtitle:e.author||"匿名作者",score:e.score,scoreLabel:c(e.score),extra:{tags:e.tags}}))}(s,i,I),t=E[s]||"小说排行";break}case"authors":{let e=["novels","words","favorites","reads","earned"];if(!e.includes(s))return(0,o.q)("INVALID_PARAM",`无效的排行榜类型，支持: ${e.join(", ")}`,400);r=function(e,r="all",t=20){let n;let{startDate:a}=u(r),s=a?`AND n.created_at >= '${a}'`:"";switch(e){case"novels":n=`
        SELECT u.id, u.username, u.nickname, COUNT(n.id) as score
        FROM users u
        INNER JOIN novels n ON n.author_id = u.id AND n.deleted_at IS NULL ${s}
        GROUP BY u.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"words":n=`
        SELECT u.id, u.username, u.nickname, COALESCE(SUM(c.word_count), 0) as score
        FROM users u
        INNER JOIN novels n ON n.author_id = u.id AND n.deleted_at IS NULL
        LEFT JOIN chapters c ON c.novel_id = n.id
        GROUP BY u.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"favorites":n=`
        SELECT u.id, u.username, u.nickname, COUNT(f.id) as score
        FROM users u
        INNER JOIN novels n ON n.author_id = u.id AND n.deleted_at IS NULL
        LEFT JOIN favorites f ON f.novel_id = n.id
        GROUP BY u.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"reads":n=`
        SELECT u.id, u.username, u.nickname, COUNT(DISTINCT up.user_id) as score
        FROM users u
        INNER JOIN novels n ON n.author_id = u.id AND n.deleted_at IS NULL
        LEFT JOIN user_progress up ON up.novel_id = n.id
        GROUP BY u.id
        ORDER BY score DESC
        LIMIT ?
      `;break;case"earned":n=`
        SELECT u.id, u.username, u.nickname, COALESCE(w.total_earned, 0) as score
        FROM users u
        LEFT JOIN wallets w ON w.user_id = u.id
        WHERE (SELECT COUNT(*) FROM novels WHERE author_id = u.id AND deleted_at IS NULL) > 0
        ORDER BY score DESC
        LIMIT ?
      `;break;default:return[]}return l.default.prepare(n).all(t).map((e,r)=>({rank:r+1,targetId:e.id,title:e.nickname||e.username,subtitle:"@"+e.username,score:e.score,scoreLabel:c(e.score)}))}(s,i,I),t=p[s]||"作者排行";break}case"seed":r=function(e=20){return(0,d.Zp)(e).map((e,r)=>({rank:r+1,targetId:e.user_id,title:e.username,subtitle:`累计收入 ${e.total_earned.toLocaleString()} 🌾`,score:e.balance,scoreLabel:"\uD83C\uDF31 "+e.balance.toLocaleString()}))}(I),t="SEED 富豪榜";break;default:return(0,o.q)("INVALID_PARAM","无效的分类，支持 novels/authors/seed",400)}return(0,o.L)({category:a,type:s,period:i,label:t,periodLabel:O[i]||"全部",entries:r,updatedAt:new Date().toISOString()})}catch(e){return console.error("[Ranking API] Error:",e),(0,o.q)("INTERNAL_ERROR","获取排行榜失败",500)}}let R=new a.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/ranking/route",pathname:"/api/ranking",filename:"route",bundlePath:"app/api/ranking/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\ranking\\route.ts",nextConfigOutput:"standalone",userland:n}),{requestAsyncStorage:L,staticGenerationAsyncStorage:S,serverHooks:_}=R,f="/api/ranking/route";function T(){return(0,i.patchFetch)({serverHooks:_,staticGenerationAsyncStorage:S})}},71299:(e,r,t)=>{t.d(r,{L:()=>a,q:()=>s});var n=t(87070);function a(e,r){return n.NextResponse.json({success:!0,data:e,...r&&{meta:r},request_id:crypto.randomUUID().slice(0,8)})}function s(e,r,t,a){return n.NextResponse.json({success:!1,error:{code:e,message:r,...a&&{details:a}},request_id:crypto.randomUUID().slice(0,8),status_code:t},{status:t})}},94877:(e,r,t)=>{t.d(r,{B3:()=>l,Zp:()=>u,f1:()=>d,jq:()=>c,k:()=>s,sb:()=>i,transferSeed:()=>o});var n=t(9576),a=t(9487);function s(e){let r=a.default.prepare("SELECT * FROM wallets WHERE user_id = ?").get(e);return r||(a.default.prepare("INSERT INTO wallets (user_id, balance, total_earned, total_spent) VALUES (?, 0, 0, 0)").run(e),r=a.default.prepare("SELECT * FROM wallets WHERE user_id = ?").get(e)),r}function i(e){let r=a.default.prepare("SELECT balance FROM wallets WHERE user_id = ?").get(e);return r?.balance??0}function o(e,r,t,o){if(r<0){let t=i(e);if(t+r<0)throw Error(`余额不足：当前 ${t} 🌱，需要 ${Math.abs(r)} 🌱`)}return a.default.transaction(()=>{let i=s(e).balance+r;a.default.prepare(`
      UPDATE wallets SET balance = ?, total_earned = total_earned + ?, total_spent = total_spent + ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).run(i,r>0?r:0,r<0?Math.abs(r):0,e);let l=(0,n.Z)();return a.default.prepare(`
      INSERT INTO transactions (id, user_id, target_id, type, ref_id, amount, balance_after, description)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(l,e,o?.targetId||null,t,o?.refId||null,r,i,o?.description||null),i})()}function l(e,r,t,n,s){if(t<=0)throw Error("转账金额必须为正数");let i=s?.platformShare||0,l=t-i;return a.default.transaction(()=>{let a;let d=o(e,-t,n,{refId:s?.refId,description:s?.description}),u=o(r,l,n,{targetId:e,refId:s?.refId,description:s?.description});return i>0&&(a=o("platform",i,n,{refId:s?.refId,description:`平台抽佣 ${i} SEED`})),{fromBalance:d,toBalance:u,platformBalance:a}})()}function d(e,r=20,t=0){return a.default.prepare(`
    SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(e,r,t)}function u(e=20){return a.default.prepare(`
    SELECT w.user_id, u.username, w.balance, w.total_earned
    FROM wallets w
    JOIN users u ON w.user_id = u.id
    WHERE w.balance > 0 AND u.role != 'admin'
    ORDER BY w.balance DESC
    LIMIT ?
  `).all(e)}function c(e,r){let t=i("platform");if(t<e)throw Error(`平台余额不足: ${t} < ${e}`);o("platform",-e,"burn",{description:r||`销毁 ${e} SEED`});let n=new Date().toISOString().slice(0,10);a.default.prepare(`
    INSERT INTO daily_economy_stats (date, seed_burned)
    VALUES (?, ?)
    ON CONFLICT(date) DO UPDATE SET seed_burned = seed_burned + ?
  `).run(n,e,e)}},49303:(e,r,t)=>{e.exports=t(30517)},9576:(e,r,t)=>{t.d(r,{Z:()=>d});var n=t(84770),a=t.n(n);let s={randomUUID:a().randomUUID},i=new Uint8Array(256),o=i.length,l=[];for(let e=0;e<256;++e)l.push((e+256).toString(16).slice(1));let d=function(e,r,t){if(s.randomUUID&&!r&&!e)return s.randomUUID();let n=(e=e||{}).random||(e.rng||function(){return o>i.length-16&&(a().randomFillSync(i),o=0),i.slice(o,o+=16)})();if(n[6]=15&n[6]|64,n[8]=63&n[8]|128,r){t=t||0;for(let e=0;e<16;++e)r[t+e]=n[e];return r}return function(e,r=0){return l[e[r+0]]+l[e[r+1]]+l[e[r+2]]+l[e[r+3]]+"-"+l[e[r+4]]+l[e[r+5]]+"-"+l[e[r+6]]+l[e[r+7]]+"-"+l[e[r+8]]+l[e[r+9]]+"-"+l[e[r+10]]+l[e[r+11]]+l[e[r+12]]+l[e[r+13]]+l[e[r+14]]+l[e[r+15]]}(n)}}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),n=r.X(0,[8948,7070,9487],()=>t(49048));module.exports=n})();