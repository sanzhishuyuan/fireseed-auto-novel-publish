"use strict";(()=>{var e={};e.id=6639,e.ids=[6639],e.modules={85890:e=>{e.exports=require("better-sqlite3")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},30946:(e,t,s)=>{s.r(t),s.d(t,{originalPathname:()=>h,patchFetch:()=>S,requestAsyncStorage:()=>E,routeModule:()=>f,serverHooks:()=>R,staticGenerationAsyncStorage:()=>x});var r={};s.r(r),s.d(r,{GET:()=>_,POST:()=>l});var n=s(49303),o=s(88716),u=s(60670),i=s(87070),a=s(9576),d=s(9487),p=s(84770),c=s.n(p),g=s(97032);async function l(e){try{let t=await e.text(),s=(0,g.N)(t);if(!s.success)return s.response;let{device_id:r}=s.data;if(r){let e=d.default.prepare("SELECT guest_id FROM guest_sessions WHERE device_id = ?").get(r);if(e)return d.default.prepare("UPDATE guest_sessions SET last_active = CURRENT_TIMESTAMP WHERE guest_id = ?").run(e.guest_id),i.NextResponse.json({success:!0,guest_id:e.guest_id,is_new:!1})}let n=(0,a.Z)(),o=`guest_${c().randomBytes(8).toString("hex")}`;return d.default.prepare(`
      INSERT INTO guest_sessions (id, guest_id, device_id)
      VALUES (?, ?, ?)
    `).run(n,o,r||null),i.NextResponse.json({success:!0,guest_id:o,is_new:!0})}catch(e){return console.error("Guest session error:",e),i.NextResponse.json({error:"服务器错误"},{status:500})}}async function _(e){let{searchParams:t}=new URL(e.url),s=t.get("guest_id");if(!s)return i.NextResponse.json({error:"缺少 guest_id"},{status:400});let r=d.default.prepare(`
    SELECT 
      gn.id,
      gn.title,
      gn.author,
      gn.description,
      gn.status,
      gn.tags,
      gn.created_at,
      gn.updated_at,
      COUNT(gc.id) as chapter_count,
      SUM(COALESCE(gc.word_count, 0)) as total_words
    FROM guest_novels gn
    LEFT JOIN guest_chapters gc ON gc.guest_novel_id = gn.id
    WHERE gn.guest_id = ?
    GROUP BY gn.id
    ORDER BY gn.updated_at DESC
  `).all(s);return i.NextResponse.json({novels:r})}let f=new n.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/guest/session/route",pathname:"/api/guest/session",filename:"route",bundlePath:"app/api/guest/session/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\guest\\session\\route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:E,staticGenerationAsyncStorage:x,serverHooks:R}=f,h="/api/guest/session/route";function S(){return(0,u.patchFetch)({serverHooks:R,staticGenerationAsyncStorage:x})}},97032:(e,t,s)=>{s.d(t,{N:()=>n});var r=s(87070);function n(e){try{let t=JSON.parse(e);return{success:!0,data:t}}catch(e){if(e instanceof SyntaxError)return{success:!1,response:r.NextResponse.json({success:!1,error:"请求体格式错误",code:"INVALID_JSON"},{status:400})};throw e}}},49303:(e,t,s)=>{e.exports=s(30517)},9576:(e,t,s)=>{s.d(t,{Z:()=>d});var r=s(84770),n=s.n(r);let o={randomUUID:n().randomUUID},u=new Uint8Array(256),i=u.length,a=[];for(let e=0;e<256;++e)a.push((e+256).toString(16).slice(1));let d=function(e,t,s){if(o.randomUUID&&!t&&!e)return o.randomUUID();let r=(e=e||{}).random||(e.rng||function(){return i>u.length-16&&(n().randomFillSync(u),i=0),u.slice(i,i+=16)})();if(r[6]=15&r[6]|64,r[8]=63&r[8]|128,t){s=s||0;for(let e=0;e<16;++e)t[s+e]=r[e];return t}return function(e,t=0){return a[e[t+0]]+a[e[t+1]]+a[e[t+2]]+a[e[t+3]]+"-"+a[e[t+4]]+a[e[t+5]]+"-"+a[e[t+6]]+a[e[t+7]]+"-"+a[e[t+8]]+a[e[t+9]]+"-"+a[e[t+10]]+a[e[t+11]]+a[e[t+12]]+a[e[t+13]]+a[e[t+14]]+a[e[t+15]]}(r)}}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[8948,7070,9487],()=>s(30946));module.exports=r})();