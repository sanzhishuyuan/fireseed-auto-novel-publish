"use strict";(()=>{var e={};e.id=714,e.ids=[714],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},78580:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>$,patchFetch:()=>O,requestAsyncStorage:()=>N,routeModule:()=>T,serverHooks:()=>L,staticGenerationAsyncStorage:()=>y});var s={};r.r(s),r.d(s,{DELETE:()=>h,GET:()=>_,POST:()=>f,PUT:()=>R,dynamic:()=>E});var a=r(49303),n=r(88716),i=r(60670),o=r(87070),c=r(9576),p=r(9487),l=r(90455);let u={dnd5e:{id:"dnd5e",name:"龙与地下城 5e",description:"经典的奇幻冒险规则系统",dice:"D20",attributes:["力量","敏捷","体质","智力","感知","魅力"],skills:{力量:["运动"],敏捷:["杂技","巧手","隐匿","体操"],体质:["体操"],智力:["秘法","历史","调查","自然","宗教"],感知:["驯兽","洞察","医药","察觉","求生"],魅力:["欺瞒","威吓","表演","游说"]},systemPrompt:`你是一位经验丰富的 D&D 5e 地下城主 (Game Master)。
规则要点：
- 使用 D20 进行属性检定和攻击检定，加上对应的属性调整值和熟练加值
- 困难等级 (DC): 5(非常容易), 10(容易), 15(中等), 20(困难), 25(非常困难), 30(几乎不可能)
- 战斗中使用先攻顺序，每个回合包括：移动、动作、附赠动作、反应
- 当需要掷骰时，使用 [[D20+N]] 格式标记
- 保持叙事生动，描述场景的视觉、听觉、嗅觉细节
- 给玩家选择权，不要替玩家做决定
- 奖励创造性思维，灵活处理规则`},coc7th:{id:"coc7th",name:"克苏鲁的呼唤 7th",description:"恐怖调查角色扮演游戏",dice:"D100",attributes:["力量","体质","体型","敏捷","外貌","智力","意志","教育","幸运"],skills:{专业技能:["会计","人类学","考古学","艺术与手艺","魅惑","攀爬","计算机","信用评级","克苏鲁神话","汽车驾驶","电气维修","话术","格斗","火器","急救","历史","恐吓","跳跃","法律","图书馆","聆听","锁匠","机械维修","医学","自然史","导航","神秘学","操作重型机械","说服","精神分析","心理学","骑术","科学","妙手","侦查","潜行","生存","游泳","投掷","追踪"]},systemPrompt:`你是一位克苏鲁的呼唤 7th 版守秘人 (Keeper of Arcane Lore)。
规则要点：
- 使用 D100 进行技能检定，结果 ≤ 技能值为成功
- 困难成功: ≤ 技能值的一半，极难成功: ≤ 技能值的五分之一
- 大成功: 掷出 01，大失败: 掷出 100
- 理智值 (SAN) 是关键机制，遭遇恐怖事件需要进行理智检定
- 战斗是危险的，鼓励调查和思考而非硬碰硬
- 营造悬疑和恐怖的氛围，描述环境的细节和不安感
- 当需要掷骰时，使用 [[D100]] 或 [[D100>技能值]] 格式标记`},shadowrun:{id:"shadowrun",name:"暗影狂奔",description:"赛博朋克+奇幻的混合世界",dice:"D6",attributes:["力量","敏捷","体质","智力","意志","魅力","边缘","魔法/共鸣"],skills:{通用:["运动","自动化","生物科技","破解","电子战","工程","逃脱","火器","投掷武器","肉搏","潜入","调查","语言","领导力","医疗","近战","导航","谈判","秘法","驾驶","手枪","长枪","霰弹枪","潜行","生存","追踪"]},systemPrompt:"You are a Shadowrun Game Master in the sixth world..."},custom:{id:"custom",name:"自由叙事",description:"完全自由的叙事式角色扮演，无固定规则约束",dice:"D20",attributes:["力量","敏捷","智力","魅力"],skills:{},systemPrompt:`你是一位富有创造力的叙事主持人 (Storyteller)。
- 用生动的语言描述场景、角色和事件
- 推动剧情发展，但给玩家充分的自由选择空间
- 当需要不确定性时，使用 [[D20]] 进行检定
- 10+ 为成功，15+ 为大成功，5- 为失败
- 注重角色发展和故事深度
- 灵活适应玩家的选择和创意`}};var d=r(13707),m=r(97669);class g{getNPC(e,t){return this.npcs.get(`${e}:${t}`)}setNPC(e,t){this.npcs.set(`${e}:${t.id}`,t)}updateAttitude(e,t,r){let s=`${e}:${t}`,a=this.npcs.get(s);a&&(a.attitude=Math.max(-100,Math.min(100,a.attitude+r)))}getAllNPCs(e){let t=`${e}:`;return Array.from(this.npcs.values()).filter(e=>e.id.startsWith(t))}constructor(){this.npcs=new Map}}new g;let E="force-dynamic";async function _(e,{params:t}){try{let{id:r}=await t,{searchParams:s}=new URL(e.url),a=Math.min(parseInt(s.get("limit")||"50"),100),n=s.get("before"),i=p.default.prepare(`
      SELECT c.*,
        (SELECT COUNT(*) FROM rpg_campaign_members WHERE campaign_id = c.id) as player_count
      FROM rpg_campaigns c WHERE c.id = ?
    `).get(r);if(!i)return o.NextResponse.json({success:!1,error:"战役不存在"},{status:404});let c=p.default.prepare(`
      SELECT * FROM rpg_sessions WHERE campaign_id = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1
    `).get(r),l=`
      SELECT m.*, u.username
      FROM rpg_messages m
      LEFT JOIN users u ON m.user_id = u.id
      WHERE m.campaign_id = ?
    `,u=[r];n&&(l+=" AND m.created_at < (SELECT created_at FROM rpg_messages WHERE id = ?)",u.push(n)),l+=" ORDER BY m.created_at DESC LIMIT ?",u.push(a);let d=p.default.prepare(l).all(...u);d.reverse();let m=d.length===a&&d.length>0,g=m?d[0].id:null,E=p.default.prepare(`
      SELECT cm.*, u.username, u.nickname, rc.name as character_name, rc.avatar_url
      FROM rpg_campaign_members cm
      LEFT JOIN users u ON cm.user_id = u.id
      LEFT JOIN rpg_characters rc ON cm.character_id = rc.id
      WHERE cm.campaign_id = ?
    `).all(r),_=null;if(i.lorebook_id){let e=p.default.prepare("SELECT name, description, entries FROM rpg_lorebooks WHERE id = ?").get(i.lorebook_id);if(e){let t=0;try{t=JSON.parse(e.entries||"[]").length}catch{}_={id:i.lorebook_id,name:e.name,entry_count:t}}}let f=null;try{p.default.exec(`CREATE TABLE IF NOT EXISTS rpg_campaign_state (
        id TEXT PRIMARY KEY, campaign_id TEXT NOT NULL UNIQUE,
        variables TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )`);let e=p.default.prepare("SELECT variables FROM rpg_campaign_state WHERE campaign_id = ?").get(r);e&&(f=JSON.parse(e.variables||"{}"))}catch{}return o.NextResponse.json({success:!0,data:{...i,session:c,messages:d,members:E,lorebook:_,campaignState:f,pagination:{hasMore:m,nextCursor:g,limit:a}}})}catch(e){return console.error("Get campaign error:",e),o.NextResponse.json({success:!1,error:"获取战役失败"},{status:500})}}async function f(e,{params:t}){try{let r=(0,l.Vc)(e);if(r instanceof Response)return o.NextResponse.json({success:!1,error:"请先登录"},{status:401});let{id:s}=await t,{action:a,characterId:n,fateActionType:i,fateDifficulty:g}=await e.json(),E=p.default.prepare(`
      SELECT c.*, s.id as session_id
      FROM rpg_campaigns c
      LEFT JOIN rpg_sessions s ON s.campaign_id = c.id AND s.status = 'active'
      WHERE c.id = ?
    `).get(s);if(!E)return o.NextResponse.json({success:!1,error:"战役不存在"},{status:404});let _=E.created_by===r.userId,f=p.default.prepare("SELECT 1 FROM rpg_campaign_members WHERE campaign_id = ? AND user_id = ?").get(s,r.userId);if(!_&&!f)return o.NextResponse.json({success:!1,error:"无权访问此副本"},{status:403});let R=null,h=null,T=i||function(e){if(!e)return null;let t=e.toLowerCase();for(let[e,r]of[["combat_attack",/攻击|战斗|砍|刺|射击|开火|施法攻击/],["combat_defend",/防御|格挡|闪避|躲避|护盾/],["persuade_neutral",/说服|劝说|请求|商量/],["persuade_hostile",/威胁|恐吓|逼迫|命令/],["deceive",/欺骗|撒谎|伪装|隐瞒|冒充/],["bargain",/砍价|讲价|还价|交易|购买|出售/],["stealth",/潜行|偷偷|悄悄地|隐藏|躲藏/],["search",/搜索|寻找|查找|搜寻|翻找/],["perception",/观察|察觉|注意|发现|聆听/],["trap_detect",/陷阱|机关|埋伏/],["lockpick",/开锁|撬锁|解锁/],["climb",/爬|攀爬|翻越|攀登/],["healing",/治疗|包扎|急救|治愈|恢复/],["knowledge",/知道|了解|认识|熟悉|回忆/],["survival",/生存|追踪|觅食|野外/],["breakthrough_minor",/修炼|冥想|运功|突破小境界/],["breakthrough_major",/筑基|金丹|元婴|突破大境界|渡劫/],["alchemy",/炼丹|炼药|制药/],["crafting",/炼器|打造|锻造|制作/],["intimidate",/威吓|震慑|恐吓/]])if(r.test(t))return e;return null}(a);if(n&&T)try{R=(0,m.Sp)({actionType:T,characterId:n,campaignId:s,difficulty:g});try{h=(0,m.Rm)(n,R)}catch(e){console.warn("State update failed:",e)}}catch(e){console.warn("Fate check failed:",e)}let N=(0,c.Z)();p.default.prepare(`
      INSERT INTO rpg_messages (id, campaign_id, session_id, user_id, character_id, role, content, msg_type)
      VALUES (?, ?, ?, ?, ?, 'player', ?, 'action')
    `).run(N,s,E.session_id||"",r.userId,n||null,a);let y=p.default.prepare(`
      SELECT role, content, msg_type FROM rpg_messages
      WHERE campaign_id = ? ORDER BY created_at DESC LIMIT 20
    `).all(s),L=null;if(n){let e=p.default.prepare("SELECT card_data FROM rpg_characters WHERE id = ?").get(n);if(e)try{L=JSON.parse(e.card_data)}catch{}}let $=u[E.system]||u.custom,O=function(e){let{preset:t,campaign:r,characterCard:s,fateResult:a,stateUpdate:n}=e,i=t.systemPrompt;if(r.world_brief&&(i+=`

## 世界设定
${r.world_brief}`),s){if(i+=`

## 玩家角色
名称: ${s.name}
描述: ${s.description}
`,s.personality&&(i+=`性格: ${s.personality}
`),s.trpg){if(i+=`等级: ${s.trpg.level||1}
`,s.trpg.attributes){let e=Object.entries(s.trpg.attributes).map(([e,t])=>`${e}:${t}`).join(", ");i+=`属性: ${e}
`}if(s.trpg.hp&&(i+=`HP: ${s.trpg.hp.current}/${s.trpg.hp.max}
`),s.trpg.mp&&(i+=`MP: ${s.trpg.mp.current}/${s.trpg.mp.max}
`),s.trpg.san&&(i+=`SAN: ${s.trpg.san.current}/${s.trpg.san.max}
`),s.trpg.equipment?.length>0&&(i+=`装备: ${s.trpg.equipment.join(", ")}
`),s.trpg.backstory&&(i+=`背景故事: ${s.trpg.backstory}
`),s.trpg.dynamic_state){let e=s.trpg.dynamic_state;void 0!==e.reputation&&(i+=`声望: ${e.reputation}
`),e.cultivation?.realm&&(i+=`修为: ${e.cultivation.realm}
`),void 0!==e.resources&&(i+=`资源: ${e.resources}
`)}if(s.trpg.flags){let e=Object.entries(s.trpg.flags).filter(([e,t])=>t).map(([e,t])=>"boolean"==typeof t?e:`${e}:${t}`).join(", ");e&&(i+=`当前状态标记: ${e}
`)}}i+=`
请根据以上角色设定，以第二人称"你"称呼玩家。`}else i+=`

玩家尚未创建正式角色，请根据对话逐渐了解并称呼他们。`;return a&&(i+=function(e,t){let r=`

## 命运判定结果（系统自动计算，请据此生成叙事）
`;if(r+=`- 判定结果: ${({critical_success:"大成功（额外正面效果）",success:"成功",mixed:"勉强成功/代价成功",failure:"失败",critical_failure:"大失败（额外负面效果）"})[e.degree]||e.degree}
- 成功率: ${e.finalRate}%（掷骰: ${e.roll}）
`,e.breakdown.playerMods?.length>0){let t=e.breakdown.playerMods.map(e=>`${e.source}(+${e.value})`).join("、");r+=`- 玩家修正: ${t}
`}if(e.breakdown.worldMods?.length>0){let t=e.breakdown.worldMods.map(e=>`${e.source}(${e.value>0?"+":""}${e.value})`).join("、");r+=`- 世界修正: ${t}
`}return r+=`
重要：请根据以上判定结果生成叙事。`,"critical_success"===e.degree?r+=`行动获得了超出预期的成功，应在叙事中体现额外的正面效果。`:"critical_failure"===e.degree&&(r+=`行动遭遇了严重失败，应在叙事中体现额外的负面后果。`),t&&t.summary&&(r+=`
- 状态变化: ${t.summary}`),r}(a,n)),i+=`

## 输出格式要求
- 使用生动的叙事语言描述场景和事件
- 当需要玩家做决定时，给出 2-3 个清晰的选择
- 当需要掷骰判定时，使用 [[D20+N]] 或 [[D100]] 格式标记，引擎会自动解析
- 保持回复在 200-500 字之间
- 推动剧情发展，但不要替玩家做决定`}({preset:$,campaign:{world_brief:E.world_brief,system:E.system},characterCard:L,fateResult:R,stateUpdate:h}),S=[{role:"system",content:O},...y.reverse().map(e=>({role:"gm"===e.role?"assistant":"user",content:e.content})),{role:"user",content:a}],x=process.env.DEEPSEEK_API_KEY;if(!x){let e=`*${$.name}的 GM 点了点头，若有所思地看着你。*

"你的行动已被记录，但 AI 引擎尚未配置完成。请设置 DEEPSEEK_API_KEY 环境变量以启用完整 AI GM 体验。"

*(提示: 当前为降级模式，仅记录你的行动)*`,t=(0,c.Z)();return p.default.prepare(`
        INSERT INTO rpg_messages (id, campaign_id, session_id, user_id, role, content, msg_type)
        VALUES (?, ?, ?, NULL, 'gm', ?, 'narrative')
      `).run(t,s,E.session_id||"",e),o.NextResponse.json({success:!0,data:{message:{id:t,role:"gm",content:e,msg_type:"narrative"},diceRolls:[],fateResult:R,stateUpdate:h}})}let D=process.env.LLM_BASE_URL||"https://api.deepseek.com/chat/completions",I=process.env.LLM_MODEL||"deepseek-chat",M=await fetch(D,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${x}`},body:JSON.stringify({model:I,max_tokens:1024,temperature:.9,messages:S})});if(!M.ok){let e=await M.text();return console.error("DeepSeek API error:",e),o.NextResponse.json({success:!1,error:"AI GM 暂时无法响应"},{status:502})}let b=await M.json(),v=b.choices?.[0]?.message?.content||"",{cleanText:A,rolls:j}=(0,d.k)(v),w=(0,c.Z)();for(let e of(p.default.prepare(`
      INSERT INTO rpg_messages (id, campaign_id, session_id, user_id, role, content, msg_type, dice_result)
      VALUES (?, ?, ?, NULL, 'gm', ?, 'narrative', ?)
    `).run(w,s,E.session_id||"",A,j.length>0?JSON.stringify(j):null),j))p.default.prepare(`
        INSERT INTO rpg_dice_rolls (id, campaign_id, session_id, user_id, character_id, expression, result, details, note)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run((0,c.Z)(),s,E.session_id||"",r.userId,n||null,e.expression,e.total,e.detail,"AI GM 自动掷骰");return o.NextResponse.json({success:!0,data:{message:{id:w,role:"gm",content:A,msg_type:"narrative",dice_result:j.length>0?JSON.stringify(j):null},diceRolls:j,fateResult:R,stateUpdate:h}})}catch(e){return console.error("AI GM action error:",e),o.NextResponse.json({success:!1,error:"AI GM 处理失败"},{status:500})}}async function R(e,{params:t}){try{if((0,l.Vc)(e) instanceof Response)return o.NextResponse.json({success:!1,error:"请先登录"},{status:401});let{id:r}=await t,s=await e.json(),a=p.default.prepare(`
      SELECT * FROM rpg_sessions WHERE campaign_id = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1
    `).get(r),n=p.default.prepare(`
      SELECT role, content, msg_type, dice_result FROM rpg_messages
      WHERE campaign_id = ? ORDER BY created_at ASC
    `).all(r),i=(0,c.Z)();return p.default.prepare(`
      INSERT INTO rpg_archives (id, campaign_id, session_id, title, content, token_count)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(i,r,a?.id||"",s.title||`存档 ${new Date().toLocaleString("zh-CN")}`,JSON.stringify({messages:n,state:s.state||{}}),0),o.NextResponse.json({success:!0,data:{id:i}})}catch(e){return console.error("Save campaign error:",e),o.NextResponse.json({success:!1,error:"存档失败"},{status:500})}}async function h(e,{params:t}){try{let r=(0,l.Vc)(e);if(r instanceof Response)return o.NextResponse.json({success:!1,error:"请先登录"},{status:401});let{id:s}=await t,a=p.default.prepare("SELECT id, created_by FROM rpg_campaigns WHERE id = ?").get(s);if(!a)return o.NextResponse.json({success:!1,error:"副本不存在"},{status:404});if(a.created_by!==r.userId)return o.NextResponse.json({success:!1,error:"无权删除此副本"},{status:403});let n=p.default.prepare("SELECT COUNT(*) as c FROM rpg_campaign_members WHERE campaign_id = ?").get(s);if(n.c>0)return o.NextResponse.json({success:!1,error:`该副本还有 ${n.c} 名成员，请先移除所有成员后再删除`},{status:409});p.default.prepare("UPDATE rpg_market_listings SET status = 'cancelled' WHERE asset_id = ? AND asset_type = 'campaign'").run(s),p.default.prepare('DELETE FROM rpg_asset_library WHERE asset_id = ? AND asset_type = "campaign"').run(s),p.default.prepare("DELETE FROM rpg_dice_rolls WHERE campaign_id = ?").run(s),p.default.prepare("DELETE FROM rpg_messages WHERE campaign_id = ?").run(s),p.default.prepare("DELETE FROM rpg_sessions WHERE campaign_id = ?").run(s),p.default.prepare("DELETE FROM rpg_archives WHERE campaign_id = ?").run(s);try{p.default.prepare("DELETE FROM rpg_campaign_state WHERE campaign_id = ?").run(s)}catch{}return p.default.prepare("DELETE FROM rpg_campaign_members WHERE campaign_id = ?").run(s),p.default.prepare("DELETE FROM rpg_campaigns WHERE id = ?").run(s),o.NextResponse.json({success:!0})}catch(e){return console.error("Delete campaign error:",e),o.NextResponse.json({success:!1,error:"删除副本失败"},{status:500})}}let T=new a.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/rpg/campaigns/[id]/route",pathname:"/api/rpg/campaigns/[id]",filename:"route",bundlePath:"app/api/rpg/campaigns/[id]/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\rpg\\campaigns\\[id]\\route.ts",nextConfigOutput:"standalone",userland:s}),{requestAsyncStorage:N,staticGenerationAsyncStorage:y,serverHooks:L}=T,$="/api/rpg/campaigns/[id]/route";function O(){return(0,i.patchFetch)({serverHooks:L,staticGenerationAsyncStorage:y})}},13707:(e,t,r)=>{function s(e){let t;let r=e.trim().toUpperCase(),s=r,a=r.match(/^(.+?)>(\d+)$/);a&&(s=a[1].trim(),t=parseInt(a[2],10));let n=0,i=s,o=s.match(/^(.+?)([+-]\d+)$/);o&&(i=o[1].trim(),n=parseInt(o[2],10));let c=i.match(/^(\d+)?[Dd](\d+)$/);if(!c){let r=parseInt(i,10);if(!isNaN(r)){let s=r+n;return{expression:e,results:[r],modifier:n,total:s,detail:`${s}`,success:void 0!==t?s>=t:void 0,successThreshold:t}}throw Error(`无法解析骰子表达式: ${e}`)}let p=parseInt(c[1]||"1",10),l=parseInt(c[2],10);if(p<1||p>100)throw Error(`骰子数量超出范围 (1-100): ${p}`);if(l<2||l>1e3)throw Error(`骰子面数超出范围 (2-1000): ${l}`);let u=[];for(let e=0;e<p;e++)u.push(Math.floor(Math.random()*l)+1);let d=[...u],m=r.match(/(\d+)[Dd]\d+[Kk](\d+)/),g=r.match(/(\d+)[Dd]\d+[Dd](\d+)/);if(m&&s.includes("K")){let e=parseInt(m[2],10);d=u.sort((e,t)=>t-e).slice(0,e)}else if(g&&s.includes("D")){let e=parseInt(g[2],10);d=u.sort((e,t)=>e-t).slice(e)}let E=d.reduce((e,t)=>e+t,0)+n,_=d.map(String),f=0!==n?`${E} (${_.join("+")}${n>=0?"+":""}${n})`:`${E} (${_.join("+")})`;return{expression:e,results:d,modifier:n,total:E,detail:f,success:void 0!==t?E>=t:void 0,successThreshold:t}}function a(e){let t=[];return{cleanText:e.replace(/\[\[([\s\S]*?)\]\]/g,(e,r)=>{try{let e=s(r.trim());return t.push(e),`**🎲 ${e.detail}**`}catch{return`[${r}]`}}),rolls:t}}function n(e){let t=`🎲 ${e.expression} → **${e.total}**`;return e.results.length>1&&(t+=` (${e.results.join(", ")})`),0!==e.modifier&&(t+=` 调整值: ${e.modifier>=0?"+":""}${e.modifier}`),void 0!==e.success&&(t+=e.success?" ✅ **成功!**":" ❌ **失败!**"),t}r.d(t,{EA:()=>n,Vf:()=>s,k:()=>a})},9576:(e,t,r)=>{r.d(t,{Z:()=>p});var s=r(84770),a=r.n(s);let n={randomUUID:a().randomUUID},i=new Uint8Array(256),o=i.length,c=[];for(let e=0;e<256;++e)c.push((e+256).toString(16).slice(1));let p=function(e,t,r){if(n.randomUUID&&!t&&!e)return n.randomUUID();let s=(e=e||{}).random||(e.rng||function(){return o>i.length-16&&(a().randomFillSync(i),o=0),i.slice(o,o+=16)})();if(s[6]=15&s[6]|64,s[8]=63&s[8]|128,t){r=r||0;for(let e=0;e<16;++e)t[r+e]=s[e];return t}return function(e,t=0){return c[e[t+0]]+c[e[t+1]]+c[e[t+2]]+c[e[t+3]]+"-"+c[e[t+4]]+c[e[t+5]]+"-"+c[e[t+6]]+c[e[t+7]]+"-"+c[e[t+8]]+c[e[t+9]]+"-"+c[e[t+10]]+c[e[t+11]]+c[e[t+12]]+c[e[t+13]]+c[e[t+14]]+c[e[t+15]]}(s)}}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[8948,7070,6944,3235,9487,3584],()=>r(78580));module.exports=s})();