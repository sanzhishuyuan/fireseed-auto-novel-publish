"use strict";(()=>{var e={};e.id=8834,e.ids=[8834],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},17015:(e,t,a)=>{a.r(t),a.d(t,{originalPathname:()=>R,patchFetch:()=>C,requestAsyncStorage:()=>p,routeModule:()=>E,serverHooks:()=>O,staticGenerationAsyncStorage:()=>_});var r={};a.r(r),a.d(r,{GET:()=>c,dynamic:()=>u});var s=a(49303),i=a(88716),o=a(60670),n=a(46267),d=a(71299),l=a(9487);let u="force-dynamic",c=(0,n.l)({auth:"admin",permission:"skill.manage"},async(e,t)=>{let a=l.default.prepare("SELECT * FROM skill_missions ORDER BY priority ASC").all(),r=l.default.prepare("SELECT COUNT(*) as c FROM skill_activations").get().c,s=l.default.prepare("SELECT COUNT(*) as c FROM skill_activations WHERE date(created_at) = date('now')").get().c,i=l.default.prepare("SELECT COUNT(*) as c FROM skill_activations WHERE created_at >= datetime('now', '-7 days')").get().c,o=l.default.prepare(`
    SELECT skill_version as version, COUNT(*) as count FROM skill_activations GROUP BY skill_version ORDER BY count DESC
  `).all(),n=l.default.prepare(`
    SELECT sa.*, u.username FROM skill_activations sa
    LEFT JOIN users u ON sa.user_id = u.id
    ORDER BY sa.created_at DESC LIMIT 50
  `).all(),u=l.default.prepare("SELECT COUNT(*) as c FROM users").get().c,c=l.default.prepare("SELECT COUNT(DISTINCT author_id) as c FROM novels WHERE author_id IS NOT NULL AND deleted_at IS NULL").get().c,E=l.default.prepare("SELECT COUNT(*) as c FROM skill_events WHERE date(created_at) = date('now')").get().c,p=l.default.prepare("SELECT COUNT(*) as c FROM novels WHERE deleted_at IS NULL").get().c,_=l.default.prepare(`
    SELECT 
      u.id, u.username, u.nickname, u.created_at as registered_at,
      MAX(u_act.last_time) as last_activation_at,
      (SELECT MAX(created_at) FROM novels WHERE author_id = u.id AND deleted_at IS NULL) as last_novel_at,
      COALESCE(u_act.cnt, 0) as activation_count,
      (SELECT COUNT(*) FROM novels WHERE author_id = u.id AND deleted_at IS NULL) as novels_count,
      (SELECT GROUP_CONCAT(substr(title, 1, 30), ' | ') FROM novels WHERE author_id = u.id AND deleted_at IS NULL ORDER BY created_at DESC) as novel_titles
    FROM users u
    LEFT JOIN (
      SELECT user_id, MAX(created_at) as last_time, COUNT(*) as cnt
      FROM skill_activations GROUP BY user_id
    ) u_act ON u.id = u_act.user_id
    WHERE 
      u_act.user_id IS NOT NULL 
      OR EXISTS (SELECT 1 FROM novels WHERE author_id = u.id AND deleted_at IS NULL)
    GROUP BY u.id
    ORDER BY 
      COALESCE(u_act.last_time, (SELECT MAX(created_at) FROM novels WHERE author_id = u.id AND deleted_at IS NULL)) DESC,
      novels_count DESC
    LIMIT 100
  `).all();return(0,d.L)({missions:a,activationStats:{total:r,today:s,this_week:i,by_version:o,recent:n,totalUsers:u,authorsWithNovels:c,eventsToday:E},activeUsers:_,conversion:{totalUsers:u,usersWithNovels:c,totalNovels:p,conversionRate:u>0?(c/u*100).toFixed(1):"0.0"}})}),E=new s.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/admin/skill-dashboard/route",pathname:"/api/admin/skill-dashboard",filename:"route",bundlePath:"app/api/admin/skill-dashboard/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\admin\\skill-dashboard\\route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:p,staticGenerationAsyncStorage:_,serverHooks:O}=E,R="/api/admin/skill-dashboard/route";function C(){return(0,o.patchFetch)({serverHooks:O,staticGenerationAsyncStorage:_})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[8948,7070,6944,1203,9487,6267],()=>a(17015));module.exports=r})();