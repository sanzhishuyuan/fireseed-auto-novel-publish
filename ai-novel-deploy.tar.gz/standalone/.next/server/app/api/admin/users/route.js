"use strict";(()=>{var e={};e.id=2628,e.ids=[2628],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},64476:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>h,patchFetch:()=>q,requestAsyncStorage:()=>E,routeModule:()=>m,serverHooks:()=>g,staticGenerationAsyncStorage:()=>x});var a={};t.r(a),t.d(a,{GET:()=>c,dynamic:()=>d});var s=t(49303),n=t(88716),i=t(60670),u=t(46267),o=t(71299),p=t(9487),l=t(95343);let d="force-dynamic",c=(0,u.l)({auth:"admin",permission:"admin.manage"},async(e,r)=>{let{searchParams:t}=new URL(e.url),a=t.get("search")||"",s=t.get("role")||"",n=parseInt(t.get("page")||"1"),i=Math.min(parseInt(t.get("limit")||"50"),200),u=(n-1)*i,d=[],c=[];a&&(d.push("(u.username LIKE ? OR u.nickname LIKE ?)"),c.push(`%${a}%`,`%${a}%`)),s&&(d.push("u.role = ?"),c.push(s));let m=d.length>0?"WHERE "+d.join(" AND "):"",E=p.default.prepare(`SELECT COUNT(*) as count FROM users u ${m}`).get(...c).count,x=p.default.prepare(`
    SELECT
      u.id,
      u.username,
      u.nickname,
      u.role,
      u.created_at,
      (SELECT COUNT(*) FROM novels WHERE author_id = u.id AND deleted_at IS NULL) as novels_count
    FROM users u
    ${m}
    ORDER BY
      CASE u.role
        WHEN 'super_admin' THEN 0
        WHEN 'admin' THEN 1
        WHEN 'editor' THEN 2
        WHEN 'viewer' THEN 3
        ELSE 4
      END,
      u.created_at DESC
    LIMIT ? OFFSET ?
  `).all(...c,i,u).map(e=>({id:e.id,username:e.username,nickname:e.nickname||e.username,role:e.role,roleLabel:l.Sx[e.role]||e.role,novelsCount:e.novels_count,registeredAt:e.created_at}));return(0,o.L)({users:x,total:E,page:n,limit:i,totalPages:Math.ceil(E/i)})}),m=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/admin/users/route",pathname:"/api/admin/users",filename:"route",bundlePath:"app/api/admin/users/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\admin\\users\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:E,staticGenerationAsyncStorage:x,serverHooks:g}=m,h="/api/admin/users/route";function q(){return(0,i.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:x})}}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[8948,7070,6944,1203,9487,6267],()=>t(64476));module.exports=a})();