"use strict";(()=>{var e={};e.id=4673,e.ids=[4673],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},20385:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>m,patchFetch:()=>x,requestAsyncStorage:()=>c,routeModule:()=>l,serverHooks:()=>_,staticGenerationAsyncStorage:()=>E});var a={};t.r(a),t.d(a,{GET:()=>d});var s=t(49303),i=t(88716),u=t(60670),n=t(9487),o=t(46267),p=t(71299);let d=(0,o.l)({auth:"user"},async(e,r)=>{let t=n.default.prepare(`
    SELECT total_uses, successful_uses
    FROM referral_codes WHERE user_id = ?
  `).get(r.user.id),a=t?.total_uses||0,s=t?.successful_uses||0,i=n.default.prepare(`
    SELECT COALESCE(SUM(amount), 0) as total
    FROM tokens
    WHERE user_id = ? AND reason LIKE '推广奖励%'
  `).get(r.user.id),u=n.default.prepare(`
    SELECT date(created_at) as day, COUNT(*) as count
    FROM referral_redemptions
    WHERE referrer_id = ? AND status = 'completed'
      AND created_at >= date('now', '-30 days')
    GROUP BY date(created_at)
    ORDER BY day
  `).all(r.user.id),o=n.default.prepare(`
    SELECT rr.id, rr.created_at, rr.status, rr.reward_given,
           u.username as new_user_name
    FROM referral_redemptions rr
    LEFT JOIN users u ON rr.new_user_id = u.id
    WHERE rr.referrer_id = ?
    ORDER BY rr.created_at DESC
    LIMIT 20
  `).all(r.user.id),d=n.default.prepare(`
    SELECT vip_type, vip_expires_at
    FROM users WHERE id = ?
  `).get(r.user.id),l=1;return"monthly"===d.vip_type?l=1.5:"yearly"===d.vip_type&&(l=2),(0,p.L)({totalUses:a,successfulUses:s,totalEarnings:i.total,bonusMultiplier:l,vipBonusActive:l>1,trend:u,recentRedemptions:o.map(e=>({id:e.id,newUserName:e.new_user_name,status:e.status,rewardGiven:e.reward_given,createdAt:e.created_at}))})}),l=new s.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/referral/stats/route",pathname:"/api/referral/stats",filename:"route",bundlePath:"app/api/referral/stats/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\referral\\stats\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:c,staticGenerationAsyncStorage:E,serverHooks:_}=l,m="/api/referral/stats/route";function x(){return(0,u.patchFetch)({serverHooks:_,staticGenerationAsyncStorage:E})}}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[8948,7070,6944,1203,9487,6267],()=>t(20385));module.exports=a})();