"use strict";(()=>{var e={};e.id=2603,e.ids=[2603],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},40827:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>x,patchFetch:()=>m,requestAsyncStorage:()=>c,routeModule:()=>_,serverHooks:()=>E,staticGenerationAsyncStorage:()=>f});var a={};t.r(a),t.d(a,{POST:()=>l});var i=t(49303),s=t(88716),n=t(60670),u=t(9487),p=t(9576),o=t(46267),d=t(71299);let l=(0,o.l)({auth:"none",body:!0},async(e,r)=>{let{code:t,newUserId:a}=r.body;if(!t||!a)return(0,d.q)("VALIDATION_REQUIRED","参数不完整",400);let i=u.default.prepare(`
    SELECT id, user_id, code, successful_uses
    FROM referral_codes
    WHERE code = ? AND is_active = 1
  `).get(t);if(!i)return(0,d.q)("NOT_FOUND","无效的推广码",404);if(i.user_id===a)return(0,d.q)("VALIDATION_SELF_REFERRAL","不能使用自己的推广码",400);if(u.default.prepare(`
    SELECT id FROM referral_redemptions
    WHERE new_user_id = ?
  `).get(a))return(0,d.q)("ALREADY_REDEEMED","该用户已使用过推广码",400);let s=u.default.prepare(`
    SELECT vip_type, vip_expires_at
    FROM users WHERE id = ?
  `).get(i.user_id),n=1;"monthly"===s.vip_type&&s.vip_expires_at?new Date(s.vip_expires_at)>new Date&&(n=1.5):"yearly"===s.vip_type&&s.vip_expires_at&&new Date(s.vip_expires_at)>new Date&&(n=2);let o=Math.floor(50*n),l=(0,p.Z)();return u.default.transaction(()=>{u.default.prepare(`
      INSERT INTO tokens (id, user_id, type, amount, reason, created_at)
      VALUES (?, ?, 'credit', ?, ?, CURRENT_TIMESTAMP)
    `).run((0,p.Z)(),i.user_id,o,`推广奖励(x${n}): ${t}`),u.default.prepare(`
      INSERT INTO tokens (id, user_id, type, amount, reason, created_at)
      VALUES (?, ?, 'credit', ?, ?, CURRENT_TIMESTAMP)
    `).run((0,p.Z)(),a,30,`注册推广奖励: ${t}`),u.default.prepare(`
      INSERT INTO referral_redemptions (id, referral_code, referrer_id, new_user_id, status, reward_given)
      VALUES (?, ?, ?, ?, 'completed', ?)
    `).run(l,t,i.user_id,a,o+30),u.default.prepare(`
      UPDATE referral_codes
      SET total_uses = total_uses + 1, successful_uses = successful_uses + 1
      WHERE id = ?
    `).run(i.id),u.default.prepare(`
      UPDATE users
      SET referral_count = referral_count + 1,
          referral_earnings = referral_earnings + ?
      WHERE id = ?
    `).run(o,i.user_id);let e=new Date;e.setDate(e.getDate()+3),u.default.prepare(`
      UPDATE users
      SET vip_type = 'monthly', vip_expires_at = ?
      WHERE id = ? AND (vip_type = 'free' OR vip_expires_at IS NULL OR vip_expires_at < CURRENT_TIMESTAMP)
    `).run(e.toISOString(),a)})(),(0,d.L)({redemptionId:l,referrerReward:o,newUserReward:30,bonusMultiplier:n,vipTrialDays:3,code:t})}),_=new i.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/referral/redeem/route",pathname:"/api/referral/redeem",filename:"route",bundlePath:"app/api/referral/redeem/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\referral\\redeem\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:c,staticGenerationAsyncStorage:f,serverHooks:E}=_,x="/api/referral/redeem/route";function m(){return(0,n.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:f})}},9576:(e,r,t)=>{t.d(r,{Z:()=>o});var a=t(84770),i=t.n(a);let s={randomUUID:i().randomUUID},n=new Uint8Array(256),u=n.length,p=[];for(let e=0;e<256;++e)p.push((e+256).toString(16).slice(1));let o=function(e,r,t){if(s.randomUUID&&!r&&!e)return s.randomUUID();let a=(e=e||{}).random||(e.rng||function(){return u>n.length-16&&(i().randomFillSync(n),u=0),n.slice(u,u+=16)})();if(a[6]=15&a[6]|64,a[8]=63&a[8]|128,r){t=t||0;for(let e=0;e<16;++e)r[t+e]=a[e];return r}return function(e,r=0){return p[e[r+0]]+p[e[r+1]]+p[e[r+2]]+p[e[r+3]]+"-"+p[e[r+4]]+p[e[r+5]]+"-"+p[e[r+6]]+p[e[r+7]]+"-"+p[e[r+8]]+p[e[r+9]]+"-"+p[e[r+10]]+p[e[r+11]]+p[e[r+12]]+p[e[r+13]]+p[e[r+14]]+p[e[r+15]]}(a)}}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[8948,7070,6944,1203,9487,6267],()=>t(40827));module.exports=a})();