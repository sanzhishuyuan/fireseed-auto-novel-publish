"use strict";(()=>{var e={};e.id=1028,e.ids=[1028],e.modules={85890:e=>{e.exports=require("better-sqlite3")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},24230:(e,a,t)=>{t.r(a),t.d(a,{originalPathname:()=>m,patchFetch:()=>f,requestAsyncStorage:()=>_,routeModule:()=>d,serverHooks:()=>E,staticGenerationAsyncStorage:()=>g});var r={};t.r(r),t.d(r,{GET:()=>l,dynamic:()=>p});var n=t(49303),s=t(88716),i=t(60670),o=t(87070),u=t(9487),c=t(43422);let p="force-dynamic";async function l(e,{params:a}){try{let{id:e}=await a,t=u.default.prepare(`
      SELECT ua.id, ua.agent_name, ua.avatar_emoji, ua.personality, ua.bio,
        ua.status, ua.total_signals, ua.total_resonance, ua.energy_level,
        ua.created_at, ua.last_active_at,
        u.nickname as owner_nickname, u.username as owner_username
      FROM user_agents ua
      JOIN users u ON ua.user_id = u.id
      WHERE ua.id = ?
    `).get(e);if(!t)return o.NextResponse.json({success:!1,error:"代理不存在"},{status:404});try{t.personality=JSON.parse(t.personality)}catch{}let r=u.default.prepare(`
      SELECT id, room_id, content, reply_to, created_at
      FROM chat_messages
      WHERE agent_id = ? AND is_ai = 1
      ORDER BY created_at DESC LIMIT 20
    `).all(e),n=(0,c.$X)(e);return o.NextResponse.json({success:!0,agent:t,signals:r,connections:n})}catch(e){return console.error("Get agent public profile error:",e),o.NextResponse.json({success:!1,error:"获取代理信息失败"},{status:500})}}let d=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/agent/[id]/profile/route",pathname:"/api/agent/[id]/profile",filename:"route",bundlePath:"app/api/agent/[id]/profile/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\agent\\[id]\\profile\\route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:_,staticGenerationAsyncStorage:g,serverHooks:E}=d,m="/api/agent/[id]/profile/route";function f(){return(0,i.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:g})}},43422:(e,a,t)=>{t.d(a,{$X:()=>n,we:()=>s});var r=t(9487);function n(e){return r.default.prepare(`
    SELECT
      ac.*,
      CASE WHEN ac.agent_a = ? THEN ac.agent_b ELSE ac.agent_a END as other_agent_id,
      ua.agent_name as other_agent_name,
      ua.avatar_emoji as other_avatar_emoji
    FROM agent_connections ac
    JOIN user_agents ua ON (
      CASE WHEN ac.agent_a = ? THEN ac.agent_b ELSE ac.agent_a END
    ) = ua.id
    WHERE ac.agent_a = ? OR ac.agent_b = ?
    ORDER BY ac.affinity DESC
  `).all(e,e,e,e)}function s(e){return({acquaintance:"初识",friend:"朋友",close_friend:"密友",rival:"对手/拍档"})[e]||e}},49303:(e,a,t)=>{e.exports=t(30517)}};var a=require("../../../../../webpack-runtime.js");a.C(e);var t=e=>a(a.s=e),r=a.X(0,[8948,7070,9487],()=>t(24230));module.exports=r})();