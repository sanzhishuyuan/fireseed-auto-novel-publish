"use strict";(()=>{var e={};e.id=4070,e.ids=[4070],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},28637:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>T,patchFetch:()=>S,requestAsyncStorage:()=>E,routeModule:()=>c,serverHooks:()=>y,staticGenerationAsyncStorage:()=>m});var a={};r.r(a),r.d(a,{POST:()=>l});var n=r(49303),i=r(88716),o=r(60670),s=r(9487),p=r(9576),u=r(46267),d=r(71299);let l=(0,u.l)({auth:"user",body:!0},async(e,t)=>{let{amount:r,paymentMethod:a="wechat",description:n="VIP订阅"}=t.body;if(!r||r<=0)return(0,d.q)("VALIDATION_INVALID_PARAM","无效的金额",400);let i=`PAY${Date.now()}${Math.random().toString(36).substr(2,6)}`,o=(0,p.Z)();s.default.prepare(`
    INSERT INTO payment_transactions (
      id, user_id, order_no, amount, currency,
      payment_method, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, 'CNY', ?, 'pending', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
  `).run(o,t.user.id,i,r,a);let u={orderNo:i,amount:r,paymentMethod:a};if("wechat"===a)u.qrCodeUrl=`/api/payment/qrcode?order=${i}`,u.payUrl=`weixin://pay?order=${i}`;else if("alipay"===a)u.payUrl=`/api/payment/alipay?order=${i}`;else if("seed"===a){let e=s.default.prepare(`
      SELECT COALESCE(SUM(
        CASE WHEN type = 'credit' THEN amount
             WHEN type = 'debit' THEN -amount
             ELSE 0
        END
      ), 0) as balance
      FROM tokens
      WHERE user_id = ?
    `).get(t.user.id);if(!e||e.balance<r)return(0,d.q)("SEED_INSUFFICIENT","SEED 余额不足",400);s.default.prepare(`
      INSERT INTO tokens (id, user_id, type, amount, reason, created_at)
      VALUES (?, ?, 'debit', ?, ?, CURRENT_TIMESTAMP)
    `).run((0,p.Z)(),t.user.id,r,n),s.default.prepare(`
      UPDATE payment_transactions
      SET status = 'paid', paid_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
      WHERE order_no = ?
    `).run(i),u.paid=!0,u.paidAt=new Date().toISOString()}return(0,d.L)(u)}),c=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/payment/create/route",pathname:"/api/payment/create",filename:"route",bundlePath:"app/api/payment/create/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\payment\\create\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:E,staticGenerationAsyncStorage:m,serverHooks:y}=c,T="/api/payment/create/route";function S(){return(0,o.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:m})}},9576:(e,t,r)=>{r.d(t,{Z:()=>u});var a=r(84770),n=r.n(a);let i={randomUUID:n().randomUUID},o=new Uint8Array(256),s=o.length,p=[];for(let e=0;e<256;++e)p.push((e+256).toString(16).slice(1));let u=function(e,t,r){if(i.randomUUID&&!t&&!e)return i.randomUUID();let a=(e=e||{}).random||(e.rng||function(){return s>o.length-16&&(n().randomFillSync(o),s=0),o.slice(s,s+=16)})();if(a[6]=15&a[6]|64,a[8]=63&a[8]|128,t){r=r||0;for(let e=0;e<16;++e)t[r+e]=a[e];return t}return function(e,t=0){return p[e[t+0]]+p[e[t+1]]+p[e[t+2]]+p[e[t+3]]+"-"+p[e[t+4]]+p[e[t+5]]+"-"+p[e[t+6]]+p[e[t+7]]+"-"+p[e[t+8]]+p[e[t+9]]+"-"+p[e[t+10]]+p[e[t+11]]+p[e[t+12]]+p[e[t+13]]+p[e[t+14]]+p[e[t+15]]}(a)}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,7070,6944,1203,9487,6267],()=>r(28637));module.exports=a})();