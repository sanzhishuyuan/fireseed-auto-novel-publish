"use strict";(()=>{var e={};e.id=461,e.ids=[461],e.modules={85890:e=>{e.exports=require("better-sqlite3")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},79631:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>R,patchFetch:()=>f,requestAsyncStorage:()=>m,routeModule:()=>_,serverHooks:()=>y,staticGenerationAsyncStorage:()=>E});var a={};r.r(a),r.d(a,{GET:()=>l,POST:()=>c});var s=r(49303),n=r(88716),o=r(60670),u=r(87070),i=r(9487),p=r(9576),d=r(97032);async function c(e){try{let t=await e.text(),r=(0,d.N)(t);if(!r.success)return r.response;let{orderNo:a,transactionId:s,status:n="success"}=r.data;if(!a)return u.NextResponse.json({error:"订单号不能为空"},{status:400});let o=i.default.prepare(`
      SELECT id, user_id, order_no, amount, status
      FROM payment_transactions
      WHERE order_no = ?
    `).get(a);if(!o)return u.NextResponse.json({error:"订单不存在"},{status:404});if("paid"===o.status)return u.NextResponse.json({success:!0,message:"订单已支付"});if(i.default.prepare(`
      UPDATE payment_transactions
      SET status = 'paid',
          transaction_id = ?,
          paid_at = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP
      WHERE order_no = ?
    `).run(s||(0,p.Z)(),a),a.startsWith("VIP")){let e=i.default.prepare(`
        SELECT vip_type, vip_expires_at
        FROM users
        WHERE id = ?
      `).get(o.user_id),t="monthly";o.amount>=9900&&(t="yearly");let r=new Date,a=new Date(r);if("free"!==e.vip_type&&e.vip_expires_at){let t=new Date(e.vip_expires_at);t>r&&(a=t)}"monthly"===t?a.setMonth(a.getMonth()+1):a.setFullYear(a.getFullYear()+1);let n=(0,p.Z)();i.default.prepare(`
        INSERT INTO vip_subscriptions (
          id, user_id, plan_type, start_date, end_date,
          status, payment_method, amount, transaction_id, created_at, updated_at
        ) VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?, 'active', 'online', ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).run(n,o.user_id,t,a.toISOString(),o.amount,s||(0,p.Z)()),i.default.prepare(`
        UPDATE users
        SET vip_type = ?, vip_expires_at = ?
        WHERE id = ?
      `).run(t,a.toISOString(),o.user_id)}return u.NextResponse.json({success:!0,data:{orderNo:a,status:"paid",paidAt:new Date().toISOString()}})}catch(e){return console.error("Payment callback error:",e),u.NextResponse.json({error:"支付回调处理失败"},{status:500})}}async function l(e){try{let{searchParams:t}=new URL(e.url),r=t.get("orderNo");if(!r)return u.NextResponse.json({error:"订单号不能为空"},{status:400});let a=i.default.prepare(`
      SELECT id, user_id, order_no, amount, payment_method, status, paid_at, created_at
      FROM payment_transactions
      WHERE order_no = ?
    `).get(r);if(!a)return u.NextResponse.json({error:"订单不存在"},{status:404});return u.NextResponse.json({success:!0,data:{orderNo:a.order_no,amount:a.amount,paymentMethod:a.payment_method,status:a.status,paidAt:a.paid_at,createdAt:a.created_at}})}catch(e){return console.error("Payment query error:",e),u.NextResponse.json({error:"查询订单失败"},{status:500})}}let _=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/payment/callback/route",pathname:"/api/payment/callback",filename:"route",bundlePath:"app/api/payment/callback/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\payment\\callback\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:m,staticGenerationAsyncStorage:E,serverHooks:y}=_,R="/api/payment/callback/route";function f(){return(0,o.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:E})}},97032:(e,t,r)=>{r.d(t,{N:()=>s});var a=r(87070);function s(e){try{let t=JSON.parse(e);return{success:!0,data:t}}catch(e){if(e instanceof SyntaxError)return{success:!1,response:a.NextResponse.json({success:!1,error:"请求体格式错误",code:"INVALID_JSON"},{status:400})};throw e}}},49303:(e,t,r)=>{e.exports=r(30517)},9576:(e,t,r)=>{r.d(t,{Z:()=>p});var a=r(84770),s=r.n(a);let n={randomUUID:s().randomUUID},o=new Uint8Array(256),u=o.length,i=[];for(let e=0;e<256;++e)i.push((e+256).toString(16).slice(1));let p=function(e,t,r){if(n.randomUUID&&!t&&!e)return n.randomUUID();let a=(e=e||{}).random||(e.rng||function(){return u>o.length-16&&(s().randomFillSync(o),u=0),o.slice(u,u+=16)})();if(a[6]=15&a[6]|64,a[8]=63&a[8]|128,t){r=r||0;for(let e=0;e<16;++e)t[r+e]=a[e];return t}return function(e,t=0){return i[e[t+0]]+i[e[t+1]]+i[e[t+2]]+i[e[t+3]]+"-"+i[e[t+4]]+i[e[t+5]]+"-"+i[e[t+6]]+i[e[t+7]]+"-"+i[e[t+8]]+i[e[t+9]]+"-"+i[e[t+10]]+i[e[t+11]]+i[e[t+12]]+i[e[t+13]]+i[e[t+14]]+i[e[t+15]]}(a)}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,7070,9487],()=>r(79631));module.exports=a})();