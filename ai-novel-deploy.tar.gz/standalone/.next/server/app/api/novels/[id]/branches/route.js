"use strict";(()=>{var e={};e.id=9017,e.ids=[9017],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},95364:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>b,patchFetch:()=>R,requestAsyncStorage:()=>x,routeModule:()=>l,serverHooks:()=>E,staticGenerationAsyncStorage:()=>h});var a={};t.r(a),t.d(a,{GET:()=>d,dynamic:()=>p});var n=t(49303),s=t(88716),o=t(60670),i=t(87070),c=t(9487),u=t(46267);let p="force-dynamic",d=(0,u.l)({auth:"none"},async(e,r)=>{try{let{id:e}=r.params,t=c.default.prepare("SELECT id, deleted_at FROM novels WHERE id = ?").get(e);if(!t||t.deleted_at)return i.NextResponse.json({success:!1,branches:[]},{status:404});let a=c.default.prepare(`
      SELECT b.*,
        (SELECT COUNT(*) FROM chapters WHERE novel_id = ? AND branch = b.branch_name) as actual_chapter_count
      FROM branches b
      WHERE b.novel_id = ? AND b.status = 'active'
      ORDER BY b.created_at DESC
    `).all(e,e);for(let r of c.default.prepare(`
      SELECT DISTINCT branch FROM chapters
      WHERE novel_id = ? AND branch != 'main' AND branch NOT IN (
        SELECT branch_name FROM branches WHERE novel_id = ?
      )
    `).all(e,e)){let t=c.default.prepare(`
        SELECT id, title, author_id, author_name, created_at FROM chapters
        WHERE novel_id = ? AND branch = ? ORDER BY created_at ASC LIMIT 1
      `).get(e,r.branch);if(t){let n="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(e){let r=16*Math.random()|0;return("x"===e?r:3&r|8).toString(16)});c.default.prepare(`
          INSERT OR IGNORE INTO branches (id, novel_id, branch_name, title, author_id, author_name, chapter_count, total_words, created_at)
          VALUES (?, ?, ?, ?, ?, ?,
            (SELECT COUNT(*) FROM chapters WHERE novel_id = ? AND branch = ?),
            (SELECT COALESCE(SUM(word_count), 0) FROM chapters WHERE novel_id = ? AND branch = ?),
            ?)
        `).run(n,e,r.branch,r.branch,t.author_id,t.author_name,e,r.branch,e,r.branch,t.created_at);let s=c.default.prepare("SELECT * FROM branches WHERE id = ?").get(n);s&&a.push(s)}}return i.NextResponse.json({success:!0,branches:a})}catch(e){return console.error("Get branches error:",e),i.NextResponse.json({success:!0,branches:[]})}}),l=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/novels/[id]/branches/route",pathname:"/api/novels/[id]/branches",filename:"route",bundlePath:"app/api/novels/[id]/branches/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\novels\\[id]\\branches\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:x,staticGenerationAsyncStorage:h,serverHooks:E}=l,b="/api/novels/[id]/branches/route";function R(){return(0,o.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:h})}}};var r=require("../../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[8948,7070,6944,1203,9487,6267],()=>t(95364));module.exports=a})();