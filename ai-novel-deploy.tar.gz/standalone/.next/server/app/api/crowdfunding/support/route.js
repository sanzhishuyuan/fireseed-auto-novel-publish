"use strict";(()=>{var e={};e.id=5001,e.ids=[5001],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},70006:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>f,patchFetch:()=>T,requestAsyncStorage:()=>l,routeModule:()=>E,serverHooks:()=>_,staticGenerationAsyncStorage:()=>m});var n={};t.r(n),t.d(n,{POST:()=>c});var u=t(49303),a=t(88716),o=t(60670),i=t(9487),s=t(9576),d=t(46267),p=t(71299);let c=(0,d.l)({auth:"user",body:!0},async(e,r)=>{let{projectId:t,amount:n}=r.body;if(!t||!n||n<10)return(0,p.q)("VALIDATION_REQUIRED","最少支持10 SEED",400);let u=i.default.prepare(`
    SELECT id, author_id, target_amount, current_amount, deadline, status
    FROM crowdfunding_projects
    WHERE id = ?
  `).get(t);if(!u)return(0,p.q)("NOT_FOUND","众筹项目不存在",404);if("active"!==u.status)return(0,p.q)("PROJECT_ENDED","该项目已结束",400);if(new Date(u.deadline)<new Date)return(0,p.q)("PROJECT_EXPIRED","众筹已截止",400);if(u.author_id===r.user.id)return(0,p.q)("VALIDATION_SELF_SUPPORT","不能支持自己的项目",400);let a=i.default.prepare(`
    SELECT COALESCE(SUM(
      CASE WHEN type = 'credit' THEN amount
           WHEN type = 'debit' THEN -amount
           ELSE 0 END
    ), 0) as balance
    FROM tokens WHERE user_id = ?
  `).get(r.user.id);if(!a||a.balance<n)return(0,p.q)("SEED_INSUFFICIENT","SEED余额不足",400);i.default.transaction(()=>{i.default.prepare(`
      INSERT INTO tokens (id, user_id, type, amount, reason, created_at)
      VALUES (?, ?, 'debit', ?, ?, CURRENT_TIMESTAMP)
    `).run((0,s.Z)(),r.user.id,n,`支持众筹: ${t}`);let e=Math.floor(.1*n),a=n-e;i.default.prepare(`
      INSERT INTO tokens (id, user_id, type, amount, reason, created_at)
      VALUES (?, ?, 'credit', ?, ?, CURRENT_TIMESTAMP)
    `).run((0,s.Z)(),u.author_id,a,`众筹收入: ${t}`),e>0&&i.default.prepare(`
        INSERT INTO tokens (id, user_id, type, amount, reason, created_at)
        VALUES (?, ?, 'credit', ?, ?, CURRENT_TIMESTAMP)
      `).run((0,s.Z)(),"platform",e,`众筹平台费: ${t}`);let o=u.current_amount+n;i.default.prepare(`
      UPDATE crowdfunding_projects
      SET current_amount = ?, supporter_count = supporter_count + 1, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(o,t),i.default.prepare(`
      INSERT INTO crowdfunding_supporters (id, project_id, user_id, amount)
      VALUES (?, ?, ?, ?)
    `).run((0,s.Z)(),t,r.user.id,n)})();let o=Math.min(Math.round((u.current_amount+n)/u.target_amount*100),100),d=u.current_amount+n>=u.target_amount;return(0,p.L)({amount:n,newCurrentAmount:u.current_amount+n,progress:o,isFunded:d})}),E=new u.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/crowdfunding/support/route",pathname:"/api/crowdfunding/support",filename:"route",bundlePath:"app/api/crowdfunding/support/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\crowdfunding\\support\\route.ts",nextConfigOutput:"standalone",userland:n}),{requestAsyncStorage:l,staticGenerationAsyncStorage:m,serverHooks:_}=E,f="/api/crowdfunding/support/route";function T(){return(0,o.patchFetch)({serverHooks:_,staticGenerationAsyncStorage:m})}},9576:(e,r,t)=>{t.d(r,{Z:()=>d});var n=t(84770),u=t.n(n);let a={randomUUID:u().randomUUID},o=new Uint8Array(256),i=o.length,s=[];for(let e=0;e<256;++e)s.push((e+256).toString(16).slice(1));let d=function(e,r,t){if(a.randomUUID&&!r&&!e)return a.randomUUID();let n=(e=e||{}).random||(e.rng||function(){return i>o.length-16&&(u().randomFillSync(o),i=0),o.slice(i,i+=16)})();if(n[6]=15&n[6]|64,n[8]=63&n[8]|128,r){t=t||0;for(let e=0;e<16;++e)r[t+e]=n[e];return r}return function(e,r=0){return s[e[r+0]]+s[e[r+1]]+s[e[r+2]]+s[e[r+3]]+"-"+s[e[r+4]]+s[e[r+5]]+"-"+s[e[r+6]]+s[e[r+7]]+"-"+s[e[r+8]]+s[e[r+9]]+"-"+s[e[r+10]]+s[e[r+11]]+s[e[r+12]]+s[e[r+13]]+s[e[r+14]]+s[e[r+15]]}(n)}}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),n=r.X(0,[8948,7070,6944,1203,9487,6267],()=>t(70006));module.exports=n})();