"use strict";(()=>{var e={};e.id=2633,e.ids=[2633],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},49774:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>x,patchFetch:()=>f,requestAsyncStorage:()=>v,routeModule:()=>l,serverHooks:()=>c,staticGenerationAsyncStorage:()=>_});var i={};r.r(i),r.d(i,{GET:()=>d});var s=r(49303),a=r(88716),p=r(60670),n=r(9487),u=r(46267),o=r(71299);let d=(0,u.l)({auth:"user"},async(e,t)=>{let r=n.default.prepare(`
    SELECT id, username, nickname, vip_type, vip_expires_at, vip_auto_renew
    FROM users
    WHERE id = ?
  `).get(t.user.id);if(!r)return(0,o.q)("NOT_FOUND","用户不存在",404);let i=!1,s="free";"free"!==r.vip_type&&r.vip_expires_at&&((i=new Date(r.vip_expires_at)>new Date)?s=r.vip_type:(n.default.prepare(`
        UPDATE users
        SET vip_type = 'free', vip_expires_at = NULL, vip_auto_renew = 0
        WHERE id = ?
      `).run(t.user.id),s="free"));let a=n.default.prepare(`
    SELECT benefit_key, benefit_value, description
    FROM vip_benefits
    WHERE plan_type = ?
  `).all(s),p=n.default.prepare(`
    SELECT id, plan_type, start_date, end_date, status, payment_method, amount
    FROM vip_subscriptions
    WHERE user_id = ? AND status = 'active'
    ORDER BY created_at DESC
    LIMIT 1
  `).get(t.user.id);return(0,o.L)({vipType:s,isVipActive:i,vipExpiresAt:r.vip_expires_at,vipAutoRenew:1===r.vip_auto_renew,benefits:a.map(e=>({key:e.benefit_key,value:e.benefit_value,description:e.description})),subscription:p||null})}),l=new s.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/vip/status/route",pathname:"/api/vip/status",filename:"route",bundlePath:"app/api/vip/status/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\vip\\status\\route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:v,staticGenerationAsyncStorage:_,serverHooks:c}=l,x="/api/vip/status/route";function f(){return(0,p.patchFetch)({serverHooks:c,staticGenerationAsyncStorage:_})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[8948,7070,6944,1203,9487,6267],()=>r(49774));module.exports=i})();