"use strict";(()=>{var e={};e.id=4528,e.ids=[4528],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},2047:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>v,patchFetch:()=>b,requestAsyncStorage:()=>d,routeModule:()=>c,serverHooks:()=>x,staticGenerationAsyncStorage:()=>f});var i={};r.r(i),r.d(i,{GET:()=>u});var n=r(49303),a=r(88716),p=r(60670),s=r(9487),o=r(46267),l=r(71299);let u=(0,o.l)({auth:"none"},async(e,t)=>{let{searchParams:r}=new URL(e.url),i=r.get("planType")||"free",n=s.default.prepare(`
    SELECT benefit_key, benefit_value, description
    FROM vip_benefits
    WHERE plan_type = ?
    ORDER BY benefit_key
  `).all(i),a=s.default.prepare(`
    SELECT DISTINCT plan_type
    FROM vip_benefits
    ORDER BY plan_type
  `).all(),p={};for(let e of a){let t=s.default.prepare(`
      SELECT benefit_key, benefit_value, description
      FROM vip_benefits
      WHERE plan_type = ?
    `).all(e.plan_type);p[e.plan_type]=t.map(e=>({key:e.benefit_key,value:e.benefit_value,description:e.description}))}return(0,l.L)({currentPlan:i,benefits:n.map(e=>({key:e.benefit_key,value:e.benefit_value,description:e.description})),allPlans:p})}),c=new n.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/vip/benefits/route",pathname:"/api/vip/benefits",filename:"route",bundlePath:"app/api/vip/benefits/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\vip\\benefits\\route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:d,staticGenerationAsyncStorage:f,serverHooks:x}=c,v="/api/vip/benefits/route";function b(){return(0,p.patchFetch)({serverHooks:x,staticGenerationAsyncStorage:f})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[8948,7070,6944,1203,9487,6267],()=>r(2047));module.exports=i})();