"use strict";(()=>{var e={};e.id=6624,e.ids=[6624],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},55740:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>_,patchFetch:()=>g,requestAsyncStorage:()=>m,routeModule:()=>l,serverHooks:()=>v,staticGenerationAsyncStorage:()=>x});var a={};r.r(a),r.d(a,{GET:()=>c,POST:()=>d});var s=r(49303),n=r(88716),i=r(60670),p=r(9487),u=r(46267),o=r(71299);let d=(0,u.l)({auth:"user"},async(e,t)=>(p.default.prepare(`
    UPDATE users
    SET vip_auto_renew = 0
    WHERE id = ?
  `).run(t.user.id),p.default.prepare(`
    UPDATE vip_subscriptions
    SET status = 'cancelled'
    WHERE user_id = ? AND status = 'active'
  `).run(t.user.id),(0,o.L)({message:"已取消自动续费"}))),c=(0,u.l)({auth:"user"},async(e,t)=>{let r=p.default.prepare(`
    SELECT id, plan_type, start_date, end_date, status, payment_method, amount, created_at
    FROM vip_subscriptions
    WHERE user_id = ?
    ORDER BY created_at DESC
  `).all(t.user.id);return(0,o.L)({subscriptions:r.map(e=>({id:e.id,planType:e.plan_type,startDate:e.start_date,endDate:e.end_date,status:e.status,paymentMethod:e.payment_method,amount:e.amount,createdAt:e.created_at}))})}),l=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/vip/manage/route",pathname:"/api/vip/manage",filename:"route",bundlePath:"app/api/vip/manage/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\vip\\manage\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:m,staticGenerationAsyncStorage:x,serverHooks:v}=l,_="/api/vip/manage/route";function g(){return(0,i.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:x})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,7070,6944,1203,9487,6267],()=>r(55740));module.exports=a})();