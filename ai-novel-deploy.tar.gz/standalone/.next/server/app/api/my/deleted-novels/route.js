"use strict";(()=>{var e={};e.id=6320,e.ids=[6320],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},44579:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>_,patchFetch:()=>v,requestAsyncStorage:()=>m,routeModule:()=>E,serverHooks:()=>y,staticGenerationAsyncStorage:()=>x});var a={};r.r(a),r.d(a,{GET:()=>p,POST:()=>c,dynamic:()=>u});var n=r(49303),s=r(88716),d=r(60670),o=r(9487),i=r(46267),l=r(71299);let u="force-dynamic",p=(0,i.l)({auth:"user"},async(e,t)=>{let r=o.default.prepare(`
    SELECT id, title, author, deleted_at, retention_days,
      datetime(deleted_at, '+' || retention_days || ' days') as cleanup_date,
      CASE 
        WHEN datetime(deleted_at, '+' || retention_days || ' days') <= datetime('now') 
        THEN 1 ELSE 0 
      END as ready_to_cleanup
    FROM novels 
    WHERE author_id = ? AND deleted_at IS NOT NULL
    ORDER BY deleted_at DESC
  `).all(t.user.id);return(0,l.L)({novels:r,count:r.length})}),c=(0,i.l)({auth:"user",body:!0},async(e,t)=>{let{novel_id:r}=t.body;if(!r)return(0,l.q)("VALIDATION_REQUIRED","请提供小说ID",400);let a=o.default.prepare(`
    SELECT id, title, deleted_at 
    FROM novels 
    WHERE id = ? AND author_id = ? AND deleted_at IS NOT NULL
  `).get(r,t.user.id);return a?(o.default.prepare(`
    UPDATE novels 
    SET deleted_at = NULL, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(r),(0,l.L)({message:`《${a.title}》已恢复`,novel_id:r})):(0,l.q)("NOT_FOUND","小说不存在或无权恢复",404)}),E=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/my/deleted-novels/route",pathname:"/api/my/deleted-novels",filename:"route",bundlePath:"app/api/my/deleted-novels/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\my\\deleted-novels\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:m,staticGenerationAsyncStorage:x,serverHooks:y}=E,_="/api/my/deleted-novels/route";function v(){return(0,d.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:x})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,7070,6944,1203,9487,6267],()=>r(44579));module.exports=a})();