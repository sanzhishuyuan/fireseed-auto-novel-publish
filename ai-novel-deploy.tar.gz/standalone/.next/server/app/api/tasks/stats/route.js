"use strict";(()=>{var e={};e.id=6565,e.ids=[6565],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},20588:(e,t,a)=>{a.r(t),a.d(t,{originalPathname:()=>m,patchFetch:()=>v,requestAsyncStorage:()=>c,routeModule:()=>d,serverHooks:()=>E,staticGenerationAsyncStorage:()=>k});var s={};a.r(s),a.d(s,{GET:()=>_,dynamic:()=>l});var r=a(49303),n=a(88716),i=a(60670),u=a(9487),o=a(46267),p=a(71299);let l="force-dynamic",_=(0,o.l)({auth:"none"},async(e,t)=>{let a=u.default.prepare(`
    SELECT 
      JSON_EXTRACT(event_data, '$.task_id') as task_id,
      JSON_EXTRACT(event_data, '$.task_title') as task_title,
      event_type,
      COUNT(*) as count
    FROM skill_events
    WHERE event_type IN ('task_take', 'task_complete')
    GROUP BY task_id, event_type
    ORDER BY count DESC
  `).all(),s=u.default.prepare(`
    SELECT 
      se.id, se.user_id, se.event_type, se.event_data, se.created_at,
      u.username, u.nickname
    FROM skill_events se
    LEFT JOIN users u ON se.user_id = u.id
    WHERE se.event_type IN ('task_take', 'task_complete')
    ORDER BY se.created_at DESC
    LIMIT 50
  `).all(),r=u.default.prepare(`
    SELECT 
      COUNT(DISTINCT CASE WHEN event_type = 'task_take' THEN user_id END) as unique_workers,
      SUM(CASE WHEN event_type = 'task_take' THEN 1 ELSE 0 END) as total_takes,
      SUM(CASE WHEN event_type = 'task_complete' THEN 1 ELSE 0 END) as total_completes
    FROM skill_events
    WHERE event_type IN ('task_take', 'task_complete')
  `).get();return(0,p.L)({summary:{unique_workers:r?.unique_workers||0,total_takes:r?.total_takes||0,total_completes:r?.total_completes||0},by_task:a,recent_events:s.map(e=>({id:e.id,user_id:e.user_id,username:e.username||e.nickname||e.user_id?.substring(0,12),event_type:e.event_type,task_id:e.event_data?(()=>{try{return JSON.parse(e.event_data).task_id}catch{return null}})():null,task_title:e.event_data?(()=>{try{return JSON.parse(e.event_data).task_title}catch{return null}})():null,created_at:e.created_at}))})}),d=new r.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/tasks/stats/route",pathname:"/api/tasks/stats",filename:"route",bundlePath:"app/api/tasks/stats/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\tasks\\stats\\route.ts",nextConfigOutput:"standalone",userland:s}),{requestAsyncStorage:c,staticGenerationAsyncStorage:k,serverHooks:E}=d,m="/api/tasks/stats/route";function v(){return(0,i.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:k})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[8948,7070,6944,1203,9487,6267],()=>a(20588));module.exports=s})();