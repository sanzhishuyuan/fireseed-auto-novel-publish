"use strict";(()=>{var e={};e.id=4580,e.ids=[4580],e.modules={85890:e=>{e.exports=require("better-sqlite3")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},55187:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>h,patchFetch:()=>v,requestAsyncStorage:()=>m,routeModule:()=>c,serverHooks:()=>g,staticGenerationAsyncStorage:()=>x});var n={};r.r(n),r.d(n,{GET:()=>d,dynamic:()=>u});var a=r(49303),i=r(88716),s=r(60670),o=r(87070),l=r(9487),p=r(46267);let u="force-dynamic",d=(0,p.l)({auth:"none"},async()=>{try{let e="https://fireseed.online",t=l.default.prepare(`
      SELECT id, title, author, description, tags, created_at, updated_at
      FROM novels
      WHERE deleted_at IS NULL
      ORDER BY updated_at DESC
      LIMIT 20
    `).all().map(t=>{let r=l.default.prepare(`
        SELECT title, created_at FROM chapters
        WHERE novel_id = ?
        ORDER BY created_at DESC LIMIT 1
      `).get(t.id),n=t.tags||"",a=(t.description||"").slice(0,200),i=new Date(t.updated_at||t.created_at).toUTCString(),s=t.author||"AI";return`
    <item>
      <title><![CDATA[${t.title}]]></title>
      <link>${e}/novels/${t.id}</link>
      <guid isPermaLink="true">${e}/novels/${t.id}</guid>
      <description><![CDATA[${a}]]></description>
      <author>${s}</author>
      <category>${n}</category>
      <pubDate>${i}</pubDate>
      ${r?`<comments>${e}/novels/${t.id}</comments>`:""}
    </item>`}).join("\n"),r=new Date().toUTCString(),n=`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>FireSeed 火种 - AI 互动小说平台</title>
    <link>${e}</link>
    <description>火种是一个 AI 驱动的互动叙事平台，在这里你可以阅读和创作 AI 生成的小说，体验多分支剧情。</description>
    <language>zh-cn</language>
    <lastBuildDate>${r}</lastBuildDate>
    <ttl>60</ttl>
    <atom:link href="${e}/api/rss" rel="self" type="application/rss+xml"/>
    <image>
      <url>${e}/favicon.svg</url>
      <title>FireSeed 火种</title>
      <link>${e}</link>
    </image>
${t}
  </channel>
</rss>`;return new o.NextResponse(n,{headers:{"Content-Type":"application/xml; charset=utf-8","Cache-Control":"public, max-age=1800"}})}catch(e){return console.error("RSS error:",e),new o.NextResponse('<?xml version="1.0"?><error>Internal error</error>',{status:500,headers:{"Content-Type":"application/xml"}})}}),c=new a.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/rss/route",pathname:"/api/rss",filename:"route",bundlePath:"app/api/rss/route"},resolvedPagePath:"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\api\\rss\\route.ts",nextConfigOutput:"standalone",userland:n}),{requestAsyncStorage:m,staticGenerationAsyncStorage:x,serverHooks:g}=c,h="/api/rss/route";function v(){return(0,s.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:x})}}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[8948,7070,6944,1203,9487,6267],()=>r(55187));module.exports=n})();