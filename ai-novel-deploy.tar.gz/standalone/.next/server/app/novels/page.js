(()=>{var e={};e.id=9572,e.ids=[9572],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},77448:(e,o,t)=>{"use strict";t.r(o),t.d(o,{GlobalError:()=>s.a,__next_app__:()=>p,originalPathname:()=>x,pages:()=>l,routeModule:()=>m,tree:()=>n}),t(38950),t(75701),t(96560);var a=t(23191),r=t(88716),d=t(37922),s=t.n(d),i=t(95231),c={};for(let e in i)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(c[e]=()=>i[e]);t.d(o,c);let n=["",{children:["novels",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,38950)),"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\novels\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(t.bind(t,75701)),"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(t.bind(t,96560)),"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\not-found.tsx"]}],l=["E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\novels\\page.tsx"],x="/novels/page",p={require:t,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/novels/page",pathname:"/novels",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:n}})},34475:(e,o,t)=>{Promise.resolve().then(t.bind(t,7486))},7486:(e,o,t)=>{"use strict";t.r(o),t.d(o,{default:()=>n});var a=t(10326),r=t(17577),d=t(90434),s=t(35047),i=t(49779);let c=`
@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,500;0,9..144,700;0,9..144,900;1,9..144,400&family=DM+Mono:wght@300;400;500&display=swap');

:root {
  --codex-bg: #0b0b0f;
  --codex-bg-card: #131318;
  --codex-bg-elevated: #1a1a22;
  --codex-bg-hover: #22222c;
  --codex-text: #f0ece4;
  --codex-text-dim: #9a9a8e;
  --codex-text-muted: #5a5a52;
  --codex-gold: #c9a55c;
  --codex-gold-light: #e4cc8a;
  --codex-gold-glow: rgba(201,165,92,0.12);
  --codex-gold-glow-strong: rgba(201,165,92,0.25);
  --codex-border: rgba(255,255,255,0.06);
  --codex-border-gold: rgba(201,165,92,0.2);
  --font-display: 'Fraunces', Georgia, serif;
  --font-mono: 'DM Mono', 'Menlo', monospace;
  --font-cn: -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Microsoft YaHei', sans-serif;
  --codex-radius: 12px;
  --codex-radius-sm: 8px;
}

/* ═══════ Texture Background ═══════ */
.codex-bg {
  position: fixed; inset: 0; z-index: 0; pointer-events: none;
  background:
    radial-gradient(ellipse 70% 50% at 15% 5%, rgba(201,165,92,0.03) 0%, transparent 60%),
    radial-gradient(ellipse 50% 40% at 85% 90%, rgba(99,102,241,0.02) 0%, transparent 50%),
    var(--codex-bg);
}
.codex-bg::after {
  content: ''; position: absolute; inset: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.025'/%3E%3C/svg%3E");
  background-repeat: repeat;
  opacity: 0.5;
}

/* ═══════ Page Shell ═══════ */
.codex-shell {
  position: relative; z-index: 1;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 24px;
}

/* ═══════ HERO ═══════ */
.codex-hero {
  padding: 48px 0 36px;
  border-bottom: 1px solid var(--codex-border);
  margin-bottom: 36px;
}
.codex-hero-grid {
  display: grid;
  grid-template-columns: 180px 1fr;
  gap: 36px;
  align-items: start;
}
.codex-hero-cover {
  width: 180px;
  aspect-ratio: 3/4;
  border-radius: 6px;
  overflow: hidden;
  position: relative;
  box-shadow: 0 4px 16px rgba(0,0,0,0.5), 0 0 0 1px rgba(201,165,92,0.15);
}
.codex-hero-cover .live-badge {
  position: absolute; bottom: 8px; left: 8px; right: 8px;
  display: flex; align-items: center; gap: 6px;
  padding: 5px 10px;
  background: rgba(0,0,0,0.7);
  backdrop-filter: blur(8px);
  border-radius: 6px;
  font-family: var(--font-mono);
  font-size: 10px;
  color: var(--codex-gold);
  z-index: 2;
}
.codex-hero-cover .live-dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: #22c55e;
  animation: codex-live-pulse 1.5s ease-in-out infinite;
}
@keyframes codex-live-pulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(34,197,94,0.5); }
  50% { box-shadow: 0 0 0 4px rgba(34,197,94,0); }
}
.codex-hero-meta { padding-top: 4px; }
.codex-hero-tag {
  display: inline-flex; align-items: center; gap: 6px;
  font-family: var(--font-mono);
  font-size: 11px; letter-spacing: 2px;
  color: var(--codex-gold);
  text-transform: uppercase;
  margin-bottom: 14px;
}
.codex-hero-tag .line {
  width: 24px; height: 1px; background: var(--codex-gold);
}
.codex-hero-title {
  font-family: var(--font-display);
  font-size: 44px; font-weight: 700;
  line-height: 1.15; color: var(--codex-text);
  margin-bottom: 14px; letter-spacing: -0.5px;
}
.codex-hero-desc {
  font-size: 15px; line-height: 1.7;
  color: var(--codex-text-dim);
  max-width: 560px; margin-bottom: 20px;
  display: -webkit-box; -webkit-line-clamp: 3;
  -webkit-box-orient: vertical; overflow: hidden;
}
.codex-hero-stats { display: flex; gap: 24px; margin-bottom: 24px; }
.codex-hero-stat { display: flex; flex-direction: column; gap: 2px; }
.codex-hero-stat-value {
  font-family: var(--font-display);
  font-size: 22px; font-weight: 700; color: var(--codex-gold);
}
.codex-hero-stat-label {
  font-family: var(--font-mono);
  font-size: 10px; color: var(--codex-text-muted); letter-spacing: 1px;
}
.codex-hero-actions { display: flex; gap: 12px; }
.codex-hero-btn {
  padding: 10px 24px; border-radius: var(--codex-radius-sm);
  font-family: var(--font-mono); font-size: 13px; font-weight: 500;
  cursor: pointer; transition: all 0.2s ease;
  text-decoration: none; display: inline-flex; align-items: center; gap: 8px;
  border: none;
}
.codex-hero-btn-primary {
  background: var(--codex-gold); color: #0b0b0f;
}
.codex-hero-btn-primary:hover {
  background: var(--codex-gold-light);
  transform: translateY(-1px);
  box-shadow: 0 4px 20px var(--codex-gold-glow);
}
.codex-hero-btn-secondary {
  background: transparent; color: var(--codex-text-dim);
  border: 1px solid var(--codex-border);
}
.codex-hero-btn-secondary:hover {
  border-color: var(--codex-gold); color: var(--codex-gold);
}

/* ═══════ STATS BAR ═══════ */
.codex-stats {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 0;
  margin-bottom: 36px;
  border: 1px solid var(--codex-border);
  border-radius: var(--codex-radius);
  overflow: hidden; background: var(--codex-bg-card);
}
.codex-stat-item {
  padding: 20px 24px; text-align: center;
  border-right: 1px solid var(--codex-border);
  transition: background 0.2s ease;
}
.codex-stat-item:last-child { border-right: none; }
.codex-stat-item:hover { background: var(--codex-bg-elevated); }
.codex-stat-number {
  font-family: var(--font-display);
  font-size: 32px; font-weight: 900;
  color: var(--codex-gold); line-height: 1;
  margin-bottom: 4px; letter-spacing: -0.5px;
}
.codex-stat-label {
  font-family: var(--font-mono);
  font-size: 10px; letter-spacing: 2px;
  color: var(--codex-text-muted); text-transform: uppercase;
}

/* ═══════ DISCOVERY ═══════ */
.codex-discovery { margin-bottom: 32px; }
.codex-search-row { position: relative; margin-bottom: 16px; }
.codex-search-icon {
  position: absolute; left: 16px; top: 50%;
  transform: translateY(-50%); color: var(--codex-text-muted);
}
.codex-search-input {
  width: 100%; padding: 14px 44px 14px 46px;
  background: var(--codex-bg-card);
  border: 1px solid var(--codex-border);
  border-radius: var(--codex-radius);
  font-size: 14px; font-family: var(--font-cn);
  color: var(--codex-text); outline: none;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}
.codex-search-input::placeholder { color: var(--codex-text-muted); }
.codex-search-input:focus {
  border-color: var(--codex-gold);
  box-shadow: 0 0 0 3px var(--codex-gold-glow);
}
.codex-search-clear {
  position: absolute; right: 14px; top: 50%;
  transform: translateY(-50%);
  background: none; border: none; cursor: pointer;
  color: var(--codex-text-muted); font-size: 14px;
  padding: 4px;
}
.codex-search-clear:hover { color: var(--codex-gold); }

/* Tag Pills */
.codex-tag-row {
  display: flex; gap: 8px;
  overflow-x: auto; padding-bottom: 8px; margin-bottom: 12px;
  scrollbar-width: none;
}
.codex-tag-row::-webkit-scrollbar { display: none; }
.codex-tag-pill {
  flex-shrink: 0; padding: 7px 16px;
  border-radius: 20px; font-size: 13px; font-weight: 500;
  cursor: pointer; transition: all 0.2s ease;
  border: 1px solid var(--codex-border);
  background: transparent; color: var(--codex-text-dim);
  white-space: nowrap; font-family: var(--font-cn);
}
.codex-tag-pill:hover {
  border-color: var(--codex-gold); color: var(--codex-gold);
}
.codex-tag-pill.active {
  background: var(--codex-gold); color: #0b0b0f;
  border-color: var(--codex-gold); font-weight: 600;
}

/* Sort & Count Row */
.codex-sort-row {
  display: flex; align-items: center;
  justify-content: space-between;
  flex-wrap: wrap; gap: 12px;
}
.codex-sort-count {
  font-family: var(--font-mono);
  font-size: 12px; color: var(--codex-text-muted);
}
.codex-sort-count strong {
  color: var(--codex-gold); font-weight: 500;
}
.codex-sort-options { display: flex; gap: 4px; }
.codex-sort-btn {
  padding: 6px 14px; border-radius: var(--codex-radius-sm);
  font-size: 12px; font-family: var(--font-mono);
  cursor: pointer; transition: all 0.15s ease;
  border: 1px solid transparent;
  background: transparent; color: var(--codex-text-muted);
}
.codex-sort-btn:hover {
  color: var(--codex-text); background: var(--codex-bg-elevated);
}
.codex-sort-btn.active {
  color: var(--codex-gold);
  border-color: var(--codex-border-gold);
  background: var(--codex-gold-glow);
}

/* ═══════ NOVEL GRID ═══════ */
.codex-novel-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px; margin-bottom: 48px;
}
.codex-novel-card {
  display: flex; flex-direction: column;
  border-radius: var(--codex-radius);
  overflow: hidden; background: var(--codex-bg-card);
  border: 1px solid var(--codex-border);
  transition: all 0.3s ease;
  text-decoration: none; color: inherit;
  position: relative;
}
.codex-novel-card:hover {
  transform: translateY(-4px);
  border-color: var(--codex-border-gold);
  box-shadow: 0 8px 32px rgba(0,0,0,0.4), 0 0 0 1px var(--codex-border-gold);
}
.codex-card-cover {
  aspect-ratio: 3/4; position: relative; overflow: hidden;
}
.codex-novel-card:hover .codex-card-cover img {
  transform: scale(1.05);
}
.codex-card-tag-overlay {
  position: absolute; top: 10px; left: 10px;
  padding: 3px 10px; border-radius: 6px;
  font-size: 11px; font-weight: 500;
  backdrop-filter: blur(8px);
  background: rgba(0,0,0,0.5); color: white;
  z-index: 2;
}
.codex-card-status {
  position: absolute; top: 10px; right: 10px;
  padding: 2px 8px; border-radius: 4px;
  font-size: 10px; font-family: var(--font-mono);
  font-weight: 500; letter-spacing: 0.5px; z-index: 2;
}
.codex-card-status.ongoing {
  background: rgba(201,165,92,0.15);
  color: var(--codex-gold);
  border: 1px solid rgba(201,165,92,0.25);
}
.codex-card-status.completed {
  background: rgba(34,197,94,0.12);
  color: #22c55e;
  border: 1px solid rgba(34,197,94,0.2);
}
.codex-card-progress {
  position: absolute; bottom: 0; left: 0; right: 0;
  height: 3px; background: rgba(255,255,255,0.08); z-index: 2;
}
.codex-card-progress-bar {
  height: 100%; border-radius: 0 3px 3px 0;
  background: linear-gradient(90deg, var(--codex-gold), var(--codex-gold-light));
  transition: width 0.8s ease;
}
.codex-card-info { padding: 14px 14px 16px; }
.codex-card-title {
  font-family: var(--font-display);
  font-size: 16px; font-weight: 700;
  color: var(--codex-text); line-height: 1.3;
  margin-bottom: 6px;
  display: -webkit-box; -webkit-line-clamp: 2;
  -webkit-box-orient: vertical; overflow: hidden;
}
.codex-card-author-row {
  display: flex; align-items: center;
  gap: 8px; margin-bottom: 8px;
}
.codex-card-author {
  font-family: var(--font-mono);
  font-size: 11px; color: var(--codex-text-dim);
}
.codex-card-chapters {
  font-family: var(--font-mono);
  font-size: 10px; color: var(--codex-text-muted);
  padding: 1px 6px; background: var(--codex-bg-elevated);
  border-radius: 4px;
}
.codex-card-desc {
  font-size: 12px; line-height: 1.55;
  color: var(--codex-text-muted);
  display: -webkit-box; -webkit-line-clamp: 2;
  -webkit-box-orient: vertical; overflow: hidden;
  margin-bottom: 10px;
}
.codex-card-tags { display: flex; flex-wrap: wrap; gap: 4px; }
.codex-card-tag-mini {
  font-family: var(--font-mono);
  font-size: 10px; padding: 2px 8px;
  border-radius: 4px;
  background: var(--codex-gold-glow);
  color: var(--codex-gold);
}

/* ═══════ Loading Skeleton ═══════ */
.codex-skeleton-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;
}
.codex-skeleton-card {
  border-radius: var(--codex-radius); overflow: hidden;
  background: var(--codex-bg-card);
  border: 1px solid var(--codex-border);
}
.codex-skeleton-cover {
  aspect-ratio: 3/4; background: var(--codex-bg-elevated);
  animation: codex-shimmer 1.5s ease-in-out infinite;
}
@keyframes codex-shimmer {
  0%, 100% { opacity: 0.6; }
  50% { opacity: 0.3; }
}
.codex-skeleton-info { padding: 14px; }
.codex-skeleton-line {
  height: 12px; border-radius: 6px;
  background: var(--codex-bg-elevated);
  margin-bottom: 8px;
  animation: codex-shimmer 1.5s ease-in-out infinite;
}
.codex-skeleton-line:nth-child(1) { width: 75%; }
.codex-skeleton-line:nth-child(2) { width: 45%; }

/* ═══════ Empty State ═══════ */
.codex-empty {
  text-align: center; padding: 60px 20px;
}
.codex-empty-icon {
  width: 64px; height: 64px; margin: 0 auto 16px;
  border-radius: 16px; background: var(--codex-gold-glow);
  display: flex; align-items: center; justify-content: center;
}
.codex-empty-title {
  font-family: var(--font-display);
  font-size: 22px; font-weight: 700;
  color: var(--codex-text); margin-bottom: 8px;
}
.codex-empty-desc {
  font-size: 14px; color: var(--codex-text-dim); margin-bottom: 20px;
}
.codex-empty-btn {
  padding: 10px 24px; border-radius: var(--codex-radius-sm);
  background: var(--codex-gold); color: #0b0b0f; border: none;
  font-family: var(--font-mono); font-size: 13px; font-weight: 500;
  cursor: pointer; transition: all 0.2s ease;
}
.codex-empty-btn:hover {
  background: var(--codex-gold-light); transform: translateY(-1px);
}

/* ═══════ Animations ═══════ */
@keyframes codex-fade-up {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}
.codex-animate {
  animation: codex-fade-up 0.5s ease forwards;
  opacity: 0;
}

/* ═══════ Responsive ═══════ */
@media (max-width: 1024px) {
  .codex-novel-grid { grid-template-columns: repeat(3, 1fr); }
  .codex-skeleton-grid { grid-template-columns: repeat(3, 1fr); }
  .codex-hero-grid { grid-template-columns: 150px 1fr; gap: 28px; }
  .codex-hero-cover { width: 150px; }
  .codex-hero-title { font-size: 36px; }
}
@media (max-width: 768px) {
  .codex-novel-grid { grid-template-columns: repeat(2, 1fr); gap: 14px; }
  .codex-skeleton-grid { grid-template-columns: repeat(2, 1fr); gap: 14px; }
  .codex-hero-grid { grid-template-columns: 1fr; }
  .codex-hero-cover { width: 120px; margin: 0 auto; }
  .codex-hero { text-align: center; }
  .codex-hero-desc { max-width: 100%; }
  .codex-hero-stats { justify-content: center; }
  .codex-hero-actions { justify-content: center; }
  .codex-hero-title { font-size: 30px; }
  .codex-stats { grid-template-columns: repeat(2, 1fr); }
  .codex-stat-item:nth-child(2) { border-right: none; }
  .codex-stat-item:nth-child(1), .codex-stat-item:nth-child(2) {
    border-bottom: 1px solid var(--codex-border);
  }
  .codex-stat-number { font-size: 26px; }
}
@media (max-width: 480px) {
  .codex-shell { padding: 0 14px; }
  .codex-hero-title { font-size: 26px; }
  .codex-hero-cover { width: 100px; }
  .codex-hero-stats { gap: 16px; }
  .codex-hero-stat-value { font-size: 18px; }
  .codex-novel-grid { gap: 10px; }
  .codex-card-info { padding: 10px 10px 12px; }
  .codex-card-title { font-size: 14px; }
  .codex-stats { grid-template-columns: 1fr 1fr; }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
`;function n(){return a.jsx(r.Suspense,{fallback:a.jsx("div",{style:{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#0b0b0f",color:"#9a9a8e",fontFamily:"'DM Mono', monospace",fontSize:"13px"},children:(0,a.jsxs)("div",{style:{textAlign:"center"},children:[a.jsx("div",{style:{fontSize:"36px",marginBottom:"12px",animation:"pulse 2s infinite"},children:"\uD83D\uDCDA"}),a.jsx("p",{children:"加载手稿中..."})]})}),children:a.jsx(l,{})})}function l(){var e;let[o,t]=(0,r.useState)([]),[n,l]=(0,r.useState)(!0),[x,p]=(0,r.useState)(null),[m,g]=(0,r.useState)("全部"),[h,u]=(0,r.useState)("最新更新"),[v,b]=(0,r.useState)(""),[f,y]=(0,r.useState)(!1),[w,j]=(0,r.useState)({totalChapters:0,totalNovels:0,totalWords:0,totalAuthors:0});(0,s.useRouter)(),(0,s.useSearchParams)();let k={全部:"\uD83D\uDCDA",玄幻:"⚡",都市:"\uD83C\uDFD9",仙侠:"\uD83C\uDFEF",言情:"\uD83D\uDC95",科幻:"\uD83D\uDE80",悬疑:"\uD83D\uDD2E",历史:"\uD83D\uDCDC",恐怖:"\uD83D\uDC7B",军事:"⚔️",奇幻:"\uD83D\uDD2E",武侠:"⚡"},N=(0,r.useMemo)(()=>{let e=new Set(["全部"]);return o.forEach(o=>{o.tags&&o.tags.split(",").forEach(o=>{let t=o.trim();t&&e.add(t)})}),Array.from(e)},[o]),D=(0,r.useMemo)(()=>{let e=[...o];if(v.trim()){let o=v.trim().toLowerCase();e=e.filter(e=>e.title?.toLowerCase().includes(o)||e.author?.toLowerCase().includes(o)||e.tags?.toLowerCase().includes(o)||e.description?.toLowerCase().includes(o))}switch(f||(e=e.filter(e=>(e.chapterCount||0)>0)),"全部"!==m&&(e=e.filter(e=>e.tags?.split(",").map(e=>e.trim()).includes(m))),h){case"最新更新":e.sort((e,o)=>new Date(o.updated_at||0).getTime()-new Date(e.updated_at||0).getTime());break;case"最多章节":e.sort((e,o)=>(o.chapterCount||0)-(e.chapterCount||0));break;case"新书上架":e.sort((e,o)=>new Date(e.updated_at||0).getTime()-new Date(o.updated_at||0).getTime())}return e},[o,m,h,v,f]),C=(0,r.useMemo)(()=>{if(0===o.length)return null;let e=o.filter(e=>(e.chapterCount||0)>0);return 0===e.length?null:e.sort((e,o)=>new Date(o.updated_at||0).getTime()-new Date(e.updated_at||0).getTime())[0]},[o]);return(0,a.jsxs)(a.Fragment,{children:[a.jsx("style",{children:c}),a.jsx("div",{className:"codex-bg"}),(0,a.jsxs)("div",{className:"codex-shell",style:{minHeight:"100vh",paddingBottom:"48px"},children:[!n&&C&&a.jsx("section",{className:"codex-hero codex-animate",children:(0,a.jsxs)("div",{className:"codex-hero-grid",children:[(0,a.jsxs)("div",{className:"codex-hero-cover",children:[a.jsx(i.Z,{src:C.cover_url,alt:C.title,tag:C.tags,aspectRatio:"aspect-[3/4]"}),"completed"!==C.status&&(0,a.jsxs)("div",{className:"live-badge",children:[a.jsx("span",{className:"live-dot"}),"LIVE WRITING"]})]}),(0,a.jsxs)("div",{className:"codex-hero-meta",children:[(0,a.jsxs)("div",{className:"codex-hero-tag",children:[a.jsx("span",{className:"line"}),"LATEST CODEX \xb7 最新手稿"]}),a.jsx("h1",{className:"codex-hero-title",children:C.title}),a.jsx("p",{className:"codex-hero-desc",children:C.description||"暂无简介"}),(0,a.jsxs)("div",{className:"codex-hero-stats",children:[(0,a.jsxs)("div",{className:"codex-hero-stat",children:[a.jsx("span",{className:"codex-hero-stat-value",children:C.chapterCount||0}),a.jsx("span",{className:"codex-hero-stat-label",children:"CHAPTERS"})]}),(0,a.jsxs)("div",{className:"codex-hero-stat",children:[a.jsx("span",{className:"codex-hero-stat-value",children:C.tags?.split(",")[0]?.trim()||"—"}),a.jsx("span",{className:"codex-hero-stat-label",children:"GENRE"})]}),(0,a.jsxs)("div",{className:"codex-hero-stat",children:[a.jsx("span",{className:"codex-hero-stat-value",children:"completed"===C.status?"完结":"连载"}),a.jsx("span",{className:"codex-hero-stat-label",children:"STATUS"})]})]}),(0,a.jsxs)("div",{className:"codex-hero-actions",children:[a.jsx(d.default,{href:`/novels/${C.id}`,className:"codex-hero-btn codex-hero-btn-primary",children:"开始阅读 →"}),a.jsx(d.default,{href:`/novels/${C.id}`,className:"codex-hero-btn codex-hero-btn-secondary",children:"查看目录"})]})]})]})}),(0,a.jsxs)("div",{className:"codex-stats codex-animate",style:{animationDelay:"0.1s"},children:[(0,a.jsxs)("div",{className:"codex-stat-item",children:[a.jsx("div",{className:"codex-stat-number",children:w.totalNovels}),a.jsx("div",{className:"codex-stat-label",children:"Total Codices"})]}),(0,a.jsxs)("div",{className:"codex-stat-item",children:[a.jsx("div",{className:"codex-stat-number",children:w.totalChapters}),a.jsx("div",{className:"codex-stat-label",children:"Chapters"})]}),(0,a.jsxs)("div",{className:"codex-stat-item",children:[a.jsx("div",{className:"codex-stat-number",children:(e=w.totalWords)>=1e4?(e/1e4).toFixed(1)+"w":e.toString()}),a.jsx("div",{className:"codex-stat-label",children:"Words Written"})]}),(0,a.jsxs)("div",{className:"codex-stat-item",children:[a.jsx("div",{className:"codex-stat-number",children:w.totalAuthors}),a.jsx("div",{className:"codex-stat-label",children:"Authors"})]})]}),!n&&o.length>0&&(0,a.jsxs)("div",{className:"codex-discovery codex-animate",style:{animationDelay:"0.2s"},children:[(0,a.jsxs)("div",{className:"codex-search-row",children:[(0,a.jsxs)("svg",{className:"codex-search-icon",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("circle",{cx:"7",cy:"7",r:"5"}),a.jsx("path",{d:"M11 11l3 3",strokeLinecap:"round"})]}),a.jsx("input",{type:"text",className:"codex-search-input",value:v,onChange:e=>b(e.target.value),placeholder:"搜索书名、作者、标签...","aria-label":"搜索书名、作者、标签"}),v&&a.jsx("button",{className:"codex-search-clear",onClick:()=>b(""),"aria-label":"清除搜索",children:"✕"})]}),a.jsx("div",{className:"codex-tag-row",children:N.slice(0,10).map(e=>(0,a.jsxs)("button",{className:`codex-tag-pill ${m===e?"active":""}`,onClick:()=>g(e),children:[k[e]||"\uD83D\uDCD6"," ",e]},e))}),(0,a.jsxs)("div",{className:"codex-sort-row",children:[(0,a.jsxs)("div",{className:"codex-sort-count",children:["共 ",a.jsx("strong",{children:D.length})," 部手稿 \xa0",(0,a.jsxs)("label",{style:{cursor:"pointer",fontSize:"11px",color:"var(--codex-text-muted)"},children:[a.jsx("input",{type:"checkbox",checked:f,onChange:e=>y(e.target.checked),style:{accentColor:"var(--codex-gold)"}})," ","显示筹备中"]})]}),a.jsx("div",{className:"codex-sort-options",children:[{key:"最新更新",label:"\uD83C\uDD95 最新更新"},{key:"最多章节",label:"\uD83D\uDCD6 最多章节"},{key:"新书上架",label:"✨ 新书上架"}].map(e=>a.jsx("button",{className:`codex-sort-btn ${h===e.key?"active":""}`,onClick:()=>u(e.key),children:e.label},e.key))})]})]}),n&&a.jsx("div",{className:"codex-skeleton-grid",children:[1,2,3,4,5,6,7,8].map(e=>(0,a.jsxs)("div",{className:"codex-skeleton-card",children:[a.jsx("div",{className:"codex-skeleton-cover"}),(0,a.jsxs)("div",{className:"codex-skeleton-info",children:[a.jsx("div",{className:"codex-skeleton-line"}),a.jsx("div",{className:"codex-skeleton-line"})]})]},e))}),!n&&D.length>0&&a.jsx("div",{className:"codex-novel-grid",children:D.map((e,o)=>{let t=e.tags?.split(",")[0]?.trim()||"故事",r=k[t]||"✨",s=Math.min((e.chapterCount||0)/30*100,100);return(0,a.jsxs)(d.default,{href:`/novels/${e.id}`,className:"codex-novel-card codex-animate",style:{animationDelay:`${Math.min(.25+.05*o,.8)}s`},children:[(0,a.jsxs)("div",{className:"codex-card-cover",children:[a.jsx(i.Z,{src:e.cover_url,alt:e.title,tag:e.tags}),(0,a.jsxs)("span",{className:"codex-card-tag-overlay",children:[r," ",t]}),a.jsx("span",{className:`codex-card-status ${"completed"===e.status?"completed":"ongoing"}`,children:"completed"===e.status?"完结":"连载"}),"completed"!==e.status&&a.jsx("div",{className:"codex-card-progress",children:a.jsx("div",{className:"codex-card-progress-bar",style:{width:`${s}%`}})})]}),(0,a.jsxs)("div",{className:"codex-card-info",children:[a.jsx("h3",{className:"codex-card-title",children:e.title}),(0,a.jsxs)("div",{className:"codex-card-author-row",children:[a.jsx("span",{className:"codex-card-author",children:e.author||"FireSeed AI"}),(0,a.jsxs)("span",{className:"codex-card-chapters",children:[e.chapterCount||0," 章"]})]}),a.jsx("p",{className:"codex-card-desc",children:e.description||"暂无简介"}),e.tags&&a.jsx("div",{className:"codex-card-tags",children:e.tags.split(",").filter(Boolean).slice(0,3).map(e=>a.jsx("span",{className:"codex-card-tag-mini",children:e.trim()},e))})]})]},e.id)})}),!n&&o.length>0&&0===D.length&&(0,a.jsxs)("div",{className:"codex-empty",children:[a.jsx("div",{className:"codex-empty-icon",children:a.jsx("span",{style:{fontSize:"28px"},children:"\uD83D\uDD0D"})}),a.jsx("h3",{className:"codex-empty-title",children:"暂无匹配结果"}),a.jsx("p",{className:"codex-empty-desc",children:v?`没有找到与 "${v}" 相关的手稿`:`没有找到 "${m}" 分类下的手稿`}),a.jsx("button",{onClick:()=>{g("全部"),b("")},className:"codex-empty-btn",children:"查看全部手稿"})]}),!n&&0===o.length&&(0,a.jsxs)("div",{className:"codex-empty",children:[a.jsx("div",{className:"codex-empty-icon",children:(0,a.jsxs)("svg",{width:"28",height:"28",viewBox:"0 0 28 28",fill:"none",stroke:"var(--codex-gold)",strokeWidth:"1.5",children:[a.jsx("path",{d:"M14 4L4 9v11l10 5 10-5V9L14 4z"}),a.jsx("path",{d:"M14 4v18M4 9l10 5 10-5"})]})}),a.jsx("h3",{className:"codex-empty-title",children:"尚无手稿"}),a.jsx("p",{className:"codex-empty-desc",children:"创作者正在书写中，第一部手稿即将上线"}),a.jsx(d.default,{href:"/admin",className:"codex-empty-btn",style:{textDecoration:"none"},children:"进入后台"})]})]})]})}},49779:(e,o,t)=>{"use strict";t.d(o,{Z:()=>s});var a=t(10326),r=t(17577),d=t(46226);function s({src:e,alt:o,tag:t,className:s="",aspectRatio:i="aspect-[3/4]"}){let[c,n]=(0,r.useState)(!1),[l,x]=(0,r.useState)(!1),p=(0,r.useCallback)(()=>n(!0),[]),m=(0,r.useCallback)(()=>x(!0),[]),g=t?.split(",")[0]?.trim()||"故事",h=e&&!c;return a.jsx("div",{className:`relative overflow-hidden ${i} ${s}`,children:h?(0,a.jsxs)(a.Fragment,{children:[a.jsx(d.default,{src:e,alt:o,fill:!0,sizes:"(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw",className:`object-cover transition-all duration-500 ${l?"opacity-100":"opacity-0"}`,onError:p,onLoad:m,priority:!1,quality:80}),!l&&a.jsx("div",{className:"absolute inset-0 flex items-center justify-center",style:{background:"var(--bg-secondary)"},children:a.jsx("div",{className:"w-6 h-6 border-2 rounded-full animate-spin",style:{borderColor:"var(--accent)",borderTopColor:"transparent"}})})]}):(0,a.jsxs)("div",{className:"absolute inset-0 flex flex-col items-center justify-center",style:{background:{玄幻:"linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",都市:"linear-gradient(135deg, #2d3436 0%, #636e72 50%, #b2bec3 100%)",仙侠:"linear-gradient(135deg, #5c3d1e 0%, #8b5e3c 50%, #c49a6c 100%)",言情:"linear-gradient(135deg, #6b21a8 0%, #db2777 50%, #f472b6 100%)",科幻:"linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #38bdf8 100%)",悬疑:"linear-gradient(135deg, #111827 0%, #374151 50%, #6b7280 100%)",历史:"linear-gradient(135deg, #78350f 0%, #92400e 50%, #d97706 100%)",武侠:"linear-gradient(135deg, #1c1917 0%, #44403c 50%, #78716c 100%)",奇幻:"linear-gradient(135deg, #312e81 0%, #5b21b6 50%, #8b5cf6 100%)"}[g]||"linear-gradient(135deg, #5c3d1e 0%, #8b5e3c 50%, #c49a6c 100%)"},children:[a.jsx("div",{className:"w-12 h-12 rounded-full border-2 border-white/20 flex items-center justify-center mb-3",children:a.jsx("span",{className:"text-2xl",children:{玄幻:"⚡",都市:"\uD83C\uDFD9",仙侠:"\uD83C\uDFEF",言情:"\uD83D\uDC95",科幻:"\uD83D\uDE80",悬疑:"\uD83D\uDD2E",历史:"\uD83D\uDCDC",恐怖:"\uD83D\uDC7B",军事:"⚔️",奇幻:"\uD83D\uDD2E",武侠:"⚡",故事:"✨"}[g]||"✨"})}),a.jsx("span",{className:"text-white/60 text-xs font-medium tracking-widest uppercase",children:g})]})})}},38950:(e,o,t)=>{"use strict";t.r(o),t.d(o,{default:()=>a});let a=(0,t(68570).createProxy)(String.raw`E:\SaiBohuman\赛博卧龙\小说创作\ai-novel-lite\app\novels\page.tsx#default`)}};var o=require("../../webpack-runtime.js");o.C(e);var t=e=>o(o.s=e),a=o.X(0,[8948,848,6907,9712],()=>t(77448));module.exports=a})();