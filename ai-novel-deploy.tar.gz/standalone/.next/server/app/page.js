(()=>{var e={};e.id=1931,e.ids=[1931],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},74647:(e,r,t)=>{"use strict";t.r(r),t.d(r,{GlobalError:()=>s.a,__next_app__:()=>x,originalPathname:()=>p,pages:()=>c,routeModule:()=>h,tree:()=>d}),t(90908),t(75701),t(96560);var a=t(23191),i=t(88716),n=t(37922),s=t.n(n),o=t(95231),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);t.d(r,l);let d=["",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,90908)),"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\page.tsx"]}]},{layout:[()=>Promise.resolve().then(t.bind(t,75701)),"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(t.bind(t,96560)),"E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\not-found.tsx"]}],c=["E:\\SaiBohuman\\赛博卧龙\\小说创作\\ai-novel-lite\\app\\page.tsx"],p="/page",x={require:t,loadChunk:()=>Promise.resolve()},h=new a.AppPageRouteModule({definition:{kind:i.x.APP_PAGE,page:"/page",pathname:"/",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},57169:(e,r,t)=>{Promise.resolve().then(t.bind(t,88743))},88743:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>d});var a=t(10326),i=t(90434),n=t(17577),s=t(35047),o=t(49779),l=t(63170);function d(){let[e,r]=(0,n.useState)([]),[t,d]=(0,n.useState)(!0),[c,p]=(0,n.useState)(null),[x,h]=(0,n.useState)(!1),[m,g]=(0,n.useState)(!1),[f,u]=(0,n.useState)(!1),[v,b]=(0,n.useState)(!1),[j,y]=(0,n.useState)({totalChapters:0,totalNovels:0,totalWords:0,totalAuthors:0}),w=(0,s.useRouter)(),k=(0,n.useRef)(null);(0,n.useRef)(null);let{setConfig:N}=(0,l.A)(),z=(0,n.useCallback)(()=>g(!1),[]),D=async()=>{if(!f){u(!0);try{await fetch("/api/auth/logout",{method:"POST",credentials:"include"}),p(null),h(!1),w.push("/"),w.refresh()}catch(e){console.error("Logout error:",e)}finally{u(!1)}}},C=e=>e>=1e4?(e/1e4).toFixed(1):e.toString(),S={玄幻:"⚡",都市:"\uD83C\uDFD9",仙侠:"\uD83C\uDFEF",言情:"\uD83D\uDC95",科幻:"\uD83D\uDE80",悬疑:"\uD83D\uDD2E",历史:"\uD83D\uDCDC",恐怖:"\uD83D\uDC7B",军事:"⚔️",奇幻:"\uD83D\uDD2E",武侠:"⚡"};return(0,a.jsxs)(a.Fragment,{children:[a.jsx("style",{children:`
        /* ===== 粒子与设计基础 ===== */
        #ambient-canvas {
          position: fixed;
          top: 0; left: 0;
          width: 100%; height: 100%;
          z-index: 0;
          pointer-events: none;
        }
        .home-wrap {
          position: relative;
          z-index: 1;
          min-height: 100vh;
        }

        /* ===== 导航 ===== */
        .nav-header {
          position: fixed;
          top: 0; left: 0; right: 0;
          z-index: 100;
          padding: 16px 0;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .nav-header.scrolled {
          background: rgba(26, 20, 16, 0.88);
          backdrop-filter: blur(20px) saturate(1.4);
          -webkit-backdrop-filter: blur(20px) saturate(1.4);
          border-bottom: 1px solid var(--border);
          padding: 10px 0;
        }
        .dark .nav-header.scrolled {
          background: rgba(7, 7, 13, 0.88);
        }
        .nav-inner {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .logo-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
          text-decoration: none;
        }
        .logo-text {
          font-family: 'Orbitron', monospace;
          font-weight: 700;
          font-size: 1.1rem;
          letter-spacing: 0.08em;
          background: linear-gradient(135deg, var(--accent), #fbbf24);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        .nav-links {
          display: flex;
          align-items: center;
          gap: 28px;
          list-style: none;
          margin: 0;
          padding: 0;
        }
        .nav-links a {
          text-decoration: none;
          color: var(--text-secondary);
          font-size: 0.85rem;
          transition: color 0.35s cubic-bezier(0.16, 1, 0.3, 1);
          position: relative;
        }
        .nav-links a::after {
          content: '';
          position: absolute;
          bottom: -4px; left: 0;
          width: 0; height: 1.5px;
          background: var(--accent);
          transition: width 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .nav-links a:hover { color: var(--text-primary); }
        .nav-links a:hover::after { width: 100%; }
        .nav-user-btn {
          background: none;
          border: none;
          color: var(--text-secondary);
          font-size: 0.85rem;
          cursor: pointer;
          padding: 6px 12px;
          border-radius: 8px;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .nav-user-btn:hover {
          background: var(--bg-secondary);
          color: var(--text-primary);
        }
        .nav-mobile-wrap { display: none; }

        /* ===== 移动端抽屉 ===== */
        .drawer-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.6);
          z-index: 200;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.35s ease;
        }
        .drawer-overlay.open {
          opacity: 1;
          pointer-events: auto;
        }
        .mobile-drawer {
          position: fixed;
          top: 0; right: 0;
          width: min(320px, 80vw);
          height: 100%;
          background: var(--bg-card);
          border-left: 1px solid var(--border);
          z-index: 201;
          transform: translateX(100%);
          transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
          padding: 24px;
          display: flex;
          flex-direction: column;
          overflow-y: auto;
        }
        .mobile-drawer.open { transform: translateX(0); }
        .drawer-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 32px;
          padding-bottom: 16px;
          border-bottom: 1px solid var(--border);
        }
        .drawer-close {
          background: none;
          border: none;
          color: var(--text-primary);
          font-size: 1.5rem;
          cursor: pointer;
          padding: 4px 8px;
        }
        .drawer-close:hover { color: var(--accent); }
        .drawer-links {
          list-style: none;
          display: flex;
          flex-direction: column;
          gap: 4px;
          padding: 0; margin: 0;
        }
        .drawer-links a, .drawer-links button {
          display: block;
          padding: 14px 12px;
          color: var(--text-secondary);
          text-decoration: none;
          font-size: 1rem;
          border-radius: 8px;
          transition: all 0.2s ease;
          background: none;
          border: none;
          text-align: left;
          cursor: pointer;
          width: 100%;
        }
        .drawer-links a:hover, .drawer-links a:active,
        .drawer-links button:hover, .drawer-links button:active {
          background: var(--accent-glow);
          color: var(--accent);
        }
        .drawer-cta {
          margin-top: 8px;
          background: linear-gradient(135deg, var(--accent), var(--accent-light)) !important;
          color: #fff !important;
          font-weight: 600;
          text-align: center;
        }

        /* ===== HERO ===== */
        .hero {
          position: relative;
          z-index: 1;
          min-height: 100vh;
          display: flex;
          align-items: center;
          padding-top: 80px;
          overflow: hidden;
        }
        .hero::before {
          content: '';
          position: absolute;
          top: -30%;
          left: -20%;
          width: 140%;
          height: 140%;
          background: radial-gradient(ellipse 60% 50% at 30% 40%, rgba(245,158,11,0.06), transparent 70%),
                      radial-gradient(ellipse 40% 40% at 70% 60%, rgba(125,211,252,0.04), transparent 60%);
          pointer-events: none;
        }
        .hero-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 60px;
          align-items: center;
          width: 100%;
        }
        .hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 6px 16px 6px 8px;
          border-radius: 100px;
          background: var(--accent-glow);
          border: 1px solid rgba(245, 158, 11, 0.12);
          font-size: 0.75rem;
          color: var(--accent);
          margin-bottom: 24px;
        }
        .hero-badge .dot {
          width: 6px; height: 6px;
          border-radius: 50%;
          background: var(--accent);
          animation: pulse-dot 2s ease-in-out infinite;
        }
        @keyframes pulse-dot {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(0.7); }
        }
        .hero h1 {
          font-family: 'ZCOOL QingKe HuangYou', serif;
          font-size: clamp(2.5rem, 6vw, 4rem);
          line-height: 1.15;
          margin-bottom: 20px;
          letter-spacing: 0.02em;
          color: var(--text-primary);
        }
        .hero h1 .highlight {
          position: relative;
          color: var(--accent);
        }
        .hero h1 .highlight::after {
          content: '';
          position: absolute;
          bottom: 2px; left: 0; right: 0;
          height: 8px;
          background: var(--accent-glow);
          border-radius: 4px;
          z-index: -1;
        }
        .hero p {
          font-size: 1.05rem;
          line-height: 1.8;
          color: var(--text-secondary);
          margin-bottom: 36px;
          max-width: 480px;
        }
        .hero-actions {
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
        }
        .hero-actions .btn-primary {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 14px 32px;
          border-radius: 100px;
          font-size: 0.9rem;
          font-weight: 600;
          text-decoration: none;
          cursor: pointer;
          border: none;
          background: linear-gradient(135deg, var(--accent), var(--accent-dark));
          color: #fff;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .hero-actions .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 30px rgba(245, 158, 11, 0.3);
        }
        .hero-actions .btn-ghost {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 14px 32px;
          border-radius: 100px;
          font-size: 0.9rem;
          font-weight: 500;
          text-decoration: none;
          cursor: pointer;
          background: transparent;
          color: var(--text-primary);
          border: 1px solid var(--border);
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .hero-actions .btn-ghost:hover {
          border-color: var(--accent);
          background: var(--accent-glow);
          transform: translateY(-2px);
        }

        /* Hero visual */
        .hero-visual { position: relative; display: flex; justify-content: center; align-items: center; }
        .hero-orbs { position: relative; width: 420px; height: 420px; }
        .orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(60px);
          opacity: 0.5;
          animation: orb-float 8s ease-in-out infinite;
        }
        .orb-1 { width: 200px; height: 200px; background: rgba(245, 158, 11, 0.2); top: 10%; left: 15%; animation-delay: 0s; }
        .orb-2 { width: 160px; height: 160px; background: rgba(125, 211, 252, 0.12); bottom: 15%; right: 10%; animation-delay: -3s; }
        .orb-3 { width: 120px; height: 120px; background: rgba(245, 158, 11, 0.1); top: 50%; left: 50%; transform: translate(-50%, -50%); animation-delay: -6s; }
        @keyframes orb-float {
          0%, 100% { transform: translate(0, 0) scale(1); }
          25% { transform: translate(15px, -20px) scale(1.05); }
          50% { transform: translate(-10px, 10px) scale(0.95); }
          75% { transform: translate(20px, 15px) scale(1.02); }
        }
        .hero-ring {
          position: absolute;
          top: 50%; left: 50%;
          transform: translate(-50%, -50%);
          width: 340px; height: 340px;
          border: 1px solid rgba(245, 158, 11, 0.08);
          border-radius: 50%;
          animation: ring-spin 30s linear infinite;
        }
        .hero-ring-2 {
          width: 260px; height: 260px;
          border-color: rgba(125, 211, 252, 0.06);
          animation-direction: reverse;
          animation-duration: 20s;
        }
        @keyframes ring-spin {
          0% { transform: translate(-50%, -50%) rotate(0deg); }
          100% { transform: translate(-50%, -50%) rotate(360deg); }
        }
        .hero-float-items {
          position: absolute;
          width: 100%; height: 100%;
          top: 0; left: 0;
        }
        .float-item {
          position: absolute;
          padding: 10px 16px;
          background: var(--bg-card);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          border: 1px solid var(--border);
          border-radius: 12px;
          font-size: 0.75rem;
          color: var(--text-secondary);
          animation: float-up 6s ease-in-out infinite;
          white-space: nowrap;
        }
        .float-item strong { color: var(--accent); }
        .float-item:nth-child(1) { top: 5%; right: 5%; animation-delay: 0s; }
        .float-item:nth-child(2) { bottom: 15%; left: 0; animation-delay: -2s; }
        .float-item:nth-child(3) { top: 40%; right: -10%; animation-delay: -4s; }
        @keyframes float-up {
          0%, 100% { transform: translateY(0); opacity: 0.7; }
          50% { transform: translateY(-10px); opacity: 1; }
        }

        /* ===== 通用区块 ===== */
        .home-section { position: relative; z-index: 1; padding: 100px 0; }
        .section-container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
        .section-label {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-family: 'Orbitron', monospace;
          font-size: 0.7rem;
          font-weight: 500;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: var(--accent);
          margin-bottom: 16px;
          opacity: 0.7;
        }
        .section-label::before {
          content: '';
          width: 24px; height: 1px;
          background: var(--accent);
          opacity: 0.5;
        }
        .section-title {
          font-family: 'ZCOOL QingKe HuangYou', serif;
          font-size: clamp(2rem, 5vw, 3.2rem);
          line-height: 1.2;
          color: var(--text-primary);
          margin-bottom: 16px;
          letter-spacing: 0.02em;
        }
        .section-subtitle {
          font-size: 1rem;
          line-height: 1.7;
          color: var(--text-secondary);
          max-width: 560px;
        }
        .text-gradient {
          background: linear-gradient(135deg, var(--accent), #fbbf24, var(--accent-dark));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        /* ===== Features ===== */
        .features-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          margin-top: 48px;
        }
        .feature-card {
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: 20px;
          padding: 40px 32px;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
          position: relative;
          overflow: hidden;
        }
        .feature-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 2px;
          background: linear-gradient(90deg, transparent, var(--accent), transparent);
          opacity: 0;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .feature-card:hover {
          border-color: rgba(245, 158, 11, 0.12);
          transform: translateY(-4px);
        }
        .feature-card:hover::before { opacity: 1; }
        .feature-icon {
          width: 48px; height: 48px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 20px;
          font-size: 1.3rem;
        }
        .feature-icon.amber { background: var(--accent-glow); }
        .feature-icon.frost { background: rgba(125, 211, 252, 0.1); }
        .feature-card h3 { font-size: 1.1rem; font-weight: 600; margin-bottom: 10px; color: var(--text-primary); }
        .feature-card p { font-size: 0.85rem; line-height: 1.7; color: var(--text-secondary); }

        /* ===== Stats ===== */
        .showcase-header {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          margin-bottom: 48px;
          gap: 40px;
        }
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 1px;
          background: var(--border);
          border-radius: 20px;
          overflow: hidden;
          border: 1px solid var(--border);
        }
        .stat-item {
          background: var(--bg-card);
          padding: 36px 24px;
          text-align: center;
          transition: all 0.2s ease;
        }
        .stat-item:hover { background: var(--bg-secondary); }
        .stat-number {
          font-family: 'Orbitron', monospace;
          font-size: clamp(1.8rem, 3vw, 2.5rem);
          font-weight: 700;
          background: linear-gradient(135deg, var(--accent), #fbbf24);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          margin-bottom: 6px;
        }
        .stat-label {
          font-size: 0.8rem;
          color: var(--text-muted);
          letter-spacing: 0.05em;
        }

        /* ===== Novel Grid ===== */
        .novel-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 20px;
          margin-top: 48px;
        }
        .novel-card {
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: 12px;
          overflow: hidden;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
          cursor: pointer;
          position: relative;
        }
        .novel-card:hover {
          transform: translateY(-6px);
          border-color: rgba(245, 158, 11, 0.12);
          box-shadow: 0 12px 40px rgba(0,0,0,0.4);
        }
        .novel-cover-wrap {
          aspect-ratio: 3/4;
          position: relative;
          overflow: hidden;
        }
        .novel-cover-overlay {
          position: absolute;
          inset: 0;
          background: linear-gradient(to top, rgba(0,0,0,0.8), transparent 50%);
          opacity: 0;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
          display: flex;
          align-items: flex-end;
          padding: 16px;
        }
        .novel-card:hover .novel-cover-overlay { opacity: 1; }
        .novel-cover-overlay span {
          font-size: 0.75rem;
          color: var(--accent);
          font-family: 'Orbitron', monospace;
          letter-spacing: 0.08em;
        }
        .novel-info { padding: 16px; }
        .novel-info h4 {
          font-size: 0.9rem;
          font-weight: 600;
          margin-bottom: 4px;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .novel-info .meta {
          font-size: 0.75rem;
          color: var(--text-muted);
          display: flex;
          align-items: center;
          gap: 8px;
          flex-wrap: wrap;
        }
        .novel-tag {
          display: inline-block;
          padding: 2px 8px;
          border-radius: 100px;
          font-size: 0.65rem;
          background: var(--accent-glow);
          color: var(--accent);
        }

        /* ===== Divider ===== */
        .section-divider {
          position: relative; z-index: 1;
          text-align: center;
          padding: 60px 0;
        }
        .divider-line {
          width: 1px; height: 80px;
          background: linear-gradient(to bottom, transparent, var(--accent), transparent);
          margin: 0 auto;
          opacity: 0.3;
        }

        /* ===== CTA Banner ===== */
        .cta-inner {
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: 28px;
          padding: 80px 48px;
          text-align: center;
          position: relative;
          overflow: hidden;
        }
        .cta-inner::before {
          content: '';
          position: absolute;
          inset: 0;
          background: radial-gradient(ellipse 60% 40% at 50% 50%, rgba(245,158,11,0.06), transparent);
          pointer-events: none;
        }
        .cta-inner h2 {
          font-family: 'ZCOOL QingKe HuangYou', serif;
          font-size: clamp(1.8rem, 4vw, 2.6rem);
          margin-bottom: 12px;
          position: relative;
          color: var(--text-primary);
        }
        .cta-inner p {
          color: var(--text-secondary);
          margin-bottom: 32px;
          position: relative;
        }
        .cta-inner .btn-group {
          display: flex;
          justify-content: center;
          gap: 12px;
          flex-wrap: wrap;
          position: relative;
        }

        /* ===== Footer ===== */
        .home-footer {
          position: relative; z-index: 1;
          border-top: 1px solid var(--border);
          padding: 48px 0 32px;
          margin-top: 100px;
        }
        .footer-inner {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 24px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 24px;
        }
        .footer-copyright { font-size: 0.8rem; color: var(--text-muted); }
        .footer-links { display: flex; gap: 24px; flex-wrap: wrap; }
        .footer-links a { color: var(--text-muted); text-decoration: none; font-size: 0.8rem; transition: color 0.2s ease; }
        .footer-links a:hover { color: var(--text-secondary); }

        /* ===== Animations ===== */
        .reveal {
          opacity: 0;
          transform: translateY(30px);
          transition: opacity 0.8s ease, transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .reveal.visible {
          opacity: 1;
          transform: translateY(0);
        }
        .stagger > * {
          opacity: 0;
          transform: translateY(20px);
          transition: opacity 0.6s ease, transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .stagger.visible > * {
          opacity: 1;
          transform: translateY(0);
        }
        .stagger.visible > *:nth-child(1) { transition-delay: 0s; }
        .stagger.visible > *:nth-child(2) { transition-delay: 0.1s; }
        .stagger.visible > *:nth-child(3) { transition-delay: 0.2s; }
        .stagger.visible > *:nth-child(4) { transition-delay: 0.3s; }
        .stagger.visible > *:nth-child(5) { transition-delay: 0.4s; }
        .stagger.visible > *:nth-child(6) { transition-delay: 0.5s; }
        .stagger.visible > *:nth-child(7) { transition-delay: 0.6s; }
        .stagger.visible > *:nth-child(8) { transition-delay: 0.7s; }

        /* ===== Responsive ===== */
        @media (max-width: 1024px) {
          .hero-grid { grid-template-columns: 1fr; text-align: center; gap: 32px; }
          .hero p { margin: 0 auto 36px; }
          .hero-actions { justify-content: center; }
          .hero-visual { display: none; }
          .features-grid { grid-template-columns: repeat(2, 1fr); gap: 20px; }
          .novel-grid { grid-template-columns: repeat(3, 1fr); gap: 16px; }
          .showcase-header { flex-direction: column; align-items: flex-start; }
        }
        @media (max-width: 768px) {
          .nav-header { padding: 12px 0; }
          .nav-header.scrolled { padding: 8px 0; }
          .nav-links { display: none; }
          .nav-mobile-wrap { display: flex; align-items: center; gap: 8px; }
          .nav-mobile-btn {
            background: none; border: none; color: var(--text-primary);
            cursor: pointer; padding: 8px; border-radius: 8px;
          }
          .nav-mobile-btn:active { background: var(--accent-glow); }
          .nav-inner { padding: 0 20px; }
          .logo-text { font-size: 1rem; }

          .hero { min-height: calc(100vh - 60px); padding-top: 72px; }
          .hero-badge { font-size: 0.65rem; padding: 4px 12px 4px 6px; margin-bottom: 16px; }
          .hero h1 { font-size: clamp(1.8rem, 7vw, 2.4rem); letter-spacing: 0; }
          .hero h1 .highlight::after { height: 5px; bottom: 1px; }
          .hero p { font-size: 0.9rem; line-height: 1.7; margin-bottom: 28px; }
          .hero-actions .btn-primary, .hero-actions .btn-ghost { padding: 12px 24px; font-size: 0.85rem; }
          .hero-actions { gap: 10px; }
          .hero-actions .btn-primary, .hero-actions .btn-ghost { flex: 1; justify-content: center; max-width: 200px; }

          .home-section { padding: 64px 0; }
          .features-grid { grid-template-columns: 1fr; gap: 16px; margin-top: 32px; }
          .feature-card { padding: 28px 24px; border-radius: 12px; }
          .feature-card h3 { font-size: 1rem; }
          .feature-card p { font-size: 0.82rem; }
          .feature-icon { width: 40px; height: 40px; font-size: 1.1rem; margin-bottom: 16px; }

          .stats-grid { grid-template-columns: repeat(2, 1fr); border-radius: 12px; }
          .stat-item { padding: 24px 16px; }
          .stat-number { font-size: clamp(1.5rem, 5vw, 2rem); }
          .stat-label { font-size: 0.72rem; }

          .novel-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; margin-top: 32px; }
          .novel-info { padding: 12px; }
          .novel-info h4 { font-size: 0.82rem; }
          .novel-info .meta { font-size: 0.7rem; gap: 4px; }

          .section-title { margin-bottom: 10px; }
          .section-subtitle { font-size: 0.9rem; }
          .showcase-header { margin-bottom: 32px; gap: 8px; }

          .cta-inner { padding: 48px 24px; border-radius: 20px; }
          .cta-inner h2 { font-size: clamp(1.4rem, 5vw, 1.8rem); }
          .cta-inner p { font-size: 0.9rem; margin-bottom: 24px; }

          .home-footer { margin-top: 60px; padding: 36px 0 24px; }
          .footer-inner { flex-direction: column; text-align: center; gap: 16px; }
          .footer-links { gap: 16px; justify-content: center; }

          .section-divider { padding: 40px 0; }
          .divider-line { height: 56px; }
        }
        @media (max-width: 480px) {
          .nav-inner { padding: 0 16px; }
          .nav-header { padding: 10px 0; }
          .nav-header.scrolled { padding: 6px 0; }
          .nav-mobile-btn { padding: 6px; }
          .nav-mobile-btn svg { width: 22px; height: 22px; }

          .hero { padding-top: 64px; min-height: auto; padding-bottom: 40px; }
          .hero-badge { font-size: 0.6rem; }
          .hero h1 { font-size: clamp(1.5rem, 8vw, 2rem); }
          .hero p { font-size: 0.82rem; margin-bottom: 24px; }
          .hero-actions .btn-primary, .hero-actions .btn-ghost { padding: 10px 20px; font-size: 0.8rem; max-width: 160px; }
          .hero-actions { gap: 8px; }
          .hero-actions .btn-primary svg { display: none; }

          .home-section { padding: 48px 0; }
          .features-grid { gap: 12px; margin-top: 24px; }
          .feature-card { padding: 24px 20px; }
          .feature-icon { width: 36px; height: 36px; font-size: 1rem; margin-bottom: 12px; }
          .feature-card h3 { font-size: 0.9rem; }
          .feature-card p { font-size: 0.78rem; }

          .stats-grid { border-radius: 8px; }
          .stat-item { padding: 20px 12px; }
          .stat-number { font-size: 1.4rem; }

          .novel-grid { gap: 10px; margin-top: 24px; }
          .novel-info { padding: 10px; }
          .novel-info h4 { font-size: 0.78rem; }
          .novel-info .meta { font-size: 0.65rem; }
          .novel-tag { font-size: 0.58rem; padding: 1px 6px; }
          .novel-cover-overlay { display: none; }

          .section-title { font-size: clamp(1.3rem, 6vw, 1.6rem); }
          .section-subtitle { font-size: 0.82rem; }

          .cta-inner { padding: 36px 20px; }
          .cta-inner h2 { font-size: clamp(1.2rem, 6vw, 1.5rem); }
          .cta-inner p { font-size: 0.82rem; margin-bottom: 20px; }

          .home-footer { margin-top: 40px; padding: 28px 0 20px; }
          .footer-copyright { font-size: 0.72rem; }
          .footer-links a { font-size: 0.72rem; }

          .section-divider { padding: 28px 0; }
          .divider-line { height: 40px; }
        }

        @supports (padding-top: env(safe-area-inset-top)) {
          .nav-inner { padding-left: calc(24px + env(safe-area-inset-left)); padding-right: calc(24px + env(safe-area-inset-right)); }
          .mobile-drawer { padding-top: env(safe-area-inset-top); }
          @media (max-width: 768px) { .nav-inner { padding-left: calc(20px + env(safe-area-inset-left)); padding-right: calc(20px + env(safe-area-inset-right)); } }
          @media (max-width: 480px) { .nav-inner { padding-left: calc(16px + env(safe-area-inset-left)); padding-right: calc(16px + env(safe-area-inset-right)); } }
        }

        @media (prefers-reduced-motion: reduce) {
          *, *::before, *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
          }
          .reveal { opacity: 1 !important; transform: none !important; }
          .stagger > * { opacity: 1 !important; transform: none !important; }
        }
      `}),a.jsx("canvas",{id:"ambient-canvas",ref:k}),(0,a.jsxs)("div",{className:"home-wrap",children:[a.jsx("header",{className:`nav-header${v?" scrolled":""}`,children:(0,a.jsxs)("div",{className:"nav-inner",children:[(0,a.jsxs)(i.default,{href:"/",className:"logo-wrap","aria-label":"FireSeed 首页",children:[(0,a.jsxs)("svg",{width:"36",height:"36",viewBox:"0 0 36 36",fill:"none","aria-hidden":"true",children:[a.jsx("circle",{cx:"18",cy:"18",r:"17",stroke:"url(#logo-grad)",strokeWidth:"1.5",opacity:"0.3"}),a.jsx("path",{d:"M18 8C18 8 22 16 18 22C14 16 18 8 18 8Z",fill:"url(#logo-grad)"}),a.jsx("circle",{cx:"18",cy:"22",r:"3",fill:"url(#logo-grad)"}),a.jsx("defs",{children:(0,a.jsxs)("linearGradient",{id:"logo-grad",x1:"0",y1:"0",x2:"36",y2:"36",children:[a.jsx("stop",{offset:"0%",stopColor:"#f59e0b"}),a.jsx("stop",{offset:"100%",stopColor:"#d97706"})]})})]}),a.jsx("span",{className:"logo-text",children:"FireSeed"})]}),(0,a.jsxs)("ul",{className:"nav-links",children:[a.jsx("li",{children:a.jsx(i.default,{href:"/novels",children:"全部作品"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/rpg",children:"AI 跑团"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/tasks",children:"任务市场"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/crowdfunding",children:"众筹广场"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/chat",children:"社区"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/download",children:"火种基地"})}),c?(0,a.jsxs)("li",{style:{position:"relative"},children:[(0,a.jsxs)("button",{onClick:()=>h(!x),className:"nav-user-btn",style:{background:x?"var(--bg-secondary)":"transparent"},children:[a.jsx("div",{className:"w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold",style:{background:"linear-gradient(135deg, var(--accent), var(--accent-light))",color:"white"},children:(c.nickname||c.username).charAt(0).toUpperCase()}),a.jsx("span",{className:"text-sm font-medium hide-mobile",children:c.nickname||c.username}),a.jsx("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",className:`transition-transform ${x?"rotate-180":""}`,children:a.jsx("path",{d:"M4 6l4 4 4-4",strokeLinecap:"round",strokeLinejoin:"round"})})]}),x&&(0,a.jsxs)(a.Fragment,{children:[a.jsx("div",{className:"fixed inset-0 z-10",onClick:()=>h(!1)}),(0,a.jsxs)("div",{className:"absolute right-0 top-full mt-2 w-48 rounded-xl overflow-hidden z-20",style:{background:"var(--bg-card)",border:"1px solid var(--border)",boxShadow:"0 8px 32px rgba(0,0,0,0.5)"},children:[(0,a.jsxs)("div",{className:"px-4 py-3",style:{borderBottom:"1px solid var(--border-light)"},children:[a.jsx("p",{className:"text-sm font-medium",style:{color:"var(--text-primary)"},children:c.nickname||c.username}),(0,a.jsxs)("p",{className:"text-xs mt-0.5",style:{color:"var(--text-muted)"},children:["@",c.username," \xb7 ","admin"===c.role?"管理员":"普通用户"]})]}),(0,a.jsxs)("div",{className:"py-1",children:[(0,a.jsxs)(i.default,{href:"/my",className:"flex items-center gap-3 px-4 py-2.5 text-sm transition-colors",style:{color:"var(--text-secondary)"},onClick:()=>h(!1),children:[(0,a.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("path",{d:"M8 8a3 3 0 100-6 3 3 0 000 6z",strokeLinecap:"round"}),a.jsx("path",{d:"M13 14c0-2.8-2.2-5-5-5s-5 2.2-5 5",strokeLinecap:"round"})]}),"个人中心"]}),"admin"===c.role&&(0,a.jsxs)(i.default,{href:"/admin",className:"flex items-center gap-3 px-4 py-2.5 text-sm transition-colors",style:{color:"var(--accent)"},onClick:()=>h(!1),children:[(0,a.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("rect",{x:"2",y:"3",width:"12",height:"10",rx:"2"}),a.jsx("path",{d:"M5 7h6M5 10h4"})]}),"管理后台"]})]}),a.jsx("div",{style:{borderTop:"1px solid var(--border-light)"},children:(0,a.jsxs)("button",{onClick:D,disabled:f,className:"flex items-center gap-3 px-4 py-2.5 text-sm w-full text-left transition-colors",style:{color:"#ef4444"},children:[a.jsx("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:a.jsx("path",{d:"M6 14H3a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1h3M11 11l3-3-3-3M14 8H6"})}),f?"退出中...":"退出登录"]})})]})]})]}):(0,a.jsxs)("li",{style:{display:"flex",alignItems:"center",gap:8},children:[a.jsx(i.default,{href:"/auth/login",className:"btn-ghost",style:{fontSize:"0.85rem",padding:"8px 16px"},children:"登录"}),a.jsx(i.default,{href:"/auth/register",className:"btn-primary",style:{fontSize:"0.85rem",padding:"8px 20px",borderRadius:100,textDecoration:"none"},children:"注册"})]})]}),(0,a.jsxs)("div",{className:"nav-mobile-wrap",children:[!c&&a.jsx(i.default,{href:"/auth/register",className:"btn-primary",style:{padding:"8px 20px",fontSize:"0.8rem",borderRadius:100,whiteSpace:"nowrap",textDecoration:"none"},children:"开始创作"}),a.jsx("button",{className:"nav-mobile-btn",onClick:()=>g(!0),"aria-label":"菜单",children:(0,a.jsxs)("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",children:[a.jsx("line",{x1:"4",y1:"7",x2:"20",y2:"7"}),a.jsx("line",{x1:"4",y1:"12",x2:"20",y2:"12"}),a.jsx("line",{x1:"4",y1:"17",x2:"20",y2:"17"})]})})]})]})}),a.jsx("div",{className:`drawer-overlay${m?" open":""}`,onClick:z}),(0,a.jsxs)("div",{className:`mobile-drawer${m?" open":""}`,children:[(0,a.jsxs)("div",{className:"drawer-header",children:[a.jsx("span",{className:"logo-text",style:{fontSize:"1rem"},children:"FireSeed"}),a.jsx("button",{className:"drawer-close",onClick:z,children:"\xd7"})]}),(0,a.jsxs)("ul",{className:"drawer-links",children:[a.jsx("li",{children:a.jsx(i.default,{href:"/",onClick:z,children:"首页"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/novels",onClick:z,children:"全部作品"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/rpg",onClick:z,children:"AI 跑团"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/tasks",onClick:z,children:"任务市场"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/crowdfunding",onClick:z,children:"众筹广场"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/chat",onClick:z,children:"社区"})}),a.jsx("li",{children:a.jsx(i.default,{href:"/download",onClick:z,children:"火种基地"})}),c?(0,a.jsxs)(a.Fragment,{children:[a.jsx("li",{style:{borderTop:"1px solid var(--border)",marginTop:8,paddingTop:8},children:(0,a.jsxs)("div",{style:{padding:"8px 12px",fontSize:"0.85rem",color:"var(--text-muted)"},children:[c.nickname||c.username," \xb7 @",c.username]})}),a.jsx("li",{children:a.jsx(i.default,{href:"/my",onClick:z,children:"个人中心"})}),"admin"===c.role&&a.jsx("li",{children:a.jsx(i.default,{href:"/admin",onClick:z,style:{color:"var(--accent)"},children:"管理后台"})}),a.jsx("li",{children:a.jsx("button",{onClick:()=>{D(),z()},style:{color:"#ef4444"},children:"退出登录"})})]}):a.jsx("li",{children:a.jsx(i.default,{href:"/auth/register",onClick:z,className:"drawer-cta",children:"免费注册"})})]})]}),a.jsx("section",{className:"hero",id:"main-content",children:a.jsx("div",{className:"section-container",style:{width:"100%"},children:(0,a.jsxs)("div",{className:"hero-grid",children:[(0,a.jsxs)("div",{children:[(0,a.jsxs)("div",{className:"hero-badge",children:[a.jsx("span",{className:"dot"}),"AI 驱动 \xb7 互动叙事 \xb7 未来已来"]}),(0,a.jsxs)("h1",{children:["一粒",a.jsx("span",{className:"highlight",children:"火种"}),a.jsx("br",{}),"便能改写故事的",a.jsx("span",{className:"highlight",children:"未来"})]}),(0,a.jsxs)("p",{children:["在这里，AI 与人类的创作边界被重新定义。",j.totalNovels>0&&` ${j.totalNovels} 部作品、${j.totalChapters} 章内容，`,"每一次选择都生成独一无二的故事分支——你既是读者，也是故事的共同缔造者。"]}),(0,a.jsxs)("div",{className:"hero-actions",children:[(0,a.jsxs)(i.default,{href:"/auth/register",className:"btn-primary",children:["开始创作",a.jsx("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",children:a.jsx("path",{d:"M2 7h10M8 3l4 4-4 4",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})})]}),a.jsx(i.default,{href:"/novels",className:"btn-ghost",children:"浏览作品"})]})]}),a.jsx("div",{className:"hero-visual",children:(0,a.jsxs)("div",{className:"hero-orbs",children:[a.jsx("div",{className:"orb orb-1"}),a.jsx("div",{className:"orb orb-2"}),a.jsx("div",{className:"orb orb-3"}),a.jsx("div",{className:"hero-ring"}),a.jsx("div",{className:"hero-ring hero-ring-2"}),(0,a.jsxs)("div",{className:"hero-float-items",children:[(0,a.jsxs)("div",{className:"float-item",children:[a.jsx("strong",{children:C(j.totalWords)})," 万字 \xb7 AI 生成"]}),(0,a.jsxs)("div",{className:"float-item",children:[a.jsx("strong",{children:j.totalChapters})," 章 \xb7 分支叙事"]}),(0,a.jsxs)("div",{className:"float-item",children:[a.jsx("strong",{children:j.totalAuthors||j.totalNovels})," 位创作者"]})]})]})})]})})}),a.jsx("section",{className:"home-section",id:"features",children:(0,a.jsxs)("div",{className:"section-container",children:[(0,a.jsxs)("div",{className:"reveal",children:[a.jsx("div",{className:"section-label",children:"Capabilities"}),a.jsx("div",{className:"showcase-header",children:(0,a.jsxs)("div",{children:[(0,a.jsxs)("h2",{className:"section-title",children:["AI 创作 \xd7 人类阅读",a.jsx("br",{}),"重新定义叙事"]}),a.jsx("p",{className:"section-subtitle",children:"不止是自动写作，更是一个让 AI 与人类共同探索故事可能性的创作生态"})]})})]}),(0,a.jsxs)("div",{className:"features-grid stagger",id:"features-grid",children:[(0,a.jsxs)("div",{className:"feature-card",children:[a.jsx("div",{className:"feature-icon amber",children:"✧"}),a.jsx("h3",{children:"AI 自动写作"}),a.jsx("p",{children:"基于大语言模型的智能创作引擎，支持风格可控的章节生成、分支剧情构建，让灵感从概念到成稿一气呵成。"})]}),(0,a.jsxs)("div",{className:"feature-card",children:[a.jsx("div",{className:"feature-icon frost",children:"◈"}),a.jsx("h3",{children:"互动叙事引擎"}),a.jsx("p",{children:"每个关键节点提供多分支选择，AI 实时生成后续剧情。同一部作品，千人千面，每一次阅读都是独一无二的冒险。"})]}),(0,a.jsxs)("div",{className:"feature-card",children:[a.jsx("div",{className:"feature-icon amber",children:"✦"}),a.jsx("h3",{children:"人类共创社区"}),a.jsx("p",{children:"不只是读者。你可以 fork 作品、贡献分支、投票决定剧情走向。平台连接每一位创作者，让故事在协作中生长。"})]}),(0,a.jsxs)("div",{className:"feature-card",children:[a.jsx("div",{className:"feature-icon frost",children:"◇"}),a.jsx("h3",{children:"多模态故事体验"}),a.jsx("p",{children:"文字、配图、背景音乐三位一体。AI 自动为章节生成插画与氛围音效，让阅读升级为沉浸式感官体验。"})]}),(0,a.jsxs)("div",{className:"feature-card",children:[a.jsx("div",{className:"feature-icon amber",children:"☆"}),a.jsx("h3",{children:"SEED 创作者经济"}),a.jsx("p",{children:"点赞、创作、互动均可获得 SEED 积分。积分可用于解锁高级功能、打赏作者、参与社区治理，让创作有价值回报。"})]}),(0,a.jsxs)("div",{className:"feature-card",children:[a.jsx("div",{className:"feature-icon frost",children:"▽"}),a.jsx("h3",{children:"开放生态"}),a.jsx("p",{children:"API 开放、数据可导出、支持自定义 AI 模型接入。不做封闭花园，做 AI 叙事领域的开源基础设施。"})]})]})]})}),a.jsx("div",{className:"section-divider",children:a.jsx("div",{className:"divider-line"})}),a.jsx("section",{className:"home-section",id:"showcase",children:(0,a.jsxs)("div",{className:"section-container",children:[(0,a.jsxs)("div",{className:"reveal",children:[a.jsx("div",{className:"section-label",children:"Platform"}),(0,a.jsxs)("div",{className:"showcase-header",children:[(0,a.jsxs)("div",{children:[a.jsx("h2",{className:"section-title",children:"从火种到燎原"}),(0,a.jsxs)("p",{className:"section-subtitle",children:["我们相信，一粒火种可以点燃整片草原。",a.jsx("br",{}),"以下数据见证了社区的成长"]})]}),a.jsx("div",{className:"section-subtitle",style:{textAlign:"right"},children:a.jsx("span",{className:"text-gradient",style:{fontFamily:"'Orbitron',monospace",fontSize:"0.85rem",letterSpacing:"0.05em"},children:"LIVE \xb7 实时更新"})})]})]}),(0,a.jsxs)("div",{className:"stats-grid stagger",id:"stats-grid",children:[(0,a.jsxs)("div",{className:"stat-item",children:[a.jsx("div",{className:"stat-number",children:j.totalNovels}),a.jsx("div",{className:"stat-label",children:"部 AI 作品"})]}),(0,a.jsxs)("div",{className:"stat-item",children:[a.jsx("div",{className:"stat-number",children:j.totalChapters}),a.jsx("div",{className:"stat-label",children:"章节内容"})]}),(0,a.jsxs)("div",{className:"stat-item",children:[a.jsx("div",{className:"stat-number",children:C(j.totalWords)}),a.jsx("div",{className:"stat-label",children:j.totalWords>=1e4?"万字 \xb7 累计":"字 \xb7 累计"})]}),(0,a.jsxs)("div",{className:"stat-item",children:[a.jsx("div",{className:"stat-number",children:j.totalAuthors||"-"}),a.jsx("div",{className:"stat-label",children:"注册作者"})]})]})]})}),a.jsx("div",{className:"section-divider",children:a.jsx("div",{className:"divider-line"})}),a.jsx("section",{className:"home-section",id:"novels",children:(0,a.jsxs)("div",{className:"section-container",children:[(0,a.jsxs)("div",{className:"reveal",children:[a.jsx("div",{className:"section-label",children:"Featured"}),(0,a.jsxs)("div",{className:"showcase-header",children:[(0,a.jsxs)("div",{children:[a.jsx("h2",{className:"section-title",children:"精选作品"}),a.jsx("p",{className:"section-subtitle",children:"每一部都是 AI 与人类共创的独特叙事实验"})]}),a.jsx(i.default,{href:"/novels",style:{fontFamily:"'Orbitron',monospace",fontSize:"0.8rem",color:"var(--accent)",textDecoration:"none",whiteSpace:"nowrap",display:"flex",alignItems:"center",gap:4},children:"查看全部 →"})]})]}),!t&&e.length>0&&a.jsx("div",{className:"novel-grid stagger",id:"novel-grid",children:e.map((e,r)=>{let t=e.tags?.split(",")[0]?.trim()||"故事",n=S[t]||"✨",s=Math.min((e.chapterCount||0)/30*100,100);return(0,a.jsxs)(i.default,{href:`/novels/${e.id}`,className:"novel-card",style:{textDecoration:"none"},children:[(0,a.jsxs)("div",{className:"novel-cover-wrap",children:[a.jsx(o.Z,{src:e.cover_url,alt:e.title,tag:e.tags}),a.jsx("div",{className:"novel-cover-overlay",children:a.jsx("span",{children:"READ →"})})]}),(0,a.jsxs)("div",{className:"novel-info",children:[a.jsx("h4",{children:e.title}),(0,a.jsxs)("div",{className:"meta",children:[(0,a.jsxs)("span",{children:[n," ",t]}),"completed"===e.status&&a.jsx("span",{className:"novel-tag",children:"完结"}),"completed"!==e.status&&"completed"!==e.status&&a.jsx("span",{className:"novel-tag",children:"连载"})]}),"completed"!==e.status&&(0,a.jsxs)("div",{style:{marginTop:8},children:[(0,a.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",fontSize:"0.65rem",color:"var(--text-muted)",marginBottom:4},children:[a.jsx("span",{children:"AI 生成进度"}),(0,a.jsxs)("span",{children:[Math.round(s),"%"]})]}),a.jsx("div",{style:{height:3,borderRadius:2,background:"var(--border-light)",overflow:"hidden"},children:a.jsx("div",{style:{width:`${s}%`,height:"100%",borderRadius:2,background:"linear-gradient(90deg, var(--accent), var(--accent-light))"}})})]}),a.jsx("div",{className:"meta",style:{marginTop:6},children:(0,a.jsxs)("span",{children:[e.chapterCount||0," 章"]})}),e.tags&&a.jsx("div",{style:{display:"flex",flexWrap:"wrap",gap:4,marginTop:8},children:e.tags.split(",").filter(Boolean).slice(0,3).map(e=>a.jsx("span",{className:"novel-tag",children:e.trim()},e))})]})]},e.id)})}),t&&a.jsx("div",{className:"novel-grid",style:{marginTop:48},children:[1,2,3,4].map(e=>(0,a.jsxs)("div",{className:"novel-card",style:{animation:"pulse 2s ease-in-out infinite"},children:[a.jsx("div",{className:"novel-cover-wrap",style:{background:"var(--bg-secondary)"}}),(0,a.jsxs)("div",{className:"novel-info",children:[a.jsx("div",{style:{height:14,background:"var(--bg-secondary)",borderRadius:4,marginBottom:8,width:"70%"}}),a.jsx("div",{style:{height:10,background:"var(--bg-secondary)",borderRadius:4,width:"40%"}})]})]},e))}),!t&&0===e.length&&(0,a.jsxs)("div",{style:{textAlign:"center",padding:"80px 0"},children:[a.jsx("div",{style:{fontSize:"4rem",marginBottom:16,opacity:.3},children:"✦"}),a.jsx("h3",{style:{fontSize:"1.3rem",fontWeight:600,marginBottom:8},children:"故事正在酝酿中"}),a.jsx("p",{style:{color:"var(--text-secondary)",marginBottom:24},children:"第一部作品即将上线，敬请期待。"}),a.jsx(i.default,{href:"/admin",className:"btn-primary",style:{padding:"12px 28px",borderRadius:100,textDecoration:"none",display:"inline-flex"},children:"进入创作后台"})]})]})}),a.jsx("section",{className:"home-section",style:{paddingTop:0},children:a.jsx("div",{className:"section-container",children:a.jsx("div",{className:"reveal",children:(0,a.jsxs)("div",{className:"cta-inner",children:[(0,a.jsxs)("div",{style:{display:"inline-flex",alignItems:"center",gap:8,padding:"6px 16px 6px 8px",borderRadius:100,background:"var(--accent-glow)",border:"1px solid rgba(245, 158, 11, 0.12)",fontSize:"0.75rem",color:"var(--accent)",marginBottom:24},children:[a.jsx("span",{className:"dot",style:{width:6,height:6,borderRadius:"50%",background:"var(--accent)",display:"inline-block"}}),"正在招募"]}),a.jsx("h2",{style:{fontFamily:"'ZCOOL QingKe HuangYou', serif",fontSize:"clamp(1.8rem, 4vw, 2.6rem)",marginBottom:12,color:"var(--text-primary)"},children:"火种\xb7百人AI作家共创计划"}),a.jsx("p",{style:{color:"var(--text-secondary)",marginBottom:32,maxWidth:520,margin:"0 auto 32px"},children:"100位AI作家，一起用AI写小说，探索互动叙事的可能性"}),a.jsx("div",{className:"btn-group",style:{display:"flex",justifyContent:"center",gap:12,flexWrap:"wrap"},children:(0,a.jsxs)(i.default,{href:"/plan",className:"btn-primary",style:{padding:"14px 32px",borderRadius:100,textDecoration:"none",display:"inline-flex",alignItems:"center",gap:8,fontSize:"0.9rem",fontWeight:600},children:["了解完整方案",a.jsx("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",children:a.jsx("path",{d:"M2 7h10M8 3l4 4-4 4",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})})]})})]})})})}),a.jsx("section",{className:"home-section",style:{paddingTop:0},children:a.jsx("div",{className:"section-container",children:a.jsx("div",{className:"reveal",children:(0,a.jsxs)("div",{style:{background:"linear-gradient(135deg, var(--accent) 0%, var(--accent-light) 100%)",borderRadius:28,padding:"80px 48px",textAlign:"center",position:"relative",overflow:"hidden"},children:[(0,a.jsxs)("div",{style:{position:"relative",zIndex:1},children:[a.jsx("h2",{style:{fontSize:"clamp(1.8rem, 4vw, 2.6rem)",fontWeight:700,color:"#fff",marginBottom:12},children:"解锁全部剧情分支"}),a.jsx("p",{style:{color:"rgba(255,255,255,0.85)",marginBottom:32,maxWidth:480,margin:"0 auto 32px"},children:"升级会员，探索每一条隐藏支线，体验完整的故事宇宙"}),(0,a.jsxs)(i.default,{href:"/vip",style:{display:"inline-flex",alignItems:"center",gap:8,padding:"14px 32px",borderRadius:100,background:"#fff",color:"var(--accent)",fontWeight:600,fontSize:"0.9rem",textDecoration:"none"},children:["了解会员权益",a.jsx("svg",{width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",stroke:"currentColor",strokeWidth:"2",children:a.jsx("path",{d:"M2 7h10M8 3l4 4-4 4",strokeLinecap:"round",strokeLinejoin:"round"})})]})]}),a.jsx("div",{style:{position:"absolute",top:-40,right:-40,width:160,height:160,borderRadius:"50%",background:"rgba(255,255,255,0.08)"}}),a.jsx("div",{style:{position:"absolute",bottom:-40,left:-40,width:120,height:120,borderRadius:"50%",background:"rgba(255,255,255,0.05)"}})]})})})}),a.jsx("section",{className:"home-section",style:{paddingTop:0},children:a.jsx("div",{className:"section-container",children:a.jsx("div",{className:"reveal",children:(0,a.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"repeat(2, 1fr)",gap:48,maxWidth:640,margin:"0 auto"},children:[(0,a.jsxs)("div",{style:{textAlign:"center"},children:[a.jsx("div",{style:{display:"inline-block",borderRadius:16,padding:12,background:"#fff",border:"1px solid var(--border)",marginBottom:12},children:a.jsx("img",{src:"https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=https://fireseed.online",alt:"扫码访问 fireseed.online",width:"160",height:"160",style:{display:"block",imageRendering:"pixelated"}})}),a.jsx("p",{style:{fontSize:"0.85rem",fontWeight:500,color:"var(--text-primary)",marginBottom:4},children:"扫码访问"}),a.jsx("p",{style:{fontSize:"0.75rem",color:"var(--text-muted)"},children:"浏览器或微信扫一扫，手机直接看"})]}),(0,a.jsxs)("div",{style:{textAlign:"center"},children:[a.jsx("div",{style:{display:"inline-block",borderRadius:16,padding:12,background:"#fff",border:"1px solid var(--border)",marginBottom:12},children:a.jsx("img",{src:"/qq-group.jpg",alt:"QQ群 火种源",width:"160",height:"160",style:{display:"block",imageRendering:"pixelated"}})}),a.jsx("p",{style:{fontSize:"0.85rem",fontWeight:500,color:"var(--text-primary)",marginBottom:4},children:"QQ群：火种源"}),a.jsx("p",{style:{fontSize:"0.75rem",color:"var(--text-muted)",marginBottom:4},children:"扫码加入 QQ 群，与 AI 作者交流"}),a.jsx("p",{style:{fontSize:"0.75rem",color:"var(--accent)"},children:"与 AI 作者一起创作"}),a.jsx("a",{href:"https://qm.qq.com/q/LPUZ9jSqC6",target:"_blank",rel:"noopener noreferrer",style:{display:"inline-block",marginTop:8,fontSize:"0.75rem",color:"var(--text-muted)",textDecoration:"underline"},children:"点击直接加群 →"})]})]})})})}),a.jsx("footer",{className:"home-footer",children:(0,a.jsxs)("div",{style:{maxWidth:1200,margin:"0 auto",padding:"0 24px",textAlign:"center"},children:[(0,a.jsxs)("div",{style:{maxWidth:560,margin:"0 auto 32px",color:"var(--text-muted)",fontSize:"0.85rem",lineHeight:1.8},children:["一粒火种微弱，众火方成燎原。",a.jsx("br",{}),"FireSeed 从诞生之初，就是为AI网文创作发布而生。未来的AI小说将有专属的宇宙空间。",a.jsx("br",{}),a.jsx("br",{}),"诚招有兴趣玩玩的核心伙伴，不以工作为目的，只以共建专属创作者的免费AI写作发布平台为初心，慢慢打磨、共同成长。",a.jsx("br",{}),a.jsx("br",{}),"期待同频的你，一起守着这份热爱，深耕网文创作，完善专属我们的创作工具。"]}),a.jsx("a",{href:"mailto:50541358@qq.com",style:{display:"inline-block",marginBottom:32,padding:"10px 24px",borderRadius:100,fontSize:"0.85rem",fontWeight:500,background:"linear-gradient(135deg, var(--accent), var(--accent-light))",color:"#fff",textDecoration:"none"},children:"联系我们 → 50541358@qq.com"}),(0,a.jsxs)("div",{className:"footer-inner",style:{borderTop:"1px solid var(--border)",paddingTop:24,marginTop:0},children:[(0,a.jsxs)("div",{className:"footer-copyright",children:[a.jsx("span",{style:{fontFamily:"'Orbitron',monospace",fontWeight:600,background:"linear-gradient(135deg,var(--accent),#fbbf24)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"},children:"FireSeed"}),a.jsx("span",{style:{color:"var(--text-muted)",marginLeft:8},children:"\xa9 2026 \xb7 AI 互动叙事平台"})]}),(0,a.jsxs)("div",{className:"footer-links",children:[a.jsx("a",{href:"/novels",children:"全部作品"}),a.jsx("a",{href:"/plan",children:"火种计划"}),a.jsx("a",{href:"/skills",children:"\uD83D\uDD25 技能排行榜"}),a.jsx("a",{href:"/seed/leaderboard",children:"\uD83C\uDFC6 SEED 富豪榜"}),a.jsx("a",{href:"/feedback",children:"反馈"}),a.jsx("a",{href:"/api/rss",target:"_blank",children:"\uD83D\uDCE1 RSS"})]})]})]})})]})]})}},49779:(e,r,t)=>{"use strict";t.d(r,{Z:()=>s});var a=t(10326),i=t(17577),n=t(46226);function s({src:e,alt:r,tag:t,className:s="",aspectRatio:o="aspect-[3/4]"}){let[l,d]=(0,i.useState)(!1),[c,p]=(0,i.useState)(!1),x=(0,i.useCallback)(()=>d(!0),[]),h=(0,i.useCallback)(()=>p(!0),[]),m=t?.split(",")[0]?.trim()||"故事",g=e&&!l;return a.jsx("div",{className:`relative overflow-hidden ${o} ${s}`,children:g?(0,a.jsxs)(a.Fragment,{children:[a.jsx(n.default,{src:e,alt:r,fill:!0,sizes:"(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw",className:`object-cover transition-all duration-500 ${c?"opacity-100":"opacity-0"}`,onError:x,onLoad:h,priority:!1,quality:80}),!c&&a.jsx("div",{className:"absolute inset-0 flex items-center justify-center",style:{background:"var(--bg-secondary)"},children:a.jsx("div",{className:"w-6 h-6 border-2 rounded-full animate-spin",style:{borderColor:"var(--accent)",borderTopColor:"transparent"}})})]}):(0,a.jsxs)("div",{className:"absolute inset-0 flex flex-col items-center justify-center",style:{background:{玄幻:"linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",都市:"linear-gradient(135deg, #2d3436 0%, #636e72 50%, #b2bec3 100%)",仙侠:"linear-gradient(135deg, #5c3d1e 0%, #8b5e3c 50%, #c49a6c 100%)",言情:"linear-gradient(135deg, #6b21a8 0%, #db2777 50%, #f472b6 100%)",科幻:"linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #38bdf8 100%)",悬疑:"linear-gradient(135deg, #111827 0%, #374151 50%, #6b7280 100%)",历史:"linear-gradient(135deg, #78350f 0%, #92400e 50%, #d97706 100%)",武侠:"linear-gradient(135deg, #1c1917 0%, #44403c 50%, #78716c 100%)",奇幻:"linear-gradient(135deg, #312e81 0%, #5b21b6 50%, #8b5cf6 100%)"}[m]||"linear-gradient(135deg, #5c3d1e 0%, #8b5e3c 50%, #c49a6c 100%)"},children:[a.jsx("div",{className:"w-12 h-12 rounded-full border-2 border-white/20 flex items-center justify-center mb-3",children:a.jsx("span",{className:"text-2xl",children:{玄幻:"⚡",都市:"\uD83C\uDFD9",仙侠:"\uD83C\uDFEF",言情:"\uD83D\uDC95",科幻:"\uD83D\uDE80",悬疑:"\uD83D\uDD2E",历史:"\uD83D\uDCDC",恐怖:"\uD83D\uDC7B",军事:"⚔️",奇幻:"\uD83D\uDD2E",武侠:"⚡",故事:"✨"}[m]||"✨"})}),a.jsx("span",{className:"text-white/60 text-xs font-medium tracking-widest uppercase",children:m})]})})}},90908:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>a});let a=(0,t(68570).createProxy)(String.raw`E:\SaiBohuman\赛博卧龙\小说创作\ai-novel-lite\app\page.tsx#default`)}};var r=require("../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[8948,848,6907,9712],()=>t(74647));module.exports=a})();