"use strict";exports.id=6366,exports.ids=[6366],exports.modules={43458:(e,r,t)=>{t.d(r,{BU:()=>d,BV:()=>y,D4:()=>p,HB:()=>c,OF:()=>E,S$:()=>h,YD:()=>m,dy:()=>R,fC:()=>O,fz:()=>g,ks:()=>n,nf:()=>S,oj:()=>f,qz:()=>u,rj:()=>T,u5:()=>b,uG:()=>N,vW:()=>_});var a=t(9576),s=t(9487),i=t(94877);let l=[{level:0,score:0,label:"见习冒险者"},{level:1,score:50,label:"熟练旅人"},{level:2,score:200,label:"资深创作者"},{level:3,score:800,label:"大师匠人"},{level:4,score:3e3,label:"传说工匠"},{level:5,score:1e4,label:"千古巨匠"}];function n(e){let r=s.default.prepare(`
    SELECT id, username, creator_score, creator_level,
           total_public_contributions, total_sales_volume,
           total_rating_sum, total_rating_count
    FROM users WHERE id = ?
  `).get(e);return r?{userId:r.id,username:r.username,score:r.creator_score||0,level:r.creator_level||0,totalContributions:r.total_public_contributions||0,totalSales:r.total_sales_volume||0,avgRating:r.total_rating_count>0?Math.round(r.total_rating_sum/r.total_rating_count*10)/10:0,ratingCount:r.total_rating_count||0}:null}function o(e,r){let t=s.default.prepare("SELECT creator_score, creator_level FROM users WHERE id = ?").get(e);if(!t)throw Error("用户不存在");let a=(t.creator_score||0)+r,i=function(e){let r=0;for(let t of l)e>=t.score&&(r=t.level);return r}(a),n=i>(t.creator_level||0);return s.default.prepare("UPDATE users SET creator_score = ?, creator_level = ? WHERE id = ?").run(a,i,e),{score:a,level:i,leveledUp:n}}function d(e,r,t,i,l="full_copy"){var n;let o=s.default.prepare("SELECT creator_level, username FROM users WHERE id = ?").get(e);if(!o)throw Error("用户不存在");let d=(n=o.creator_level||0)>=3?1/0:n>=2?500:0;if(i>0&&0===d)throw Error("当前等级不能发布付费资产，需要 L2 以上");if(i>d)throw Error(`定价超出等级上限：${d} SEED`);let _=!1;if("character"===r){let r=s.default.prepare("SELECT id, user_id, license_type FROM rpg_characters WHERE id = ?").get(t);if(!r)throw Error("角色卡不存在");if(r.user_id!==e)throw Error("只能出售自己的资产");_=!0}else if("lorebook"===r){let r=s.default.prepare("SELECT id, user_id, license_type FROM rpg_lorebooks WHERE id = ?").get(t);if(!r)throw Error("世界书不存在");if(r.user_id!==e)throw Error("只能出售自己的资产");_=!0}else if("module"===r){let r=s.default.prepare("SELECT id, created_by FROM rpg_campaigns WHERE id = ?").get(t);if(!r)throw Error("战役模组不存在");if(r.created_by!==e)throw Error("只能出售自己的资产");_=!0}if(!_)throw Error("资产不存在");if(s.default.prepare(`
    SELECT id FROM rpg_market_listings
    WHERE asset_id = ? AND asset_type = ? AND status = 'active'
  `).get(t,r))throw Error("该资产已在市场中挂牌");let p=Math.floor(i*("module"===r?.15:.1)),u=i-p,c=(0,a.Z)();return s.default.prepare(`
    INSERT INTO rpg_market_listings (id, asset_type, asset_id, seller_id, price, license_mode, status, platform_fee, creator_share)
    VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)
  `).run(c,r,t,e,i,l,p,u),"character"===r?s.default.prepare("UPDATE rpg_characters SET license_type = 'public_full' WHERE id = ?").run(t):"lorebook"===r?s.default.prepare("UPDATE rpg_lorebooks SET license_type = 'public_full' WHERE id = ?").run(t):"module"===r&&s.default.prepare("UPDATE rpg_campaigns SET license_type = 'public_full' WHERE id = ?").run(t),{id:c,asset_type:r,asset_id:t,seller_id:e,price:i,license_mode:l,status:"active",platform_fee:p,creator_share:u,buyer_id:null,sold_at:null,created_at:new Date().toISOString()}}function _(e,r){let t=s.default.prepare("SELECT * FROM rpg_market_listings WHERE id = ? AND status = ?").get(r,"active");if(!t)throw Error("该商品已下架或不存在");if(t.seller_id===e)throw Error("不能获取自己的资产");let l=0===t.price;if(l&&s.default.prepare("SELECT id FROM rpg_asset_library WHERE user_id = ? AND asset_id = ? AND asset_type = ?").get(e,t.asset_id,t.asset_type))throw Error("你已领取过该资产");if(!l){let r=(0,i.sb)(e);if(r<t.price)throw Error(`SEED 余额不足！当前 ${r} 🌱，需要 ${t.price} 🌱`)}let n="",d=null;if("character"===t.asset_type?(d=s.default.prepare("SELECT id, name, card_data FROM rpg_characters WHERE id = ?").get(t.asset_id),n=d?.name||"角色卡"):"lorebook"===t.asset_type?(d=s.default.prepare("SELECT id, name, description, entries FROM rpg_lorebooks WHERE id = ?").get(t.asset_id),n=d?.name||"世界书","reference_only"===t.license_mode&&(d={...d,_referenceOnly:!0})):"module"===t.asset_type&&(d=s.default.prepare("SELECT id, name, world_brief FROM rpg_campaigns WHERE id = ?").get(t.asset_id),n=d?.name||"战役模组"),!d)throw Error("资产数据不存在");let _=(0,a.Z)();return s.default.transaction(()=>{if(!l){let a=Math.floor(.05*t.price);(0,i.B3)(e,t.seller_id,t.price,"rpg_purchase",{refId:r,description:`购买 ${"character"===t.asset_type?"角色卡":"lorebook"===t.asset_type?"世界书":"战役模组"}：${n}`,platformShare:t.platform_fee}),s.default.prepare(`
        UPDATE rpg_market_listings SET status = 'sold', buyer_id = ?, sold_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(e,r),o(t.seller_id,5),s.default.prepare("UPDATE users SET total_sales_volume = total_sales_volume + ? WHERE id = ?").run(t.price,t.seller_id),a>0&&(0,i.transferSeed)("platform",a,"rpg_purchase",{refId:r,description:`创作者基金注入：${n}`})}if(s.default.prepare(`
      INSERT INTO rpg_asset_library (id, user_id, asset_type, asset_id, license_mode, source, source_listing_id)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(_,e,t.asset_type,t.asset_id,t.license_mode,l?"free_claim":"purchased",r),"character"===t.asset_type)s.default.prepare("UPDATE rpg_characters SET download_count = download_count + 1, copy_count = copy_count + 1 WHERE id = ?").run(t.asset_id);else if("lorebook"===t.asset_type)s.default.prepare("UPDATE rpg_lorebooks SET download_count = download_count + 1, copy_count = copy_count + 1 WHERE id = ?").run(t.asset_id);else if("module"===t.asset_type&&(s.default.prepare("UPDATE rpg_campaigns SET download_count = download_count + 1, copy_count = copy_count + 1 WHERE id = ?").run(t.asset_id),!s.default.prepare("SELECT id FROM rpg_campaign_members WHERE campaign_id = ? AND user_id = ?").get(t.asset_id,e))){let r=s.default.prepare("SELECT id FROM rpg_characters WHERE user_id = ? ORDER BY created_at ASC LIMIT 1").get(e);s.default.prepare(`
          INSERT OR IGNORE INTO rpg_campaign_members (campaign_id, user_id, character_id, role)
          VALUES (?, ?, ?, 'player')
        `).run(t.asset_id,e,r?.id||null)}})(),{success:!0,listing:{...t,status:l?"active":"sold",buyer_id:e},assetData:"reference_only"===t.license_mode?{id:d.id,name:d.name,description:d.description,_referenceOnly:!0}:d}}function p(e,r){let t=s.default.prepare("SELECT * FROM rpg_market_listings WHERE id = ? AND seller_id = ?").get(r,e);if(!t)throw Error("挂牌不存在或无权操作");s.default.prepare("UPDATE rpg_market_listings SET status = 'cancelled' WHERE id = ?").run(r),"character"===t.asset_type?s.default.prepare("UPDATE rpg_characters SET license_type = 'personal' WHERE id = ?").run(t.asset_id):"lorebook"===t.asset_type?s.default.prepare("UPDATE rpg_lorebooks SET license_type = 'personal' WHERE id = ?").run(t.asset_id):"module"===t.asset_type&&s.default.prepare("UPDATE rpg_campaigns SET license_type = 'personal' WHERE id = ?").run(t.asset_id)}function u(e={}){let{assetType:r,sort:t="newest",page:a=1,limit:i=20,search:l}=e,n="ml.status = 'active'",o=[];if(r&&"all"!==r&&(n+=" AND ml.asset_type = ?",o.push(r)),l){let e=l.replace(/([%_\\])/g,"\\$1");n+=" AND (a.name LIKE ? OR a.description LIKE ?)",o.push(`%${e}%`,`%${e}%`)}let d=`
    SELECT COUNT(*) as total FROM rpg_market_listings ml WHERE ${n}
  `,_=s.default.prepare(d).get(...o).total,p=`
    SELECT
      ml.id as listing_id, ml.asset_type, ml.asset_id, ml.price, ml.license_mode,
      ml.seller_id, ml.created_at,
      COALESCE(c.name, l.name, cp.name) as name,
      COALESCE(json_extract(c.card_data, '$.description'), l.description, cp.world_brief) as description,
      u.username as seller_name,
      COALESCE(c.avg_rating, l.avg_rating, cp.avg_rating, 0) as avg_rating,
      COALESCE(c.rating_count, l.rating_count, cp.rating_count, 0) as rating_count,
      COALESCE(c.download_count, l.download_count, cp.download_count, 0) as sales
    FROM rpg_market_listings ml
    LEFT JOIN rpg_characters c ON ml.asset_type = 'character' AND ml.asset_id = c.id
    LEFT JOIN rpg_lorebooks l ON ml.asset_type = 'lorebook' AND ml.asset_id = l.id
    LEFT JOIN rpg_campaigns cp ON ml.asset_type = 'module' AND ml.asset_id = cp.id
    LEFT JOIN users u ON ml.seller_id = u.id
    WHERE ${n}
    ORDER BY ${{newest:"ml.created_at DESC",popular:"sales DESC",price_low:"ml.price ASC",price_high:"ml.price DESC",rating:"avg_rating DESC"}[t]||"ml.created_at DESC"}
    LIMIT ? OFFSET ?
  `;return{items:s.default.prepare(p).all(...o,i,(a-1)*i).map(e=>({id:e.listing_id,name:e.name,type:e.asset_type,description:(e.description||"").slice(0,200),price:e.price,sellerName:e.seller_name,sellerId:e.seller_id,rating:e.avg_rating||0,ratingCount:e.rating_count||0,createdAt:e.created_at})),total:_,page:a,totalPages:Math.ceil(_/i)}}function c(e){return s.default.prepare(`
    SELECT al.*, c.name as char_name, l.name as lore_name, cp.name as campaign_name
    FROM rpg_asset_library al
    LEFT JOIN rpg_characters c ON al.asset_type = 'character' AND al.asset_id = c.id
    LEFT JOIN rpg_lorebooks l ON al.asset_type = 'lorebook' AND al.asset_id = l.id
    LEFT JOIN rpg_campaigns cp ON al.asset_type = 'module' AND al.asset_id = cp.id
    WHERE al.user_id = ? AND al.source IN ('purchased', 'free_claim')
    ORDER BY al.acquired_at DESC
  `).all(e)}function E(e){return s.default.prepare(`
    SELECT ml.*, c.name as char_name, l.name as lore_name, cp.name as campaign_name
    FROM rpg_market_listings ml
    LEFT JOIN rpg_characters c ON ml.asset_type = 'character' AND ml.asset_id = c.id
    LEFT JOIN rpg_lorebooks l ON ml.asset_type = 'lorebook' AND ml.asset_id = l.id
    LEFT JOIN rpg_campaigns cp ON ml.asset_type = 'module' AND ml.asset_id = cp.id
    WHERE ml.seller_id = ?
    ORDER BY ml.created_at DESC
  `).all(e)}function g(e,r,t,i){if(t<1||t>5)throw Error("评价分数需在 1-5 之间");let l=s.default.prepare("SELECT * FROM rpg_market_listings WHERE id = ?").get(e);if(!l)throw Error("交易不存在");if(l.buyer_id!==r)throw Error("只有买家可以评价");if(s.default.prepare("SELECT id FROM rpg_creator_ratings WHERE listing_id = ? AND rater_id = ?").get(e,r))throw Error("已评价过该交易");s.default.prepare(`
    INSERT INTO rpg_creator_ratings (id, listing_id, rater_id, ratee_id, rating, review)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run((0,a.Z)(),e,r,l.seller_id,t,i||null);let n=s.default.prepare(`
    SELECT total_rating_sum, total_rating_count FROM users WHERE id = ?
  `).get(l.seller_id),d=(n.total_rating_sum||0)+t,_=(n.total_rating_count||0)+1;s.default.prepare("UPDATE users SET total_rating_sum = ?, total_rating_count = ? WHERE id = ?").run(d,_,l.seller_id);let p=Math.round(d/_*10)/10;"character"===l.asset_type?s.default.prepare("UPDATE rpg_characters SET avg_rating = ?, rating_count = ? WHERE id = ?").run(p,_,l.asset_id):"lorebook"===l.asset_type?s.default.prepare("UPDATE rpg_lorebooks SET avg_rating = ?, rating_count = ? WHERE id = ?").run(p,_,l.asset_id):"module"===l.asset_type&&s.default.prepare("UPDATE rpg_campaigns SET avg_rating = ?, rating_count = ? WHERE id = ?").run(p,_,l.asset_id),o(l.seller_id,2),o(r,1)}function m(e,r=1,t=10){let a=s.default.prepare("SELECT COUNT(*) as c FROM rpg_creator_ratings WHERE ratee_id = ?").get(e).c;return{ratings:s.default.prepare(`
    SELECT cr.*, u.username as rater_name
    FROM rpg_creator_ratings cr
    LEFT JOIN users u ON cr.rater_id = u.id
    WHERE cr.ratee_id = ?
    ORDER BY cr.created_at DESC
    LIMIT ? OFFSET ?
  `).all(e,t,(r-1)*t),total:a,page:r,totalPages:Math.ceil(a/t)}}function f(e,r){if(r.budget<10)throw Error("预算至少 10 SEED");(0,i.transferSeed)(e,-r.budget,"rpg_commission_pub",{description:`发布创作任务：${r.title}`});let t=(0,a.Z)();return s.default.prepare(`
    INSERT INTO rpg_commission_tasks (id, asset_type, title, description, requester_id, budget, deadline, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'open')
  `).run(t,r.assetType,r.title.trim(),r.description.trim(),e,r.budget,r.deadline||null),{id:t,asset_type:r.assetType,title:r.title,description:r.description,requester_id:e,budget:r.budget,deadline:r.deadline||null,status:"open",assignee_id:null,submitted_at:null,completed_at:null,delivery_asset_id:null,created_at:new Date().toISOString()}}function T(e,r,t){let a=s.default.prepare("SELECT * FROM rpg_commission_tasks WHERE id = ?").get(e);if(!a)throw Error("任务不存在");if("open"!==a.status)throw Error("任务已被接取");if(a.requester_id===r)throw Error("不能接自己的任务");if(t&&a.requester_id!==t)throw Error("无权操作");let i=s.default.prepare("SELECT creator_level FROM users WHERE id = ?").get(r);if(!i||1>(i.creator_level||0))throw Error("信誉等级不足，需要 L1 以上");s.default.prepare("UPDATE rpg_commission_tasks SET status = 'assigned', assignee_id = ? WHERE id = ?").run(r,e)}function R(e,r,t){let a=s.default.prepare("SELECT * FROM rpg_commission_tasks WHERE id = ? AND assignee_id = ?").get(e,r);if(!a)throw Error("任务不存在或无权操作");if("assigned"!==a.status)throw Error("任务状态不正确");s.default.prepare(`
    UPDATE rpg_commission_tasks SET status = 'submitted', submitted_at = CURRENT_TIMESTAMP, delivery_asset_id = ? WHERE id = ?
  `).run(t,e)}function S(e,r){let t=s.default.prepare("SELECT * FROM rpg_commission_tasks WHERE id = ? AND requester_id = ?").get(e,r);if(!t)throw Error("任务不存在或无权操作");if("submitted"!==t.status)throw Error("任务状态不正确，需要已提交");let a=Math.floor(.1*t.budget),l=t.budget-a;s.default.transaction(()=>{(0,i.transferSeed)(t.assignee_id,l,"rpg_commission_pay",{refId:e,description:`创作任务完成：${t.title}`}),a>0&&(0,i.transferSeed)("platform",a,"rpg_commission_pay",{refId:e,description:`创作任务平台抽成：${t.title}`}),s.default.prepare(`
      UPDATE rpg_commission_tasks SET status = 'completed', completed_at = CURRENT_TIMESTAMP WHERE id = ?
    `).run(e)})(),o(t.assignee_id,10+Math.floor(t.budget/10)),o(r,3),s.default.prepare("UPDATE users SET total_sales_volume = total_sales_volume + ? WHERE id = ?").run(l,t.assignee_id)}function O(e,r){let t=s.default.prepare("SELECT * FROM rpg_commission_tasks WHERE id = ? AND requester_id = ?").get(e,r);if(!t)throw Error("任务不存在或无权操作");if("submitted"!==t.status)throw Error("任务状态不正确");s.default.prepare("UPDATE rpg_commission_tasks SET status = 'disputed' WHERE id = ?").run(e)}function y(e){let r=s.default.prepare("SELECT * FROM rpg_commission_tasks WHERE id = ? AND status = ?").get(e,"disputed");if(!r)throw Error("任务不存在或状态不正确");s.default.transaction(()=>{(0,i.transferSeed)(r.requester_id,r.budget,"rpg_commission_refund",{refId:e,description:`创作任务退款：${r.title}`}),s.default.prepare("UPDATE rpg_commission_tasks SET status = 'cancelled' WHERE id = ?").run(e)})()}function h(e,r){let t=s.default.prepare("SELECT * FROM rpg_commission_tasks WHERE id = ? AND requester_id = ? AND status = ?").get(e,r,"open");if(!t)throw Error("任务不存在或无权操作");s.default.transaction(()=>{(0,i.transferSeed)(t.requester_id,t.budget,"rpg_commission_refund",{refId:e,description:`取消创作任务退款：${t.title}`}),s.default.prepare("UPDATE rpg_commission_tasks SET status = 'cancelled' WHERE id = ?").run(e)})()}function N(e={}){let{status:r,assetType:t,page:a=1,limit:i=20}=e,l=[],n=[];r&&(l.push("status = ?"),n.push(r)),t&&(l.push("asset_type = ?"),n.push(t));let o=l.length>0?"WHERE "+l.join(" AND "):"",d=s.default.prepare(`SELECT COUNT(*) as c FROM rpg_commission_tasks ${o}`).get(...n).c;return{tasks:s.default.prepare(`
    SELECT ct.*, u.username as requester_name, a.username as assignee_name
    FROM rpg_commission_tasks ct
    LEFT JOIN users u ON ct.requester_id = u.id
    LEFT JOIN users a ON ct.assignee_id = a.id
    ${o}
    ORDER BY ct.created_at DESC LIMIT ? OFFSET ?
  `).all(...n,i,(a-1)*i),total:d}}function b(e){let r=(0,a.Z)(),t=(0,a.Z)(),i=(0,a.Z)(),l=(0,a.Z)();return s.default.prepare(`
    INSERT INTO rpg_characters (id, user_id, name, spec_version, card_data, system, is_public, seed_price, license_type, char_type)
    VALUES (?, ?, ?, '2.0', ?, 'dnd5e', 0, 0, 'personal', 'dedicated')
  `).run(r,e,"李青云",JSON.stringify({name:"李青云",description:"一位出身平凡的年轻剑客，自幼在山村长大。一场突如其来的变故让他踏上了冒险之路。他性格温和但意志坚定，手持一柄祖传铁剑，虽然不是什么神兵利器，却承载着他全部的信念。",personality:"善良、坚韧，带着年轻人特有的好奇心与热血。说话坦诚，有时显得天真，但在关键时刻总能做出正确的选择。对陌生人保持友善，但内心有自己的底线。",scenario:'李青云离开家乡已经三天了。沿着山间小路走了许久，他终于在黄昏时分来到了一座小镇——"雾隐镇"。镇口的告示牌上写着"欢迎来到雾隐镇——冒险者的起点"。',first_mes:'"终于到了……"你站在镇口，望着远处炊烟袅袅的屋顶，深吸一口气。背后是连绵的群山，前方是未知但充满可能的冒险。你摸了摸腰间的铁剑，迈步走进了雾隐镇。',mes_example:"",system_prompt:"",post_history_instructions:"",tags:["新手","剑客","冒险"],creator:"系统",character_version:"1.0",trpg:{system:"dnd5e",level:1,attributes:{力量:14,敏捷:13,体质:12,智力:10,感知:11,魅力:12},skills:{剑术:4,运动:3,察觉:2,求生:2},hp:{current:12,max:12},equipment:["祖传铁剑","旅行者服装","背包","干粮（3天）","水囊","10枚铜币"],spells:[],backstory:'李青云出生在一个偏远的山村，从小跟着爷爷学习基础剑术。18岁那年，爷爷将祖传铁剑交到他手中，鼓励他出去闯荡。"去看看外面的世界，"爷爷说，"但记住，剑是用来保护人的，不是用来伤害人的。"',inventory:[{name:"家书",quantity:1,description:"爷爷写的平安信"}]}})),s.default.prepare(`
    INSERT INTO rpg_lorebooks (id, name, description, user_id, entries, is_public, st_compatible, seed_price, license_type)
    VALUES (?, ?, ?, ?, ?, 0, 1, 0, 'personal')
  `).run(t,"雾隐大陆","一本简明的大陆设定集，包含雾隐镇及周边地区的基本信息，适合新手冒险者快速了解世界。",e,JSON.stringify([{keys:["雾隐镇","雾隐"],content:'雾隐镇是冒险者的起始之地，坐落于雾隐大陆的中央平原。小镇不大，但五脏俱全：有一家"醉仙楼"酒馆、一间杂货铺、一座冒险者公会分部，以及一座供奉战神的小神庙。镇长是一位退休的老冒险者，名叫赵铁柱。',priority:10,constant:!0,selective:!1},{keys:["冒险者公会","公会"],content:"雾隐镇冒险者公部分部是一栋两层石楼。一楼是任务大厅，张贴着各种委托——从驱赶野兽到护送商队应有尽有。二楼是休息区和装备寄存处。公会负责人是一位名叫林婉儿的年轻女性，她总是笑容满面但办事效率极高。",priority:8,constant:!1,selective:!1},{keys:["醉仙楼","酒馆"],content:'醉仙楼是雾隐镇最大的酒馆，老板是一位胖乎乎的中年人"王胖子"。这里提供各种美食和饮品，也是冒险者们交换情报的地方。招牌菜是"红烧灵猪肉"，招牌酒是"百年醉仙酿"（价格不菲但物有所值）。',priority:6,constant:!1,selective:!1},{keys:["暗影森林","森林"],content:"位于雾隐镇以北十里的一片古老森林。据说林中栖息着各种奇异生物，偶尔还有冒险者报告在深处发现了古老遗迹。森林外围相对安全，但越往深处走，危险越大。新手冒险者通常只在外围完成采集和猎杀任务。",priority:7,constant:!1,selective:!1}])),s.default.prepare(`
    INSERT INTO rpg_campaigns (id, name, mode, system, gm_type, world_brief, lorebook_id, status, created_by)
    VALUES (?, ?, 'solo', 'dnd5e', 'ai', ?, ?, 'active', ?)
  `).run(i,"雾隐镇初冒险","你是一名初出茅庐的冒险者，刚刚来到雾隐镇。在这里，你将接到第一个任务，认识第一个伙伴，迈出冒险生涯的第一步。前往冒险者公会，开始你的故事吧！",t,e),s.default.prepare(`
    INSERT OR IGNORE INTO rpg_campaign_members (campaign_id, user_id, character_id, role)
    VALUES (?, ?, ?, 'player')
  `).run(i,e,r),s.default.prepare(`
    INSERT INTO rpg_sessions (id, campaign_id, title, session_number, status)
    VALUES (?, ?, '第1章: 初到雾隐镇', 1, 'active')
  `).run(l,i),{characterId:r,lorebookId:t,campaignId:i}}},94877:(e,r,t)=>{t.d(r,{B3:()=>o,Zp:()=>_,f1:()=>d,jq:()=>p,k:()=>i,sb:()=>l,transferSeed:()=>n});var a=t(9576),s=t(9487);function i(e){let r=s.default.prepare("SELECT * FROM wallets WHERE user_id = ?").get(e);return r||(s.default.prepare("INSERT INTO wallets (user_id, balance, total_earned, total_spent) VALUES (?, 0, 0, 0)").run(e),r=s.default.prepare("SELECT * FROM wallets WHERE user_id = ?").get(e)),r}function l(e){let r=s.default.prepare("SELECT balance FROM wallets WHERE user_id = ?").get(e);return r?.balance??0}function n(e,r,t,n){if(r<0){let t=l(e);if(t+r<0)throw Error(`余额不足：当前 ${t} 🌱，需要 ${Math.abs(r)} 🌱`)}return s.default.transaction(()=>{let l=i(e).balance+r;s.default.prepare(`
      UPDATE wallets SET balance = ?, total_earned = total_earned + ?, total_spent = total_spent + ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).run(l,r>0?r:0,r<0?Math.abs(r):0,e);let o=(0,a.Z)();return s.default.prepare(`
      INSERT INTO transactions (id, user_id, target_id, type, ref_id, amount, balance_after, description)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(o,e,n?.targetId||null,t,n?.refId||null,r,l,n?.description||null),l})()}function o(e,r,t,a,i){if(t<=0)throw Error("转账金额必须为正数");let l=i?.platformShare||0,o=t-l;return s.default.transaction(()=>{let s;let d=n(e,-t,a,{refId:i?.refId,description:i?.description}),_=n(r,o,a,{targetId:e,refId:i?.refId,description:i?.description});return l>0&&(s=n("platform",l,a,{refId:i?.refId,description:`平台抽佣 ${l} SEED`})),{fromBalance:d,toBalance:_,platformBalance:s}})()}function d(e,r=20,t=0){return s.default.prepare(`
    SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(e,r,t)}function _(e=20){return s.default.prepare(`
    SELECT w.user_id, u.username, w.balance, w.total_earned
    FROM wallets w
    JOIN users u ON w.user_id = u.id
    WHERE w.balance > 0 AND u.role != 'admin'
    ORDER BY w.balance DESC
    LIMIT ?
  `).all(e)}function p(e,r){let t=l("platform");if(t<e)throw Error(`平台余额不足: ${t} < ${e}`);n("platform",-e,"burn",{description:r||`销毁 ${e} SEED`});let a=new Date().toISOString().slice(0,10);s.default.prepare(`
    INSERT INTO daily_economy_stats (date, seed_burned)
    VALUES (?, ?)
    ON CONFLICT(date) DO UPDATE SET seed_burned = seed_burned + ?
  `).run(a,e,e)}},49303:(e,r,t)=>{e.exports=t(30517)},9576:(e,r,t)=>{t.d(r,{Z:()=>d});var a=t(84770),s=t.n(a);let i={randomUUID:s().randomUUID},l=new Uint8Array(256),n=l.length,o=[];for(let e=0;e<256;++e)o.push((e+256).toString(16).slice(1));let d=function(e,r,t){if(i.randomUUID&&!r&&!e)return i.randomUUID();let a=(e=e||{}).random||(e.rng||function(){return n>l.length-16&&(s().randomFillSync(l),n=0),l.slice(n,n+=16)})();if(a[6]=15&a[6]|64,a[8]=63&a[8]|128,r){t=t||0;for(let e=0;e<16;++e)r[t+e]=a[e];return r}return function(e,r=0){return o[e[r+0]]+o[e[r+1]]+o[e[r+2]]+o[e[r+3]]+"-"+o[e[r+4]]+o[e[r+5]]+"-"+o[e[r+6]]+o[e[r+7]]+"-"+o[e[r+8]]+o[e[r+9]]+"-"+o[e[r+10]]+o[e[r+11]]+o[e[r+12]]+o[e[r+13]]+o[e[r+14]]+o[e[r+15]]}(a)}}};