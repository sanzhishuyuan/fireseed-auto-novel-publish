"use strict";exports.id=4630,exports.ids=[4630],exports.modules={4630:(e,r,t)=>{t.d(r,{Fl:()=>l,I6:()=>i,q0:()=>o,rI:()=>s,sM:()=>d});var a=t(9487),n=t(94877),u=t(9576);function i(e,r){try{let t=function(e){if(!e.title||e.title.trim().length<5)return{valid:!1,error:"项目标题至少5个字符"};if(e.title.length>100)return{valid:!1,error:"项目标题不能超过100个字符"};if(!e.description||e.description.trim().length<50)return{valid:!1,error:"项目描述至少50个字符"};if(e.description.length>5e3)return{valid:!1,error:"项目描述不能超过5000个字符"};if(!e.target_amount||e.target_amount<500)return{valid:!1,error:"目标金额至少500 SEED"};if(e.target_amount>1e5)return{valid:!1,error:"目标金额不能超过100000 SEED"};let r=new Date(e.deadline),t=new Date;if(isNaN(r.getTime()))return{valid:!1,error:"无效的截止日期格式"};if(r<=t)return{valid:!1,error:"截止日期必须在未来"};let a=(r.getTime()-t.getTime())/864e5;if(a<7)return{valid:!1,error:"众筹期限至少7天"};if(a>90)return{valid:!1,error:"众筹期限不能超过90天"};if(e.rewards&&e.rewards.length>0){if(e.rewards.length>10)return{valid:!1,error:"回报档位不能超过10个"};for(let r=0;r<e.rewards.length;r++){let t=e.rewards[r];if(!t.tier_name||t.tier_name.length<2)return{valid:!1,error:`第${r+1}个档位名称至少2个字符`};if(!t.min_amount||t.min_amount<10)return{valid:!1,error:`第${r+1}个档位最低支持金额至少10 SEED`};if(!t.benefits||0===t.benefits.length)return{valid:!1,error:`第${r+1}个档位必须包含权益描述`}}}return{valid:!0}}(r);if(!t.valid)return{success:!1,error:t.error};let n=a.default.transaction(()=>{let t=(0,u.Z)(),n=r.rewards?JSON.stringify(r.rewards):"[]";if(a.default.prepare(`
        INSERT INTO crowdfunding_projects (
          id, author_id, title, description, target_amount, current_amount,
          supporter_count, deadline, status, rewards, min_support_amount,
          stretch_goals, updates_count, success_stories, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, 0, 0, ?, 'active', ?, 10, '[]', 0, '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).run(t,e,r.title,r.description,r.target_amount,r.deadline,n),r.rewards&&r.rewards.length>0){let e=a.default.prepare(`
          INSERT INTO crowdfunding_rewards (
            id, project_id, tier_name, min_amount, benefits, limit_count, claimed_count
          ) VALUES (?, ?, ?, ?, ?, ?, 0)
        `);for(let a of r.rewards)e.run((0,u.Z)(),t,a.tier_name,a.min_amount,JSON.stringify(a.benefits),a.limit_count||0)}return t})();return{success:!0,projectId:n}}catch(e){return console.error("创建众筹项目失败:",e),{success:!1,error:e instanceof Error?e.message:"未知错误"}}}function d(e){let r=e.page||1,t=e.limit||20,n=[],u=[];e.status&&(n.push("p.status = ?"),u.push(e.status));let i=n.length>0?`WHERE ${n.join(" AND ")}`:"",d="p.created_at DESC";"popular"===e.sort?d="p.current_amount DESC":"ending_soon"===e.sort&&(d="p.deadline ASC");let o=`SELECT COUNT(*) as total FROM crowdfunding_projects p ${i}`,s=a.default.prepare(o).get(...u).total,l=`
    SELECT 
      p.*,
      u.username as author_name,
      CAST((p.current_amount * 100.0 / p.target_amount) AS INTEGER) as progress_percentage,
      CAST(julianday(p.deadline) - julianday('now') AS INTEGER) as days_left
    FROM crowdfunding_projects p
    LEFT JOIN users u ON p.author_id = u.id
    ${i}
    ORDER BY ${d}
    LIMIT ? OFFSET ?
  `;return{projects:a.default.prepare(l).all(...u,t,(r-1)*t),total:s,page:r,totalPages:Math.ceil(s/t)}}function o(e){return{project:a.default.prepare(`
    SELECT 
      p.*,
      u.username as author_name,
      CAST((p.current_amount * 100.0 / p.target_amount) AS INTEGER) as progress_percentage,
      CAST(julianday(p.deadline) - julianday('now') AS INTEGER) as days_left
    FROM crowdfunding_projects p
    LEFT JOIN users u ON p.author_id = u.id
    WHERE p.id = ?
  `).get(e)||null,rewards:a.default.prepare(`
    SELECT * FROM crowdfunding_rewards WHERE project_id = ? ORDER BY min_amount ASC
  `).all(e)}}function s(e,r,t,i){try{let d=a.default.prepare("SELECT status, target_amount, current_amount, deadline FROM crowdfunding_projects WHERE id = ?").get(e);if(!d)return{success:!1,error:"众筹项目不存在"};if("active"!==d.status)return{success:!1,error:"众筹项目已结束"};let o=new Date(d.deadline);if(new Date>o)return{success:!1,error:"众筹已过期"};let s=(0,n.k)(r);if(s.balance<t)return{success:!1,error:`余额不足，当前余额: ${s.balance} SEED，需要: ${t} SEED`};if(a.default.prepare("SELECT id FROM crowdfunding_supporters WHERE project_id = ? AND user_id = ?").get(e,r))return{success:!1,error:"您已经支持过此项目"};if(i){let r=a.default.prepare("SELECT min_amount, limit_count, claimed_count FROM crowdfunding_rewards WHERE project_id = ? AND tier_name = ?").get(e,i);if(!r)return{success:!1,error:"无效的回报档位"};if(t<r.min_amount)return{success:!1,error:`此档位最低支持金额为 ${r.min_amount} SEED`};if(r.limit_count>0&&r.claimed_count>=r.limit_count)return{success:!1,error:"此档位限量已售罄"}}return a.default.transaction(()=>{let n=(0,u.Z)();a.default.prepare("UPDATE wallets SET balance = balance - ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?").run(t,r),a.default.prepare("INSERT INTO transactions (id, user_id, type, amount, balance_after, description, created_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)").run((0,u.Z)(),r,"crowdfunding_support",-t,s.balance-t,`支持众筹项目`),a.default.prepare(`
        INSERT INTO crowdfunding_supporters (id, project_id, user_id, amount, reward_tier, created_at)
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `).run(n,e,r,t,i||""),a.default.prepare(`
        UPDATE crowdfunding_projects 
        SET current_amount = current_amount + ?, supporter_count = supporter_count + 1, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(t,e),i&&a.default.prepare(`
          UPDATE crowdfunding_rewards 
          SET claimed_count = claimed_count + 1
          WHERE project_id = ? AND tier_name = ?
        `).run(e,i)})(),{success:!0}}catch(e){return console.error("支持众筹失败:",e),{success:!1,error:e instanceof Error?e.message:"未知错误"}}}function l(e,r,t,n){try{let i=a.default.prepare("SELECT author_id FROM crowdfunding_projects WHERE id = ?").get(e);if(!i)return{success:!1,error:"项目不存在"};if(i.author_id!==r)return{success:!1,error:"无权操作此项目"};return a.default.prepare(`
      INSERT INTO crowdfunding_updates (id, project_id, title, content, created_at)
      VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
    `).run((0,u.Z)(),e,t,n),a.default.prepare(`
      UPDATE crowdfunding_projects SET updates_count = updates_count + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?
    `).run(e),{success:!0}}catch(e){return console.error("发布更新失败:",e),{success:!1,error:e instanceof Error?e.message:"未知错误"}}}},94877:(e,r,t)=>{t.d(r,{B3:()=>o,Zp:()=>l,f1:()=>s,jq:()=>c,k:()=>u,sb:()=>i,transferSeed:()=>d});var a=t(9576),n=t(9487);function u(e){let r=n.default.prepare("SELECT * FROM wallets WHERE user_id = ?").get(e);return r||(n.default.prepare("INSERT INTO wallets (user_id, balance, total_earned, total_spent) VALUES (?, 0, 0, 0)").run(e),r=n.default.prepare("SELECT * FROM wallets WHERE user_id = ?").get(e)),r}function i(e){let r=n.default.prepare("SELECT balance FROM wallets WHERE user_id = ?").get(e);return r?.balance??0}function d(e,r,t,d){if(r<0){let t=i(e);if(t+r<0)throw Error(`余额不足：当前 ${t} 🌱，需要 ${Math.abs(r)} 🌱`)}return n.default.transaction(()=>{let i=u(e).balance+r;n.default.prepare(`
      UPDATE wallets SET balance = ?, total_earned = total_earned + ?, total_spent = total_spent + ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).run(i,r>0?r:0,r<0?Math.abs(r):0,e);let o=(0,a.Z)();return n.default.prepare(`
      INSERT INTO transactions (id, user_id, target_id, type, ref_id, amount, balance_after, description)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(o,e,d?.targetId||null,t,d?.refId||null,r,i,d?.description||null),i})()}function o(e,r,t,a,u){if(t<=0)throw Error("转账金额必须为正数");let i=u?.platformShare||0,o=t-i;return n.default.transaction(()=>{let n;let s=d(e,-t,a,{refId:u?.refId,description:u?.description}),l=d(r,o,a,{targetId:e,refId:u?.refId,description:u?.description});return i>0&&(n=d("platform",i,a,{refId:u?.refId,description:`平台抽佣 ${i} SEED`})),{fromBalance:s,toBalance:l,platformBalance:n}})()}function s(e,r=20,t=0){return n.default.prepare(`
    SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(e,r,t)}function l(e=20){return n.default.prepare(`
    SELECT w.user_id, u.username, w.balance, w.total_earned
    FROM wallets w
    JOIN users u ON w.user_id = u.id
    WHERE w.balance > 0 AND u.role != 'admin'
    ORDER BY w.balance DESC
    LIMIT ?
  `).all(e)}function c(e,r){let t=i("platform");if(t<e)throw Error(`平台余额不足: ${t} < ${e}`);d("platform",-e,"burn",{description:r||`销毁 ${e} SEED`});let a=new Date().toISOString().slice(0,10);n.default.prepare(`
    INSERT INTO daily_economy_stats (date, seed_burned)
    VALUES (?, ?)
    ON CONFLICT(date) DO UPDATE SET seed_burned = seed_burned + ?
  `).run(a,e,e)}},9576:(e,r,t)=>{t.d(r,{Z:()=>s});var a=t(84770),n=t.n(a);let u={randomUUID:n().randomUUID},i=new Uint8Array(256),d=i.length,o=[];for(let e=0;e<256;++e)o.push((e+256).toString(16).slice(1));let s=function(e,r,t){if(u.randomUUID&&!r&&!e)return u.randomUUID();let a=(e=e||{}).random||(e.rng||function(){return d>i.length-16&&(n().randomFillSync(i),d=0),i.slice(d,d+=16)})();if(a[6]=15&a[6]|64,a[8]=63&a[8]|128,r){t=t||0;for(let e=0;e<16;++e)r[t+e]=a[e];return r}return function(e,r=0){return o[e[r+0]]+o[e[r+1]]+o[e[r+2]]+o[e[r+3]]+"-"+o[e[r+4]]+o[e[r+5]]+"-"+o[e[r+6]]+o[e[r+7]]+"-"+o[e[r+8]]+o[e[r+9]]+"-"+o[e[r+10]]+o[e[r+11]]+o[e[r+12]]+o[e[r+13]]+o[e[r+14]]+o[e[r+15]]}(a)}}};