"use strict";exports.id=3920,exports.ids=[3920],exports.modules={94877:(e,r,t)=>{t.d(r,{B3:()=>d,Zp:()=>o,f1:()=>l,jq:()=>E,k:()=>n,sb:()=>u,transferSeed:()=>i});var a=t(9576),s=t(9487);function n(e){let r=s.default.prepare("SELECT * FROM wallets WHERE user_id = ?").get(e);return r||(s.default.prepare("INSERT INTO wallets (user_id, balance, total_earned, total_spent) VALUES (?, 0, 0, 0)").run(e),r=s.default.prepare("SELECT * FROM wallets WHERE user_id = ?").get(e)),r}function u(e){let r=s.default.prepare("SELECT balance FROM wallets WHERE user_id = ?").get(e);return r?.balance??0}function i(e,r,t,i){if(r<0){let t=u(e);if(t+r<0)throw Error(`余额不足：当前 ${t} 🌱，需要 ${Math.abs(r)} 🌱`)}return s.default.transaction(()=>{let u=n(e).balance+r;s.default.prepare(`
      UPDATE wallets SET balance = ?, total_earned = total_earned + ?, total_spent = total_spent + ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).run(u,r>0?r:0,r<0?Math.abs(r):0,e);let d=(0,a.Z)();return s.default.prepare(`
      INSERT INTO transactions (id, user_id, target_id, type, ref_id, amount, balance_after, description)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(d,e,i?.targetId||null,t,i?.refId||null,r,u,i?.description||null),u})()}function d(e,r,t,a,n){if(t<=0)throw Error("转账金额必须为正数");let u=n?.platformShare||0,d=t-u;return s.default.transaction(()=>{let s;let l=i(e,-t,a,{refId:n?.refId,description:n?.description}),o=i(r,d,a,{targetId:e,refId:n?.refId,description:n?.description});return u>0&&(s=i("platform",u,a,{refId:n?.refId,description:`平台抽佣 ${u} SEED`})),{fromBalance:l,toBalance:o,platformBalance:s}})()}function l(e,r=20,t=0){return s.default.prepare(`
    SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(e,r,t)}function o(e=20){return s.default.prepare(`
    SELECT w.user_id, u.username, w.balance, w.total_earned
    FROM wallets w
    JOIN users u ON w.user_id = u.id
    WHERE w.balance > 0 AND u.role != 'admin'
    ORDER BY w.balance DESC
    LIMIT ?
  `).all(e)}function E(e,r){let t=u("platform");if(t<e)throw Error(`平台余额不足: ${t} < ${e}`);i("platform",-e,"burn",{description:r||`销毁 ${e} SEED`});let a=new Date().toISOString().slice(0,10);s.default.prepare(`
    INSERT INTO daily_economy_stats (date, seed_burned)
    VALUES (?, ?)
    ON CONFLICT(date) DO UPDATE SET seed_burned = seed_burned + ?
  `).run(a,e,e)}},3920:(e,r,t)=>{t.d(r,{Ak:()=>i,JM:()=>l,Wl:()=>o,el:()=>c,ov:()=>E,vr:()=>u,yW:()=>d});var a=t(9487),s=t(94877),n=t(9576);function u(e,r){try{let t=function(e){if(!e.title||e.title.trim().length<5)return{valid:!1,error:"任务标题至少5个字符"};if(e.title.length>100)return{valid:!1,error:"任务标题不能超过100个字符"};if(!e.description||e.description.trim().length<20)return{valid:!1,error:"任务描述至少20个字符"};if(e.description.length>2e3)return{valid:!1,error:"任务描述不能超过2000个字符"};if(!e.budget||e.budget<50)return{valid:!1,error:"任务预算至少50 SEED"};if(e.budget>5e4)return{valid:!1,error:"任务预算不能超过50000 SEED"};let r=new Date(e.deadline),t=new Date;if(isNaN(r.getTime()))return{valid:!1,error:"无效的截止日期格式"};if(r<=t)return{valid:!1,error:"截止日期必须在未来"};if((r.getTime()-t.getTime())/864e5>90)return{valid:!1,error:"任务期限不能超过90天"};if(e.target_words){if(e.target_words<1e3)return{valid:!1,error:"目标字数至少1000字"};if(e.target_words>1e6)return{valid:!1,error:"目标字数不能超过100万字"}}return{valid:!0}}(r);if(!t.valid)return{success:!1,error:t.error};let u=(0,s.k)(e);if(u.balance<r.budget)return{success:!1,error:`余额不足，当前余额: ${u.balance} SEED，需要: ${r.budget} SEED`};let i=a.default.transaction(()=>{let t=(0,n.Z)();return a.default.prepare("UPDATE wallets SET balance = balance - ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?").run(r.budget,e),a.default.prepare("INSERT INTO transactions (id, user_id, type, amount, balance_after, description, created_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)").run((0,n.Z)(),e,"task_publish",-r.budget,u.balance-r.budget,`发布任务: ${r.title}`),a.default.prepare(`
        INSERT INTO novel_tasks (
          id, publisher_id, title, description, genre, target_words, 
          budget, deadline, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      `).run(t,e,r.title,r.description,r.genre||null,r.target_words||null,r.budget,r.deadline),t})();return{success:!0,taskId:i}}catch(e){return console.error("创建任务失败:",e),{success:!1,error:e instanceof Error?e.message:"未知错误"}}}function i(e){let r=e.page||1,t=e.limit||20,s=[],n=[];e.status&&(s.push("t.status = ?"),n.push(e.status)),e.genre&&(s.push("t.genre = ?"),n.push(e.genre));let u=s.length>0?`WHERE ${s.join(" AND ")}`:"",i=`SELECT COUNT(*) as total FROM novel_tasks t ${u}`,d=a.default.prepare(i).get(...n).total,l=`
    SELECT 
      t.*,
      u1.username as publisher_name,
      u2.username as assignee_name
    FROM novel_tasks t
    LEFT JOIN users u1 ON t.publisher_id = u1.id
    LEFT JOIN users u2 ON t.assignee_id = u2.id
    ${u}
    ORDER BY t.created_at DESC
    LIMIT ? OFFSET ?
  `;return{tasks:a.default.prepare(l).all(...n,t,(r-1)*t),total:d,page:r,totalPages:Math.ceil(d/t)}}function d(e){return a.default.prepare(`
    SELECT 
      t.*,
      u1.username as publisher_name,
      u2.username as assignee_name
    FROM novel_tasks t
    LEFT JOIN users u1 ON t.publisher_id = u1.id
    LEFT JOIN users u2 ON t.assignee_id = u2.id
    WHERE t.id = ?
  `).get(e)||null}function l(e,r){try{let t=a.default.prepare("SELECT status, budget FROM novel_tasks WHERE id = ?").get(e);if(!t)return{success:!1,error:"任务不存在"};if("open"!==t.status)return{success:!1,error:"任务已被接单或已完成"};return a.default.prepare(`
      UPDATE novel_tasks 
      SET status = 'assigned', assignee_id = ?, assigned_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND status = 'open'
    `).run(r,e),{success:!0}}catch(e){return console.error("接单失败:",e),{success:!1,error:e instanceof Error?e.message:"未知错误"}}}function o(e,r,t){try{let s=a.default.prepare("SELECT status, assignee_id FROM novel_tasks WHERE id = ?").get(e);if(!s)return{success:!1,error:"任务不存在"};if("assigned"!==s.status)return{success:!1,error:"任务状态不正确"};if(s.assignee_id!==r)return{success:!1,error:"无权操作此任务"};return a.default.prepare(`
      UPDATE novel_tasks 
      SET status = 'pending_review', delivery_url = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(t,e),{success:!0}}catch(e){return console.error("提交完成失败:",e),{success:!1,error:e instanceof Error?e.message:"未知错误"}}}function E(e,r,t,u){try{let i=a.default.prepare("SELECT status, publisher_id, budget, assignee_id FROM novel_tasks WHERE id = ?").get(e);if(!i)return{success:!1,error:"任务不存在"};if("pending_review"!==i.status)return{success:!1,error:"任务状态不正确"};if(i.publisher_id!==r)return{success:!1,error:"无权操作此任务"};let d=Math.floor(.9*i.budget),l=i.budget-d;return a.default.transaction(()=>{let r=(0,s.k)(i.assignee_id);a.default.prepare("UPDATE wallets SET balance = balance + ?, total_earned = total_earned + ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?").run(d,d,i.assignee_id),a.default.prepare("INSERT INTO transactions (id, user_id, target_id, type, ref_id, amount, balance_after, description, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)").run((0,n.Z)(),i.assignee_id,null,"task_reward",e,d,r.balance+d,"完成任务获得奖励");let o=(0,s.k)("platform");a.default.prepare("UPDATE wallets SET balance = balance + ?, total_earned = total_earned + ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?").run(l,l,"platform"),a.default.prepare("INSERT INTO transactions (id, user_id, target_id, type, ref_id, amount, balance_after, description, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)").run((0,n.Z)(),"platform",null,"task_reward",e,l,o.balance+l,"任务平台抽成 10%"),a.default.prepare(`
        UPDATE novel_tasks 
        SET status = 'completed', completed_at = CURRENT_TIMESTAMP, rating = ?, review = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(t||null,u||null,e)})(),{success:!0}}catch(e){return console.error("确认完成失败:",e),{success:!1,error:e instanceof Error?e.message:"未知错误"}}}function c(e,r){try{let t=a.default.prepare("SELECT status, publisher_id, budget FROM novel_tasks WHERE id = ?").get(e);if(!t)return{success:!1,error:"任务不存在"};if(t.publisher_id!==r)return{success:!1,error:"无权操作此任务"};if("completed"===t.status)return{success:!1,error:"已完成的任务不能取消"};return("assigned"===t.status||"pending_review"===t.status)&&a.default.prepare("UPDATE novel_tasks SET status = 'open', assignee_id = NULL, assigned_at = NULL WHERE id = ?").run(e),a.default.transaction(()=>{let u=(0,s.k)(r);a.default.prepare("UPDATE wallets SET balance = balance + ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?").run(t.budget,r),a.default.prepare("INSERT INTO transactions (id, user_id, target_id, type, ref_id, amount, balance_after, description, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)").run((0,n.Z)(),r,null,"compensate",e,t.budget,u.balance+t.budget,"任务取消退款"),a.default.prepare(`
        UPDATE novel_tasks 
        SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(e)})(),{success:!0,refundAmount:t.budget}}catch(e){return console.error("取消任务失败:",e),{success:!1,error:e instanceof Error?e.message:"未知错误"}}}},9576:(e,r,t)=>{t.d(r,{Z:()=>l});var a=t(84770),s=t.n(a);let n={randomUUID:s().randomUUID},u=new Uint8Array(256),i=u.length,d=[];for(let e=0;e<256;++e)d.push((e+256).toString(16).slice(1));let l=function(e,r,t){if(n.randomUUID&&!r&&!e)return n.randomUUID();let a=(e=e||{}).random||(e.rng||function(){return i>u.length-16&&(s().randomFillSync(u),i=0),u.slice(i,i+=16)})();if(a[6]=15&a[6]|64,a[8]=63&a[8]|128,r){t=t||0;for(let e=0;e<16;++e)r[t+e]=a[e];return r}return function(e,r=0){return d[e[r+0]]+d[e[r+1]]+d[e[r+2]]+d[e[r+3]]+"-"+d[e[r+4]]+d[e[r+5]]+"-"+d[e[r+6]]+d[e[r+7]]+"-"+d[e[r+8]]+d[e[r+9]]+"-"+d[e[r+10]]+d[e[r+11]]+d[e[r+12]]+d[e[r+13]]+d[e[r+14]]+d[e[r+15]]}(a)}}};